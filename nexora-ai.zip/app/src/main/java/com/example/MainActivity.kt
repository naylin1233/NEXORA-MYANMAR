package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.localization.NexoraStrings
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.projects.ProjectsScreen
import com.example.ui.screens.recap.VideoRecapScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.subtitle.SrtStudioScreen
import com.example.ui.screens.thumbnail.ThumbnailGeneratorScreen
import com.example.ui.screens.title.TitleHashtagScreen
import com.example.ui.screens.translate.MyanmarTranslateScreen
import com.example.ui.screens.voice.VoiceStudioScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDarkNavy
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraPurpleVioletGradient
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraNavDestination
import com.example.ui.viewmodel.NexoraViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: NexoraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NexoraApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexoraApp(viewModel: NexoraViewModel) {
    val currentDest by viewModel.currentDestination.collectAsState()
    val strings by viewModel.strings.collectAsState()
    var showMoreSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    // BackHandler: Return to Home if on sub-screens
    BackHandler(enabled = currentDest != NexoraNavDestination.HOME) {
        viewModel.navigateTo(NexoraNavDestination.HOME)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(NexoraDeepBlack)) {
        val isWideScreen = maxWidth >= 600.dp

        if (isWideScreen) {
            // Tablet / Desktop layout with Navigation Rail
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    modifier = Modifier
                        .fillMaxHeight()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .background(NexoraDarkNavy),
                    containerColor = NexoraDarkNavy,
                    contentColor = NexoraTextPrimary
                ) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "NEXORA",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = NexoraNeonViolet
                        )
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    RailItem(
                        selected = currentDest == NexoraNavDestination.HOME,
                        icon = Icons.Default.Home,
                        label = strings.navHome,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.HOME) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.RECAP,
                        icon = Icons.Default.Movie,
                        label = strings.navRecap,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.RECAP) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.TRANSLATE,
                        icon = Icons.Default.Translate,
                        label = strings.navTranslate,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.TRANSLATE) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.VOICE,
                        icon = Icons.Default.GraphicEq,
                        label = strings.navVoice,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.VOICE) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.SRT_STUDIO,
                        icon = Icons.Default.Subtitles,
                        label = strings.navSrt,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.SRT_STUDIO) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.THUMBNAIL,
                        icon = Icons.Default.Image,
                        label = strings.navThumbnail,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.THUMBNAIL) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.TITLES_TAGS,
                        icon = Icons.Default.Tag,
                        label = strings.navTitle,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.TITLES_TAGS) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.PROJECTS,
                        icon = Icons.Default.Folder,
                        label = strings.navProjects,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.PROJECTS) }
                    )
                    RailItem(
                        selected = currentDest == NexoraNavDestination.SETTINGS,
                        icon = Icons.Default.Settings,
                        label = strings.navSettings,
                        onClick = { viewModel.navigateTo(NexoraNavDestination.SETTINGS) }
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .windowInsetsPadding(WindowInsets.statusBars)
                ) {
                    ScreenContent(currentDest, viewModel)
                }
            }
        } else {
            // Mobile layout with Top Safe Insets and Bottom Navigation
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars),
                containerColor = NexoraDeepBlack,
                bottomBar = {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .background(NexoraDeepBlack)
                    ) {
                        NavigationBar(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(68.dp)
                                .shadow(16.dp)
                                .border(BorderSubtle, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .testTag("main_bottom_nav"),
                            containerColor = NexoraDarkNavy,
                            contentColor = NexoraTextPrimary,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentDest == NexoraNavDestination.HOME,
                                onClick = { viewModel.navigateTo(NexoraNavDestination.HOME) },
                                icon = { Icon(Icons.Default.Home, contentDescription = strings.navHome) },
                                label = { Text(strings.navHome, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                colors = navItemColors()
                            )
                            NavigationBarItem(
                                selected = currentDest == NexoraNavDestination.RECAP,
                                onClick = { viewModel.navigateTo(NexoraNavDestination.RECAP) },
                                icon = { Icon(Icons.Default.Movie, contentDescription = strings.navRecap) },
                                label = { Text(strings.navRecap, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                colors = navItemColors()
                            )
                            NavigationBarItem(
                                selected = currentDest == NexoraNavDestination.TRANSLATE,
                                onClick = { viewModel.navigateTo(NexoraNavDestination.TRANSLATE) },
                                icon = { Icon(Icons.Default.Translate, contentDescription = strings.navTranslate) },
                                label = { Text(strings.navTranslate, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                colors = navItemColors()
                            )
                            NavigationBarItem(
                                selected = currentDest == NexoraNavDestination.VOICE,
                                onClick = { viewModel.navigateTo(NexoraNavDestination.VOICE) },
                                icon = { Icon(Icons.Default.GraphicEq, contentDescription = strings.navVoice) },
                                label = { Text(strings.navVoice, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                colors = navItemColors()
                            )
                            NavigationBarItem(
                                selected = showMoreSheet || isSecondaryActive(currentDest),
                                onClick = { showMoreSheet = true },
                                icon = { Icon(Icons.Default.Apps, contentDescription = strings.navMore) },
                                label = { Text(strings.navMore, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                colors = navItemColors()
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    ScreenContent(currentDest, viewModel)
                }
            }
        }

        // More Tools Modal Sheet
        if (showMoreSheet) {
            ModalBottomSheet(
                onDismissRequest = { showMoreSheet = false },
                sheetState = sheetState,
                containerColor = NexoraSurfaceDark,
                contentColor = NexoraTextPrimary,
                dragHandle = null
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.allFeatures,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                        IconButton(onClick = {
                            scope.launch { sheetState.hide() }.invokeOnCompletion { showMoreSheet = false }
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = NexoraTextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    MoreToolItem(
                        icon = Icons.Default.Subtitles,
                        title = strings.navSrt,
                        desc = "SRT subtitle timeline, timing sync & translation",
                        accentColor = NexoraCyanAccent,
                        onClick = {
                            viewModel.navigateTo(NexoraNavDestination.SRT_STUDIO)
                            showMoreSheet = false
                        }
                    )
                    MoreToolItem(
                        icon = Icons.Default.Image,
                        title = strings.navThumbnail,
                        desc = "16:9 & 9:16 high CTR thumbnails with Myanmar typography",
                        accentColor = NexoraNeonViolet,
                        onClick = {
                            viewModel.navigateTo(NexoraNavDestination.THUMBNAIL)
                            showMoreSheet = false
                        }
                    )
                    MoreToolItem(
                        icon = Icons.Default.Tag,
                        title = strings.navTitle,
                        desc = "High CTR YouTube titles, TikTok hooks & viral hashtags",
                        accentColor = NexoraPurplePrimary,
                        onClick = {
                            viewModel.navigateTo(NexoraNavDestination.TITLES_TAGS)
                            showMoreSheet = false
                        }
                    )
                    MoreToolItem(
                        icon = Icons.Default.Folder,
                        title = strings.navProjects,
                        desc = "View, manage, search, and export saved project archives",
                        accentColor = Color(0xFFF59E0B),
                        onClick = {
                            viewModel.navigateTo(NexoraNavDestination.PROJECTS)
                            showMoreSheet = false
                        }
                    )
                    MoreToolItem(
                        icon = Icons.Default.Settings,
                        title = strings.navSettings,
                        desc = "Language switcher, Gemini API status & app info",
                        accentColor = NexoraTextSecondary,
                        onClick = {
                            viewModel.navigateTo(NexoraNavDestination.SETTINGS)
                            showMoreSheet = false
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

private val BorderSubtle = androidx.compose.foundation.BorderStroke(1.dp, NexoraBorderGlass)

private fun isSecondaryActive(dest: NexoraNavDestination): Boolean {
    return dest in listOf(
        NexoraNavDestination.SRT_STUDIO,
        NexoraNavDestination.THUMBNAIL,
        NexoraNavDestination.TITLES_TAGS,
        NexoraNavDestination.PROJECTS,
        NexoraNavDestination.SETTINGS
    )
}

@Composable
private fun navItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = NexoraNeonViolet,
    selectedTextColor = NexoraNeonViolet,
    indicatorColor = NexoraPurplePrimary.copy(alpha = 0.25f),
    unselectedIconColor = NexoraTextMuted,
    unselectedTextColor = NexoraTextMuted
)

@Composable
private fun RailItem(
    selected: Boolean,
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    NavigationRailItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label, fontSize = 10.sp) },
        colors = NavigationRailItemDefaults.colors(
            selectedIconColor = NexoraNeonViolet,
            selectedTextColor = NexoraNeonViolet,
            indicatorColor = NexoraPurplePrimary.copy(alpha = 0.25f),
            unselectedIconColor = NexoraTextMuted,
            unselectedTextColor = NexoraTextMuted
        )
    )
}

@Composable
private fun MoreToolItem(
    icon: ImageVector,
    title: String,
    desc: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.2f))
                    .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NexoraTextSecondary
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun ScreenContent(dest: NexoraNavDestination, viewModel: NexoraViewModel) {
    AnimatedContent(
        targetState = dest,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { target ->
        when (target) {
            NexoraNavDestination.HOME -> HomeScreen(viewModel)
            NexoraNavDestination.RECAP -> VideoRecapScreen(viewModel)
            NexoraNavDestination.TRANSLATE -> MyanmarTranslateScreen(viewModel)
            NexoraNavDestination.VOICE -> VoiceStudioScreen(viewModel)
            NexoraNavDestination.SRT_STUDIO -> SrtStudioScreen(viewModel)
            NexoraNavDestination.THUMBNAIL -> ThumbnailGeneratorScreen(viewModel)
            NexoraNavDestination.TITLES_TAGS -> TitleHashtagScreen(viewModel)
            NexoraNavDestination.PROJECTS -> ProjectsScreen(viewModel)
            NexoraNavDestination.SETTINGS -> SettingsScreen(viewModel)
        }
    }
}
