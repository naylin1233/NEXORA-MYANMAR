package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val NexoraDarkColorScheme = darkColorScheme(
    primary = NexoraPurplePrimary,
    onPrimary = NexoraTextPrimary,
    primaryContainer = NexoraPurpleDark,
    onPrimaryContainer = NexoraNeonViolet,
    secondary = NexoraElectricViolet,
    onSecondary = NexoraTextPrimary,
    secondaryContainer = NexoraSurfaceElevated,
    onSecondaryContainer = NexoraTextPrimary,
    tertiary = NexoraCyanAccent,
    onTertiary = NexoraDeepBlack,
    background = NexoraDeepBlack,
    onBackground = NexoraTextPrimary,
    surface = NexoraDarkNavy,
    onSurface = NexoraTextPrimary,
    surfaceVariant = NexoraSurfaceDark,
    onSurfaceVariant = NexoraTextSecondary,
    outline = NexoraBorderGlass,
    outlineVariant = NexoraBorderSubtle,
    error = NexoraRedAccent
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = NexoraDeepBlack.toArgb()
                window.navigationBarColor = NexoraDeepBlack.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = NexoraDarkColorScheme,
        typography = Typography,
        content = content
    )
}
