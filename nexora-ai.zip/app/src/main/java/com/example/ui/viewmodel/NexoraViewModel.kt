package com.example.ui.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.NexoraDatabase
import com.example.data.local.ProjectEntity
import com.example.data.model.CharacterDialogue
import com.example.data.model.CharacterRole
import com.example.data.model.GeneratedTitlesAndTags
import com.example.data.model.MyanmarRecapMode
import com.example.data.model.MyanmarRecapResult
import com.example.data.model.MyanmarRecapScene
import com.example.data.model.ProjectStatus
import com.example.data.model.ProjectType
import com.example.data.model.RecapResult
import com.example.data.model.SubtitleSegment
import com.example.data.model.PersonalVoiceProfile
import com.example.data.model.VoiceProfile
import com.example.data.model.MyanmarVoiceStyle
import com.example.data.model.AzureBurmeseVoices
import com.example.data.model.SupportedTtsLanguages
import com.example.data.model.TtsLanguage
import com.example.data.remote.GeminiService
import com.example.data.repository.NexoraRepository
import com.example.ui.localization.NexoraLanguage
import com.example.ui.localization.NexoraStrings
import com.example.ui.localization.getStrings
import com.example.ui.voice.NexoraTtsManager
import com.example.ui.voice.NexoraVoiceRecorder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class NexoraNavDestination {
    HOME,
    RECAP,
    TRANSLATE,
    VOICE,
    SRT_STUDIO,
    THUMBNAIL,
    TITLES_TAGS,
    PROJECTS,
    SETTINGS
}

class NexoraViewModel(application: Application) : AndroidViewModel(application) {
    private val database = NexoraDatabase.getDatabase(application)
    val geminiService = GeminiService()
    val repository = NexoraRepository(database.projectDao(), geminiService, application.applicationContext)
    val ttsManager = NexoraTtsManager(application)
    val voiceRecorder = NexoraVoiceRecorder(application.applicationContext)

    // Personal Voice & Voice Cloning
    val personalVoices: StateFlow<List<PersonalVoiceProfile>> = repository.personalVoices
    val activePersonalVoice: StateFlow<PersonalVoiceProfile?> = repository.activePersonalVoice
    val isRecordingVoice: StateFlow<Boolean> = voiceRecorder.isRecording
    val recordingDuration: StateFlow<Int> = voiceRecorder.durationSeconds
    val recordingAmplitude: StateFlow<Float> = voiceRecorder.amplitude
    val recordedSampleFile: StateFlow<File?> = voiceRecorder.recordedFile
    val isPlayingRecordedSample: StateFlow<Boolean> = voiceRecorder.isPlayingRecording

    val selectedRecapVoice = MutableStateFlow<String>(AzureBurmeseVoices.MALE_THIHA)

    init {
        repository.loadPersonalVoices()
    }

    fun isApiConfigured(): Boolean = geminiService.isConfigured()

    // Current App Language & Strings
    private val _currentLanguage = MutableStateFlow(NexoraLanguage.ENGLISH)
    val currentLanguage: StateFlow<NexoraLanguage> = _currentLanguage.asStateFlow()

    val strings: StateFlow<NexoraStrings> = _currentLanguage
        .combine(MutableStateFlow(Unit)) { lang, _ -> getStrings(lang) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, getStrings(NexoraLanguage.ENGLISH))

    // Navigation Destination
    private val _currentDestination = MutableStateFlow(NexoraNavDestination.HOME)
    val currentDestination: StateFlow<NexoraNavDestination> = _currentDestination.asStateFlow()

    // Status / Toast Message
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // ---------------- Video Recap State ----------------
    var recapInput = MutableStateFlow("In Neo-City, an amnesiac soldier with bionic enhancements discovers his former squad leader has rigged the subterranean power grid to overthrow the governor.")
    var recapVideoLang = MutableStateFlow("English")
    var recapOutputLang = MutableStateFlow("Myanmar")
    var selectedVideoUri = MutableStateFlow<Uri?>(null)

    // Five Myanmar Recap Modes
    val selectedRecapMode = MutableStateFlow(MyanmarRecapMode.NARRATOR_RECAP)
    val recapChunkCount = MutableStateFlow(1) // 1 for normal, 2..4 for long videos
    val viralDurationOption = MutableStateFlow("60s") // "60s" or "120s" for Mode 5
    val previewingMode = MutableStateFlow<MyanmarRecapMode?>(null)

    private val _isRecapProcessing = MutableStateFlow(false)
    val isRecapProcessing: StateFlow<Boolean> = _isRecapProcessing.asStateFlow()

    private val _recapProgress = MutableStateFlow(0f)
    val recapProgress: StateFlow<Float> = _recapProgress.asStateFlow()

    private val _recapProgressText = MutableStateFlow("")
    val recapProgressText: StateFlow<String> = _recapProgressText.asStateFlow()

    private val _currentMyanmarRecap = MutableStateFlow<MyanmarRecapResult?>(null)
    val currentMyanmarRecap: StateFlow<MyanmarRecapResult?> = _currentMyanmarRecap.asStateFlow()

    // Burmese TTS state & error handling
    val isBurmeseTtsSupported = ttsManager.isBurmeseSupported
    val burmeseEngineMessage = ttsManager.burmeseEngineMessage
    val ttsErrorMessage = MutableStateFlow<String?>(null)
    val showTtsInstallDialog = MutableStateFlow(false)

    // ---------------- Translation State ----------------
    var translateSourceText = MutableStateFlow("")
    var translateSourceLang = MutableStateFlow("English")
    var translateTargetLang = MutableStateFlow("Myanmar")
    var translateStyle = MutableStateFlow("Natural")

    private val _translatedResult = MutableStateFlow("")
    val translatedResult: StateFlow<String> = _translatedResult.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    val translationHistory = repository.translationHistory

    // ---------------- Voice / Dubbing State ----------------
    var voiceScriptText = MutableStateFlow("မင်္ဂလာပါ NEXORA AI မှ ကြိုဆိုပါတယ်။ ကျွန်တော်တို့ရဲ့ အဆင့်မြင့် AI စနစ်ဖြင့် ဗီဒီယို နောက်ခံအသံများကို သဘာဝကျကျ အသံသွင်း ဖန်တီးနိုင်ပါပြီ။")
    val supportedTtsLanguages: List<TtsLanguage> = SupportedTtsLanguages.ALL
    var selectedTtsLanguage = MutableStateFlow<TtsLanguage>(SupportedTtsLanguages.BURMESE)
    var selectedGenderVoice = MutableStateFlow("Female")
    var selectedVoiceProfile = MutableStateFlow(repository.voiceProfiles.first())
    var selectedVoiceStyle = MutableStateFlow(MyanmarVoiceStyle.MALE_VOICE)
    var selectedBaseVoiceId = MutableStateFlow(AzureBurmeseVoices.MALE_THIHA)
    var voiceSpeed = MutableStateFlow(1.0f)
    var voicePitch = MutableStateFlow(1.0f)
    var voiceVolume = MutableStateFlow(1.0f)
    var isSceneMode = MutableStateFlow(false)
    var isVoiceGenerating = MutableStateFlow(false)
    var previewingVoiceStyle = MutableStateFlow<MyanmarVoiceStyle?>(null)

    val isVoicePlaying = ttsManager.isPlaying
    val lastGeneratedAudioFile = ttsManager.lastGeneratedAudioFile

    // ---------------- SRT Studio State ----------------
    var srtRawInput = MutableStateFlow(
        """1
00:00:01,000 --> 00:00:04,500
Deep within Neo-City, the signal began to pulse.

2
00:00:05,000 --> 00:00:08,200
Leo stepped out into the pouring rain.

3
00:00:09,000 --> 00:00:13,800
Tonight, the secret of the Apex Tower will be revealed."""
    )

    private val _srtSegments = MutableStateFlow<List<SubtitleSegment>>(emptyList())
    val srtSegments: StateFlow<List<SubtitleSegment>> = _srtSegments.asStateFlow()

    private val _isTranslatingSrt = MutableStateFlow(false)
    val isTranslatingSrt: StateFlow<Boolean> = _isTranslatingSrt.asStateFlow()

    // ---------------- Thumbnail Generator State ----------------
    var thumbnailPrompt = MutableStateFlow("Cyberpunk detective in rain with neon purple glow, looking at holographic clues")
    var thumbnailAspectRatio = MutableStateFlow("16:9")
    var thumbnailTitleText = MutableStateFlow("မထင်မှတ်ထားတဲ့ ဇာတ်သိမ်း!")
    var thumbnailVisualStyle = MutableStateFlow("Cyber Neon")

    private val _isGeneratingThumbnail = MutableStateFlow(false)
    val isGeneratingThumbnail: StateFlow<Boolean> = _isGeneratingThumbnail.asStateFlow()

    // ---------------- Titles & Tags State ----------------
    var titleTopicInput = MutableStateFlow("Sci-Fi Mystery Movie Recap with Cyber Sentinels")
    var titleLang = MutableStateFlow("Myanmar")

    private val _generatedTitlesTags = MutableStateFlow<GeneratedTitlesAndTags?>(null)
    val generatedTitlesTags: StateFlow<GeneratedTitlesAndTags?> = _generatedTitlesTags.asStateFlow()

    private val _isGeneratingTitles = MutableStateFlow(false)
    val isGeneratingTitles: StateFlow<Boolean> = _isGeneratingTitles.asStateFlow()

    // ---------------- Projects State ----------------
    var projectSearchQuery = MutableStateFlow("")
    var projectFilter = MutableStateFlow("All")
    val allProjects = repository.allProjects

    init {
        viewModelScope.launch {
            repository.seedSampleProjectsIfEmpty()
            parseCurrentSrt()
        }
    }

    fun setLanguage(lang: NexoraLanguage) {
        _currentLanguage.value = lang
        if (lang == NexoraLanguage.MYANMAR) {
            selectedTtsLanguage.value = SupportedTtsLanguages.BURMESE
            selectMyanmarVoiceStyle(MyanmarVoiceStyle.MALE_VOICE)
        }
    }

    fun navigateTo(dest: NexoraNavDestination) {
        _currentDestination.value = dest
    }

    fun showToast(msg: String) {
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    fun copyToClipboard(text: String, label: String = "NEXORA AI") {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        showToast("Copied to clipboard!")
    }

    // ---------------- Myanmar Video Recap Actions ----------------
    fun startMyanmarVideoRecap() {
        if (recapInput.value.isBlank()) {
            showToast("Please enter story content or upload a video!")
            return
        }

        viewModelScope.launch {
            _isRecapProcessing.value = true
            _recapProgress.value = 0f
            try {
                val result = repository.generateMyanmarVideoRecap(
                    inputContent = recapInput.value,
                    mode = selectedRecapMode.value,
                    chunkCount = recapChunkCount.value,
                    onProgress = { progress, text ->
                        _recapProgress.value = progress
                        _recapProgressText.value = text
                    }
                )
                _currentMyanmarRecap.value = result
                showToast("Myanmar Video Recap (${result.mode.badge}) Ready!")
            } catch (e: Exception) {
                showToast("Recap failed: ${e.message}")
            } finally {
                _isRecapProcessing.value = false
            }
        }
    }

    // Myanmar Unicode Script Editing
    fun updateSceneNarratorScript(sceneNumber: Int, newScript: String) {
        val current = _currentMyanmarRecap.value ?: return
        val updatedScenes = current.scenes.map { scene ->
            if (scene.sceneNumber == sceneNumber) scene.copy(narratorScript = newScript) else scene
        }
        val newSrt = repository.generateSrtFromScenes(updatedScenes)
        _currentMyanmarRecap.value = current.copy(
            scenes = updatedScenes,
            fullSynchronizedSrt = newSrt
        )
    }

    fun updateSceneDramaticCue(sceneNumber: Int, newCue: String) {
        val current = _currentMyanmarRecap.value ?: return
        val updatedScenes = current.scenes.map { scene ->
            if (scene.sceneNumber == sceneNumber) scene.copy(dramaticCue = newCue) else scene
        }
        _currentMyanmarRecap.value = current.copy(scenes = updatedScenes)
    }

    fun updateCharacterDialogue(sceneNumber: Int, dialogueId: String, newText: String) {
        val current = _currentMyanmarRecap.value ?: return
        val updatedScenes = current.scenes.map { scene ->
            if (scene.sceneNumber == sceneNumber) {
                val updatedDialogues = scene.dialogues.map { d ->
                    if (d.id == dialogueId) d.copy(myanmarDialogue = newText) else d
                }
                scene.copy(dialogues = updatedDialogues)
            } else {
                scene
            }
        }
        val newSrt = repository.generateSrtFromScenes(updatedScenes)
        _currentMyanmarRecap.value = current.copy(
            scenes = updatedScenes,
            fullSynchronizedSrt = newSrt
        )
    }

    // Burmese TTS Audio Playback (Strictly No English Fallback)
    fun playBurmeseNarration(text: String, speed: Float = 1.0f, pitch: Float = 1.0f, voiceName: String? = null) {
        if (ttsManager.isPlaying.value) {
            ttsManager.stop()
            return
        }

        viewModelScope.launch {
            val personalProfile = repository.activePersonalVoice.value
            val isPersonal = (voiceName != null && personalProfile?.id == voiceName) ||
                             (voiceName == null && selectedRecapVoice.value == personalProfile?.id)

            if (isPersonal && personalProfile != null) {
                val refFile = File(personalProfile.audioSamplePath)
                val res = ttsManager.synthesizeWithVoiceCloning(
                    text = text,
                    referenceAudioFile = refFile,
                    language = "my",
                    speed = personalProfile.speed * speed,
                    pitch = personalProfile.pitch * pitch
                )
                if (res.isSuccess) {
                    val f = res.getOrNull()
                    if (f != null && f.exists()) {
                        ttsManager.playAudioFile(f)
                        showToast("Playing Recap Narration with ${personalProfile.name}")
                        return@launch
                    }
                }
            }

            // Normal synthesis with selected voice
            val effectiveVoice = voiceName ?: selectedRecapVoice.value
            val synthRes = ttsManager.synthesizeBurmeseSpeech(
                text = text,
                voiceName = effectiveVoice,
                speed = speed,
                pitch = pitch
            )
            if (synthRes.isSuccess) {
                val f = synthRes.getOrNull()
                if (f != null && f.exists()) {
                    ttsManager.playAudioFile(f)
                    showToast("Playing Burmese Narration Audio")
                    return@launch
                }
            }

            // Fallback to local TTS
            val localRes = ttsManager.speakBurmese(text, speed, pitch, effectiveVoice)
            if (localRes.isFailure) {
                ttsErrorMessage.value = localRes.exceptionOrNull()?.message ?: "Burmese audio synthesis failed."
                showTtsInstallDialog.value = true
            }
        }
    }

    fun stopAudio() {
        ttsManager.stop()
    }

    // Export Narration Audio (Validates Burmese TTS Backend)
    fun exportNarrationAudio(context: Context) {
        val current = _currentMyanmarRecap.value
        if (current == null) {
            showToast("No recap generated to export audio.")
            return
        }

        val textToSynthesize = when (current.mode) {
            MyanmarRecapMode.NARRATOR_RECAP,
            MyanmarRecapMode.CINEMATIC_RECAP -> current.scenes.joinToString("\n\n") { it.narratorScript }
            MyanmarRecapMode.SHORT_VIRAL_RECAP -> {
                val hook = if (current.viralHook.isNotBlank()) "${current.viralHook}\n\n" else ""
                hook + current.scenes.joinToString("\n\n") { it.narratorScript }
            }
            MyanmarRecapMode.DIALOGUE_RECAP -> current.scenes.joinToString("\n\n") { s ->
                s.dialogues.joinToString("\n") { "${it.speakerName}: ${it.myanmarDialogue}" }
            }
            MyanmarRecapMode.FULL_RECAP -> current.fullNarrationText
        }

        viewModelScope.launch {
            val personalProfile = repository.activePersonalVoice.value
            val isPersonal = selectedRecapVoice.value == personalProfile?.id

            val audioFile: File? = if (isPersonal && personalProfile != null) {
                val ref = File(personalProfile.audioSamplePath)
                val res = ttsManager.synthesizeWithVoiceCloning(
                    text = textToSynthesize,
                    referenceAudioFile = ref,
                    speed = personalProfile.speed,
                    pitch = personalProfile.pitch
                )
                res.getOrNull()
            } else {
                val res = ttsManager.synthesizeBurmeseSpeech(
                    text = textToSynthesize,
                    voiceName = selectedRecapVoice.value,
                    speed = 1.0f,
                    pitch = 1.0f
                )
                res.getOrNull()
            }

            if (audioFile != null && audioFile.exists() && audioFile.length() > 0) {
                try {
                    val uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        audioFile
                    )
                    val mimeType = if (audioFile.name.endsWith(".mp3", ignoreCase = true)) "audio/mpeg" else "audio/wav"
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = mimeType
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "NEXORA AI Burmese Recap Audio (${current.mode.titleEn})")
                        putExtra(Intent.EXTRA_TEXT, "Generated with NEXORA AI Myanmar Video Recap Studio:\n\n$textToSynthesize")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Download / Export Recap Audio"))
                    showToast("Audio file exported (${audioFile.name})!")
                } catch (e: Exception) {
                    showToast("Export error: ${e.message}")
                }
            } else {
                showToast("Could not synthesize audio for export.")
            }
        }
    }

    // Export Synchronized Myanmar SRT Subtitles
    fun exportMyanmarSrt(context: Context) {
        val current = _currentMyanmarRecap.value
        if (current == null) {
            showToast("No recap generated to export SRT.")
            return
        }

        val srtContent = current.fullSynchronizedSrt
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${current.title} - Myanmar Subtitles.srt")
            putExtra(Intent.EXTRA_TEXT, srtContent)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Export Synchronized Myanmar SRT"))
        showToast("Synchronized SRT exported!")
    }

    fun openTtsSettings(context: Context) {
        ttsManager.openTtsSettings(context)
        showTtsInstallDialog.value = false
    }

    fun sendRecapScriptToVoice() {
        val recap = _currentMyanmarRecap.value
        val script = recap?.fullNarrationText
        if (!script.isNullOrBlank()) {
            voiceScriptText.value = script
            when (recap.mode) {
                MyanmarRecapMode.NARRATOR_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.STORYTELLER)
                MyanmarRecapMode.DIALOGUE_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.MALE_VOICE)
                MyanmarRecapMode.FULL_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.STORYTELLER)
                MyanmarRecapMode.CINEMATIC_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.CINEMATIC)
                MyanmarRecapMode.SHORT_VIRAL_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.EXCITING_VOICE)
            }
            navigateTo(NexoraNavDestination.VOICE)
            showToast("Recap script loaded in Voice Studio (${selectedVoiceStyle.value.badge})!")
        }
    }

    fun loadFromRecapMode(mode: MyanmarRecapMode) {
        val recap = _currentMyanmarRecap.value
        val script = if (recap != null && recap.mode == mode) {
            recap.fullNarrationText
        } else {
            mode.previewSample
        }
        voiceScriptText.value = script
        when (mode) {
            MyanmarRecapMode.NARRATOR_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.STORYTELLER)
            MyanmarRecapMode.DIALOGUE_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.MALE_VOICE)
            MyanmarRecapMode.FULL_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.STORYTELLER)
            MyanmarRecapMode.CINEMATIC_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.CINEMATIC)
            MyanmarRecapMode.SHORT_VIRAL_RECAP -> selectMyanmarVoiceStyle(MyanmarVoiceStyle.EXCITING_VOICE)
        }
        showToast("${mode.titleEn} script loaded in Voice Studio!")
    }

    // ---------------- Translation Actions ----------------
    fun executeTranslation() {
        val text = translateSourceText.value
        if (text.isBlank()) {
            showToast("Please enter text to translate!")
            return
        }

        viewModelScope.launch {
            _isTranslating.value = true
            try {
                val res = repository.translateText(
                    text = text,
                    sourceLang = translateSourceLang.value,
                    targetLang = translateTargetLang.value,
                    style = translateStyle.value
                )
                _translatedResult.value = res
            } catch (e: Exception) {
                showToast("Translation error: ${e.message}")
            } finally {
                _isTranslating.value = false
            }
        }
    }

    fun swapTranslationLanguages() {
        val temp = translateSourceLang.value
        translateSourceLang.value = translateTargetLang.value
        translateTargetLang.value = temp
        val currentResult = _translatedResult.value
        if (currentResult.isNotBlank()) {
            translateSourceText.value = currentResult
            _translatedResult.value = ""
        }
    }

    // ---------------- Voice Studio Actions ----------------
    fun selectTtsLanguage(lang: TtsLanguage) {
        selectedTtsLanguage.value = lang
        if (lang.isBurmese) {
            selectedBaseVoiceId.value = if (selectedGenderVoice.value == "Male") AzureBurmeseVoices.MALE_THIHA else AzureBurmeseVoices.FEMALE_NILAR
            selectMyanmarVoiceStyle(if (selectedGenderVoice.value == "Male") MyanmarVoiceStyle.MALE_VOICE else MyanmarVoiceStyle.FEMALE_VOICE)
        } else {
            selectedBaseVoiceId.value = if (selectedGenderVoice.value == "Male") lang.maleVoice else lang.femaleVoice
        }
        ttsManager.checkBurmeseSupport()
    }

    fun selectGenderVoice(gender: String) {
        selectedGenderVoice.value = gender
        val lang = selectedTtsLanguage.value
        selectedBaseVoiceId.value = if (gender == "Male") lang.maleVoice else lang.femaleVoice
        if (lang.isBurmese) {
            if (gender == "Male") {
                selectMyanmarVoiceStyle(MyanmarVoiceStyle.MALE_VOICE)
            } else {
                selectMyanmarVoiceStyle(MyanmarVoiceStyle.FEMALE_VOICE)
            }
        }
    }

    fun selectMyanmarVoiceStyle(style: MyanmarVoiceStyle) {
        selectedVoiceStyle.value = style
        selectedBaseVoiceId.value = style.baseVoiceId
        voiceSpeed.value = style.defaultSpeed
        voicePitch.value = style.defaultPitch
        voiceVolume.value = style.defaultVolume
        ttsManager.setVolume(style.defaultVolume)
    }

    fun updateVoiceVolume(volume: Float) {
        voiceVolume.value = volume
        ttsManager.setVolume(volume)
    }

    fun playVoiceStylePreview(style: MyanmarVoiceStyle, baseVoiceId: String? = null) {
        if (ttsManager.isPlaying.value) {
            ttsManager.stop()
            return
        }

        val voice = baseVoiceId ?: style.baseVoiceId
        viewModelScope.launch {
            // 1. Try Azure Speech synthesis if configured
            if (ttsManager.isAzureConfigured) {
                val azureResult = ttsManager.synthesizeWithAzureSpeech(
                    text = style.previewSample,
                    voiceName = voice,
                    speed = style.defaultSpeed,
                    pitch = style.defaultPitch,
                    volume = style.defaultVolume
                )

                if (azureResult.isSuccess) {
                    val file = azureResult.getOrNull()
                    if (file != null && file.exists()) {
                        ttsManager.playAudioFile(file)
                        showToast("Playing Azure ${style.titleEn} Preview (${style.badge})")
                        return@launch
                    }
                }
            }

            // 2. Try Self-Hosted Myanmar TTS Backend if configured
            if (ttsManager.isSelfHostedConfigured) {
                val selfHostedResult = ttsManager.synthesizeWithSelfHostedBackend(
                    text = style.previewSample,
                    voiceName = voice,
                    speed = style.defaultSpeed,
                    pitch = style.defaultPitch,
                    volume = style.defaultVolume
                )

                if (selfHostedResult.isSuccess) {
                    val file = selfHostedResult.getOrNull()
                    if (file != null && file.exists()) {
                        ttsManager.playAudioFile(file)
                        showToast("Playing Self-Hosted ${style.titleEn} Preview (${style.badge})")
                        return@launch
                    }
                }
            }

            // 3. Built-in Real Burmese Cloud TTS Engine (my-MM / Myanmar Unicode)
            val realRes = ttsManager.synthesizeBurmeseSpeech(
                text = style.previewSample,
                voiceName = voice,
                speed = style.defaultSpeed,
                pitch = style.defaultPitch,
                volume = style.defaultVolume
            )
            if (realRes.isSuccess) {
                val file = realRes.getOrNull()
                if (file != null && file.exists()) {
                    ttsManager.playAudioFile(file)
                    showToast("Playing ${style.titleEn} Preview (${style.badge})")
                    return@launch
                }
            }

            // 4. Fallback to local Burmese TTS if available
            val localRes = ttsManager.speakBurmese(
                text = style.previewSample,
                speed = style.defaultSpeed,
                pitch = style.defaultPitch,
                voiceName = voice,
                volume = style.defaultVolume
            )

            if (localRes.isFailure) {
                ttsErrorMessage.value = ttsManager.getMissingConfigurationError()
                showTtsInstallDialog.value = true
            } else {
                showToast("Playing ${style.titleEn} Preview (${style.badge})")
            }
        }
    }

    fun playVoicePreview() {
        if (ttsManager.isPlaying.value) {
            ttsManager.stop()
            return
        }

        val text = voiceScriptText.value
        if (text.isBlank()) {
            showToast("Please enter narration text to synthesize.")
            return
        }

        val style = selectedVoiceStyle.value
        val voice = selectedBaseVoiceId.value
        val activePersonal = repository.activePersonalVoice.value

        viewModelScope.launch {
            isVoiceGenerating.value = true
            try {
                // If personal voice is selected for preview
                if (activePersonal != null && voice == activePersonal.id) {
                    val refFile = File(activePersonal.audioSamplePath)
                    val cloneRes = ttsManager.synthesizeWithVoiceCloning(
                        text = text,
                        referenceAudioFile = refFile,
                        language = "my",
                        speed = voiceSpeed.value,
                        pitch = voicePitch.value
                    )
                    if (cloneRes.isSuccess) {
                        val file = cloneRes.getOrNull()
                        if (file != null && file.exists()) {
                            ttsManager.playAudioFile(file)
                            showToast("Playing Personal Cloned Voice: ${activePersonal.name}")
                            return@launch
                        }
                    }
                }

                // Unified Burmese speech synthesis (Azure -> SelfHosted -> Real Burmese Cloud TTS)
                val synthRes = ttsManager.synthesizeBurmeseSpeech(
                    text = text,
                    voiceName = voice,
                    speed = voiceSpeed.value,
                    pitch = voicePitch.value,
                    volume = voiceVolume.value
                )

                if (synthRes.isSuccess) {
                    val file = synthRes.getOrNull()
                    if (file != null && file.exists()) {
                        ttsManager.playAudioFile(file)
                        showToast("Burmese Speech Generated & Playing (${style.badge})")
                        return@launch
                    }
                }

                // Fallback to local Burmese TTS
                val localRes = ttsManager.speakBurmese(
                    text = text,
                    speed = voiceSpeed.value,
                    pitch = voicePitch.value,
                    voiceName = voice,
                    volume = voiceVolume.value
                )

                if (localRes.isFailure) {
                    ttsErrorMessage.value = localRes.exceptionOrNull()?.message ?: ttsManager.getMissingConfigurationError()
                    showTtsInstallDialog.value = true
                } else {
                    showToast("Playing Burmese Speech (${style.badge})")
                }
            } finally {
                isVoiceGenerating.value = false
            }
        }
    }

    fun stopVoice() {
        ttsManager.stop()
    }

    fun playSampleVoice(profile: VoiceProfile) {
        if (profile.language.contains("Myanmar", ignoreCase = true)) {
            val res = ttsManager.speakBurmese(profile.sampleText, 1.0f, 1.0f, profile.id, 1.0f)
            if (res.isFailure) {
                ttsErrorMessage.value = res.exceptionOrNull()?.message ?: "Burmese TTS engine not found."
                showTtsInstallDialog.value = true
            }
        } else {
            ttsManager.speak(profile.sampleText, 1.0f, 1.0f, profile.id)
        }
    }

    fun downloadOrExportAudio(context: Context) {
        val lastFile = lastGeneratedAudioFile.value
        val text = voiceScriptText.value

        if (text.isBlank()) {
            showToast("Enter a script to generate and export audio.")
            return
        }

        viewModelScope.launch {
            val personalProfile = repository.activePersonalVoice.value
            val isPersonal = selectedBaseVoiceId.value == personalProfile?.id

            val audioFile: File? = if (lastFile != null && lastFile.exists() && lastFile.length() > 0) {
                lastFile
            } else if (isPersonal && personalProfile != null) {
                val ref = File(personalProfile.audioSamplePath)
                val res = ttsManager.synthesizeWithVoiceCloning(
                    text = text,
                    referenceAudioFile = ref,
                    speed = voiceSpeed.value,
                    pitch = voicePitch.value
                )
                res.getOrNull()
            } else {
                val res = ttsManager.synthesizeBurmeseSpeech(
                    text = text,
                    voiceName = selectedBaseVoiceId.value,
                    speed = voiceSpeed.value,
                    pitch = voicePitch.value,
                    volume = voiceVolume.value
                )
                res.getOrNull()
            }

            if (audioFile != null && audioFile.exists() && audioFile.length() > 0) {
                try {
                    val uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        audioFile
                    )
                    val mimeType = if (audioFile.name.endsWith(".mp3", ignoreCase = true)) "audio/mpeg" else "audio/wav"
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = mimeType
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "NEXORA AI Burmese Audio (${selectedVoiceStyle.value.titleEn})")
                        putExtra(Intent.EXTRA_TEXT, "Generated with NEXORA AI Voice Studio:\n\n$text")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Download / Share Audio File"))
                    showToast("Audio exported (${audioFile.name})!")
                } catch (e: Exception) {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "NEXORA AI Burmese Narration Script")
                        putExtra(Intent.EXTRA_TEXT, "NEXORA AI Voice Script (${selectedVoiceStyle.value.titleEn}):\n\n$text")
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Narration Script"))
                    showToast("Narration script exported!")
                }
            } else {
                showToast("Could not synthesize audio for export.")
            }
        }
    }

    // ---------------- Personal Voice Actions ----------------
    fun startVoiceRecording(): Result<File> {
        val res = voiceRecorder.startRecording()
        if (res.isSuccess) {
            showToast("Recording started. Please speak into the microphone.")
        } else {
            showToast("Failed to start recording: ${res.exceptionOrNull()?.message}")
        }
        return res
    }

    fun stopVoiceRecording(): Result<File> {
        val res = voiceRecorder.stopRecording()
        if (res.isSuccess) {
            showToast("Recording saved (${voiceRecorder.durationSeconds.value}s)!")
        } else {
            showToast("Error stopping recording: ${res.exceptionOrNull()?.message}")
        }
        return res
    }

    fun playRecordedSample() {
        val res = voiceRecorder.playRecordedSample()
        if (res.isFailure) {
            showToast("Playback error: ${res.exceptionOrNull()?.message}")
        }
    }

    fun stopRecordedSample() {
        voiceRecorder.stopPlayingRecording()
    }

    fun cancelVoiceRecording() {
        voiceRecorder.cancelRecording()
        showToast("Recording cancelled")
    }

    fun createPersonalVoiceProfile(
        name: String,
        pitch: Float = 1.0f,
        speed: Float = 1.0f,
        baseGender: String = "Male"
    ) {
        val file = voiceRecorder.recordedFile.value
        if (file == null || !file.exists()) {
            showToast("Please record a voice sample first!")
            return
        }
        if (name.isBlank()) {
            showToast("Please enter a voice profile name!")
            return
        }

        val baseVoice = if (baseGender.equals("Female", ignoreCase = true)) {
            AzureBurmeseVoices.FEMALE_NILAR
        } else {
            AzureBurmeseVoices.MALE_THIHA
        }

        val profile = PersonalVoiceProfile(
            name = name.trim(),
            audioSamplePath = file.absolutePath,
            durationSeconds = voiceRecorder.durationSeconds.value.coerceAtLeast(3),
            pitch = pitch,
            speed = speed,
            baseVoiceId = baseVoice
        )

        repository.savePersonalVoice(profile)
        selectedBaseVoiceId.value = profile.id
        selectedRecapVoice.value = profile.id
        voiceRecorder.clearRecording()
        showToast("Personal Voice Profile '$name' created successfully!")
    }

    fun deletePersonalVoiceProfile(id: String) {
        repository.deletePersonalVoice(id)
        if (selectedRecapVoice.value == id) {
            selectedRecapVoice.value = AzureBurmeseVoices.MALE_THIHA
        }
        showToast("Personal Voice Profile deleted")
    }

    fun selectPersonalVoiceProfile(profile: PersonalVoiceProfile?) {
        repository.setActivePersonalVoice(profile)
        if (profile != null) {
            selectedBaseVoiceId.value = profile.id
            selectedRecapVoice.value = profile.id
            voicePitch.value = profile.pitch
            voiceSpeed.value = profile.speed
            showToast("Selected Personal Voice: ${profile.name}")
        } else {
            selectedBaseVoiceId.value = AzureBurmeseVoices.MALE_THIHA
            selectedRecapVoice.value = AzureBurmeseVoices.MALE_THIHA
        }
    }

    fun previewPersonalVoice(profile: PersonalVoiceProfile) {
        if (ttsManager.isPlaying.value) {
            ttsManager.stop()
            return
        }

        viewModelScope.launch {
            isVoiceGenerating.value = true
            try {
                val refFile = File(profile.audioSamplePath)
                val res = ttsManager.synthesizeWithVoiceCloning(
                    text = profile.sampleText,
                    referenceAudioFile = refFile,
                    language = "my",
                    speed = profile.speed,
                    pitch = profile.pitch
                )
                if (res.isSuccess) {
                    val file = res.getOrNull()
                    if (file != null && file.exists()) {
                        ttsManager.playAudioFile(file)
                        showToast("Playing Personal Cloned Voice: ${profile.name}")
                    }
                } else {
                    showToast("Error generating preview: ${res.exceptionOrNull()?.message}")
                }
            } finally {
                isVoiceGenerating.value = false
            }
        }
    }

    // ---------------- SRT Studio Actions ----------------
    fun parseCurrentSrt() {
        _srtSegments.value = repository.parseSrt(srtRawInput.value)
    }

    fun translateSubtitles() {
        viewModelScope.launch {
            _isTranslatingSrt.value = true
            try {
                val translated = repository.translateSubtitlesToMyanmar(_srtSegments.value)
                _srtSegments.value = translated
                showToast("All subtitles translated to Myanmar!")
            } catch (e: Exception) {
                showToast("Error: ${e.message}")
            } finally {
                _isTranslatingSrt.value = false
            }
        }
    }

    fun updateSegmentText(index: Int, newText: String) {
        val list = _srtSegments.value.toMutableList()
        val itemIndex = list.indexOfFirst { it.index == index }
        if (itemIndex != -1) {
            list[itemIndex] = list[itemIndex].copy(translatedText = newText)
            _srtSegments.value = list
        }
    }

    fun exportSrtContent(): String {
        return repository.exportToSrt(_srtSegments.value)
    }

    fun exportTxtContent(): String {
        return repository.exportToTxt(_srtSegments.value)
    }

    // ---------------- Thumbnail Actions ----------------
    fun generateThumbnail() {
        viewModelScope.launch {
            _isGeneratingThumbnail.value = true
            kotlinx.coroutines.delay(800)
            _isGeneratingThumbnail.value = false
            showToast("Thumbnail rendered with custom title overlay!")
        }
    }

    // ---------------- Titles & Tags Actions ----------------
    fun generateTitlesAndTags() {
        val topic = titleTopicInput.value
        if (topic.isBlank()) {
            showToast("Please enter a video topic!")
            return
        }

        viewModelScope.launch {
            _isGeneratingTitles.value = true
            try {
                val res = repository.generateTitlesAndTags(topic, titleLang.value)
                _generatedTitlesTags.value = res
                showToast("Titles and Hashtags generated!")
            } catch (e: Exception) {
                showToast("Error: ${e.message}")
            } finally {
                _isGeneratingTitles.value = false
            }
        }
    }

    // ---------------- Project Actions ----------------
    fun deleteProject(id: String) {
        viewModelScope.launch {
            repository.deleteProject(id)
            showToast("Project deleted")
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceRecorder.release()
        ttsManager.shutdown()
    }
}
