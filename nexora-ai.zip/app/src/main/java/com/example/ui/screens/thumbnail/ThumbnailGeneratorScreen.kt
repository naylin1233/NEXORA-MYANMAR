package com.example.ui.screens.thumbnail

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowingButton
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurpleDark
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraPurpleVioletGradient
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun ThumbnailGeneratorScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings by viewModel.strings.collectAsState()
    val isGenerating by viewModel.isGeneratingThumbnail.collectAsState()

    var prompt by remember { mutableStateOf(viewModel.thumbnailPrompt.value) }
    var titleOverlay by remember { mutableStateOf(viewModel.thumbnailTitleText.value) }
    var selectedRatio by remember { mutableStateOf(viewModel.thumbnailAspectRatio.value) }
    var selectedStyle by remember { mutableStateOf(viewModel.thumbnailVisualStyle.value) }

    val styles = listOf("Cyber Neon", "Cinematic Film", "High-CTR Bold", "Anime Thriller")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraPurplePrimary.copy(alpha = 0.2f))
                        .border(1.dp, NexoraPurplePrimary, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = NexoraNeonViolet,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = strings.thumbnailTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = strings.thumbnailSubtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary
                        )
                    )
                }
            }
        }

        // Live Graphic Thumbnail Canvas Preview
        item {
            Text(
                text = "Live Canvas Preview",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )
            Spacer(modifier = Modifier.height(8.dp))

            val aspectValue = if (selectedRatio == "16:9") 16f / 9f else 9f / 16f
            val previewHeight = if (selectedRatio == "16:9") 200.dp else 280.dp

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(previewHeight)
                    .clip(RoundedCornerShape(16.dp))
                    .border(2.dp, NexoraNeonViolet.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                    .testTag("thumbnail_preview_canvas")
            ) {
                // Background art
                Image(
                    painter = painterResource(id = R.drawable.img_nexora_hero),
                    contentDescription = "Thumbnail Background",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Atmospheric Gradient Tint
                val tintGradient = when (selectedStyle) {
                    "Cyber Neon" -> Brush.verticalGradient(listOf(Color(0x6606B6D4), Color(0xBB7C3AED)))
                    "Cinematic Film" -> Brush.verticalGradient(listOf(Color(0x44000000), Color(0xDD0D0F1D)))
                    "High-CTR Bold" -> Brush.verticalGradient(listOf(Color(0x66EF4444), Color(0xBB7C3AED)))
                    else -> Brush.verticalGradient(listOf(Color(0x558B5CF6), Color(0xCC000000)))
                }

                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(tintGradient)
                )

                // Top Badge
                Box(
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopStart)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Red)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "NEW RECAP",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    )
                }

                // Title Overlay Text
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .align(Alignment.BottomCenter),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexoraDeepBlack.copy(alpha = 0.85f))
                            .border(1.dp, NexoraNeonViolet, RoundedCornerShape(8.dp))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = if (titleOverlay.isNotBlank()) titleOverlay else "NEXORA AI RECAP",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = NexoraCyanAccent,
                                textAlign = TextAlign.Center
                            ),
                            maxLines = 2
                        )
                    }
                }
            }
        }

        // Ratio Selector (16:9 vs 9:16)
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = strings.aspectFormat,
                        style = MaterialTheme.typography.labelMedium.copy(color = NexoraTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        RatioButton(
                            label = strings.formatYoutube,
                            isSelected = selectedRatio == "16:9",
                            onClick = {
                                selectedRatio = "16:9"
                                viewModel.thumbnailAspectRatio.value = "16:9"
                            },
                            modifier = Modifier.weight(1f)
                        )
                        RatioButton(
                            label = strings.formatTiktok,
                            isSelected = selectedRatio == "9:16",
                            onClick = {
                                selectedRatio = "9:16"
                                viewModel.thumbnailAspectRatio.value = "9:16"
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Overlay Title Text Field
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = strings.overlayTitleText,
                        style = MaterialTheme.typography.labelMedium.copy(color = NexoraTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = titleOverlay,
                        onValueChange = {
                            titleOverlay = it
                            viewModel.thumbnailTitleText.value = it
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("thumbnail_overlay_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoraSurfaceElevated,
                            unfocusedContainerColor = NexoraSurfaceDark,
                            focusedBorderColor = NexoraPurplePrimary,
                            unfocusedBorderColor = NexoraBorderGlass,
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary
                        )
                    )
                }
            }
        }

        // Prompt Description Input
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Image Generation Prompt",
                        style = MaterialTheme.typography.labelMedium.copy(color = NexoraTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = {
                            prompt = it
                            viewModel.thumbnailPrompt.value = it
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .testTag("thumbnail_prompt_input"),
                        placeholder = {
                            Text(
                                strings.promptPlaceholder,
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoraSurfaceElevated,
                            unfocusedContainerColor = NexoraSurfaceDark,
                            focusedBorderColor = NexoraPurplePrimary,
                            unfocusedBorderColor = NexoraBorderGlass,
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary
                        )
                    )
                }
            }
        }

        // Aesthetic Style Chips
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = strings.visualStyle,
                        style = MaterialTheme.typography.labelMedium.copy(color = NexoraTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        styles.forEach { s ->
                            val isSel = selectedStyle == s
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) NexoraPurplePrimary else NexoraSurfaceElevated)
                                    .border(1.dp, if (isSel) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedStyle = s
                                        viewModel.thumbnailVisualStyle.value = s
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = s,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSel) NexoraTextPrimary else NexoraTextSecondary,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Generate & Download Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GlowingButton(
                    text = if (isGenerating) "Generating..." else strings.generateThumbnailBtn,
                    icon = Icons.Default.AutoAwesome,
                    enabled = !isGenerating,
                    onClick = { viewModel.generateThumbnail() },
                    modifier = Modifier.weight(1f),
                    testTag = "generate_thumbnail_btn"
                )
                SecondaryGlowingButton(
                    text = strings.downloadThumbnail,
                    icon = Icons.Default.FileDownload,
                    onClick = {
                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "NEXORA AI Thumbnail: $titleOverlay\nStyle: $selectedStyle\nRatio: $selectedRatio")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Save/Share Thumbnail"))
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "download_thumbnail_btn"
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}

@Composable
private fun RatioButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) NexoraPurplePrimary.copy(alpha = 0.25f) else NexoraSurfaceDark)
            .border(1.dp, if (isSelected) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) NexoraCyanAccent else NexoraTextSecondary
            )
        )
    }
}
