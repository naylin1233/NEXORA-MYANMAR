package com.example.ui.screens.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.LanguageSelectorChip
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.components.StatusBadge
import com.example.ui.localization.NexoraLanguage
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraEmeraldAccent
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun SettingsScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val strings by viewModel.strings.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()
    val isApiConfigured = viewModel.isApiConfigured()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraPurplePrimary.copy(alpha = 0.2f))
                        .border(1.dp, NexoraPurplePrimary, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = NexoraNeonViolet,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = strings.settingsTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = "Customize language, AI connection, and workspace preferences",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary
                        )
                    )
                }
            }
        }

        // Language Switch Card
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = NexoraCyanAccent,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = strings.appLanguage,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                            Text(
                                text = "English / မြန်မာဘာသာ သတ်မှတ်မည်",
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary)
                            )
                        }
                    }

                    LanguageSelectorChip(
                        currentLanguage = currentLang,
                        onLanguageSelected = { viewModel.setLanguage(it) },
                        modifier = Modifier.testTag("settings_lang_toggle")
                    )
                }
            }
        }

        // Account Profile Card
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(NexoraPurplePrimary.copy(alpha = 0.3f))
                            .border(1.5.dp, NexoraNeonViolet, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = NexoraTextPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Nay",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            StatusBadge(status = "PRO AI", isSuccess = true)
                        }
                        Text(
                            text = "nay577770@gmail.com",
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary)
                        )
                    }
                }
            }
        }

        // AI Engine Configuration Guide
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = null,
                                tint = NexoraNeonViolet,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = strings.geminiApiStatus,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                        }
                        StatusBadge(
                            status = if (isApiConfigured) "Connected" else "Offline Preview",
                            isSuccess = isApiConfigured
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isApiConfigured) {
                            "Gemini 2.5 Flash API is connected via server-side Secrets. Live multimodal video analysis and real-time translations are operational."
                        } else {
                            strings.apiInstruction
                        },
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary,
                            lineHeight = 20.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SecondaryGlowingButton(
                        text = "Check Connection Status",
                        icon = Icons.Default.CheckCircle,
                        onClick = {
                            if (isApiConfigured) {
                                viewModel.showToast("Gemini 2.5 Flash API connected successfully!")
                            } else {
                                viewModel.showToast("GEMINI_API_KEY placeholder detected. Running in offline template mode.")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "check_api_btn"
                    )
                }
            }
        }

        // About NEXORA AI
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_nexora_logo),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = strings.appName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = NexoraTextPrimary
                                )
                            )
                            Text(
                                text = strings.tagline,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NexoraNeonViolet,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "NEXORA AI is an end-to-end creative suite engineered for creators, translators, and storytellers. Featuring automated video recap breakdown, natural Myanmar translation, text-to-speech dubbing, synchronized SRT studio, and viral thumbnail generation.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary,
                            lineHeight = 20.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = NexoraBorderSubtle, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Release Build",
                            style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                        )
                        Text(
                            text = strings.version,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NexoraTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Privacy Policy Card
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = NexoraEmeraldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.privacyPolicy,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your projects and generated files are stored securely on your device and via secure server-side proxy. No personal API keys or credentials are leaked in client code.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary,
                            lineHeight = 18.sp
                        )
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}
