package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// NEXORA AI Core Brand Colors
val NexoraDeepBlack = Color(0xFF07070B)
val NexoraDarkNavy = Color(0xFF0D0F1D)
val NexoraSurfaceDark = Color(0xFF131629)
val NexoraSurfaceElevated = Color(0xFF1A1E38)
val NexoraSurfaceGlass = Color(0xDD181B34)
val NexoraBorderGlass = Color(0x33A855F7)
val NexoraBorderSubtle = Color(0x22FFFFFF)

// Purple and Violet Accents
val NexoraPurplePrimary = Color(0xFF8B5CF6)
val NexoraPurpleDark = Color(0xFF6D28D9)
val NexoraElectricViolet = Color(0xFFA855F7)
val NexoraNeonViolet = Color(0xFFC084FC)
val NexoraGlowMagenta = Color(0xFFE879F9)
val NexoraCyanAccent = Color(0xFF38BDF8)
val NexoraEmeraldAccent = Color(0xFF10B981)
val NexoraAmberAccent = Color(0xFFF59E0B)
val NexoraRedAccent = Color(0xFFEF4444)

// Text Colors
val NexoraTextPrimary = Color(0xFFF8FAFC)
val NexoraTextSecondary = Color(0xFF94A3B8)
val NexoraTextMuted = Color(0xFF64748B)

// Gradients
val NexoraPurpleVioletGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF7C3AED), Color(0xFFA855F7), Color(0xFFC084FC))
)

val NexoraHeroGradient = Brush.verticalGradient(
    colors = listOf(Color(0xEE161938), Color(0xFF0B0D1B))
)

val NexoraCyberGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF7C3AED), Color(0xFF06B6D4))
)

val NexoraGlassGradient = Brush.verticalGradient(
    colors = listOf(Color(0x33A855F7), Color(0x110F1123))
)
