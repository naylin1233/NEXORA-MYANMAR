package com.example.ui.screens.voice

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AzureBurmeseVoices
import com.example.data.model.MyanmarRecapMode
import com.example.data.model.MyanmarVoiceStyle
import com.example.data.model.TtsLanguage
import com.example.ui.components.AudioWaveformVisualizer
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowingButton
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraAmberAccent
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraEmeraldAccent
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun VoiceStudioScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings by viewModel.strings.collectAsState()
    val isPlaying by viewModel.isVoicePlaying.collectAsState()
    val isGenerating by viewModel.isVoiceGenerating.collectAsState()

    val selectedTtsLang by viewModel.selectedTtsLanguage.collectAsState()
    val selectedGenderVoice by viewModel.selectedGenderVoice.collectAsState()
    val selectedStyle by viewModel.selectedVoiceStyle.collectAsState()
    val selectedBaseVoice by viewModel.selectedBaseVoiceId.collectAsState()
    val speed by viewModel.voiceSpeed.collectAsState()
    val pitch by viewModel.voicePitch.collectAsState()
    val volume by viewModel.voiceVolume.collectAsState()

    val isBurmeseTtsSupported by viewModel.isBurmeseTtsSupported.collectAsState()
    val burmeseEngineMsg by viewModel.burmeseEngineMessage.collectAsState()
    val showTtsDialog by viewModel.showTtsInstallDialog.collectAsState()
    val ttsErrorMsg by viewModel.ttsErrorMessage.collectAsState()
    val lastGeneratedFile by viewModel.lastGeneratedAudioFile.collectAsState()

    var scriptText by remember { mutableStateOf(viewModel.voiceScriptText.value) }
    var showPipelineInspectionDialog by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // =================================================================
        // HEADER & BACKEND STATUS CHIP
        // =================================================================
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexoraNeonViolet.copy(alpha = 0.2f))
                            .border(1.dp, NexoraNeonViolet, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = NexoraNeonViolet,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Myanmar Voice Studio",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                        Text(
                            text = "Azure Speech (my-MM) • စတိုင်လ် ၇ မျိုး",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraTextSecondary
                            )
                        )
                    }
                }

                // Backend Voice Engine Status Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isBurmeseTtsSupported) NexoraEmeraldAccent.copy(alpha = 0.15f) else NexoraAmberAccent.copy(alpha = 0.15f))
                        .border(1.dp, if (isBurmeseTtsSupported) NexoraEmeraldAccent else NexoraAmberAccent, RoundedCornerShape(12.dp))
                        .clickable { viewModel.openTtsSettings(context) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isBurmeseTtsSupported) NexoraEmeraldAccent else NexoraAmberAccent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBurmeseTtsSupported) "my-MM: Active" else "my-MM: Unconfigured",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isBurmeseTtsSupported) NexoraEmeraldAccent else NexoraAmberAccent
                            )
                        )
                    }
                }
            }
        }

        // =================================================================
        // STUDIO MODE TAB SELECTOR (7 VOICE STYLES vs PERSONAL VOICE STUDIO)
        // =================================================================
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexoraSurfaceDark)
                    .border(1.dp, NexoraBorderSubtle, RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedTab == 0) NexoraPurplePrimary else Color.Transparent)
                        .clickable { selectedTab = 0 }
                        .padding(vertical = 10.dp)
                        .testTag("tab_voice_styles"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = if (selectedTab == 0) NexoraTextPrimary else NexoraTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "7 Voice Styles & TTS",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 0) NexoraTextPrimary else NexoraTextSecondary
                            )
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedTab == 1) NexoraPurplePrimary else Color.Transparent)
                        .clickable { selectedTab = 1 }
                        .padding(vertical = 10.dp)
                        .testTag("tab_personal_voice"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = if (selectedTab == 1) NexoraTextPrimary else NexoraTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Personal Voice Studio",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 1) NexoraTextPrimary else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        if (selectedTab == 1) {
            item {
                PersonalVoiceStudioSection(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
        // =================================================================
        // TTS LANGUAGE SELECTOR (MANUALLY CONFIGURED WITH BURMESE DEFAULT)
        // =================================================================
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = null,
                                tint = NexoraCyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TTS Language Selector (အသံ ဘာသာစကား)",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                        }
                        StatusBadge(
                            status = if (selectedTtsLang.isBurmese) "Default Language" else selectedTtsLang.code,
                            isSuccess = selectedTtsLang.isBurmese
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Manually registered TTS languages. Does not depend on browser language detection.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextMuted,
                            fontSize = 11.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Language Selector Chips (Myanmar is listed first and default)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(viewModel.supportedTtsLanguages) { lang ->
                            val isSel = selectedTtsLang.code == lang.code
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSel) NexoraPurplePrimary.copy(alpha = 0.35f) else NexoraSurfaceDark)
                                    .border(1.dp, if (isSel) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(10.dp))
                                    .clickable { viewModel.selectTtsLanguage(lang) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("tts_lang_${lang.code}")
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = lang.displayName,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSel) NexoraCyanAccent else NexoraTextPrimary
                                            )
                                        )
                                        if (lang.isBurmese) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "⭐",
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${lang.nativeName} • ${lang.code}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isSel) NexoraTextPrimary else NexoraTextSecondary,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Configuration Details & Voices for Selected Language
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexoraSurfaceElevated)
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Provider Configuration (${selectedTtsLang.displayName}):",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraTextSecondary
                                    )
                                )
                                Text(
                                    text = "Locale: ${selectedTtsLang.code}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = NexoraCyanAccent,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Female Voice option: my-MM-NilarNeural
                                val isFemaleSel = selectedGenderVoice == "Female"
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isFemaleSel) NexoraPurplePrimary.copy(alpha = 0.35f) else NexoraSurfaceDark)
                                        .border(1.dp, if (isFemaleSel) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(6.dp))
                                        .clickable { viewModel.selectGenderVoice("Female") }
                                        .padding(8.dp)
                                        .testTag("voice_female_btn")
                                ) {
                                    Column {
                                        Text(
                                            text = "Female: ${if (selectedTtsLang.isBurmese) "Nilar" else "Female"}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isFemaleSel) NexoraCyanAccent else NexoraTextPrimary
                                            )
                                        )
                                        Text(
                                            text = selectedTtsLang.femaleVoice,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontSize = 9.sp,
                                                color = NexoraTextMuted,
                                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                            ),
                                            maxLines = 1
                                        )
                                    }
                                }

                                // Male Voice option: my-MM-ThihaNeural
                                val isMaleSel = selectedGenderVoice == "Male"
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isMaleSel) NexoraPurplePrimary.copy(alpha = 0.35f) else NexoraSurfaceDark)
                                        .border(1.dp, if (isMaleSel) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(6.dp))
                                        .clickable { viewModel.selectGenderVoice("Male") }
                                        .padding(8.dp)
                                        .testTag("voice_male_btn")
                                ) {
                                    Column {
                                        Text(
                                            text = "Male: ${if (selectedTtsLang.isBurmese) "Thiha" else "Male"}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isMaleSel) NexoraCyanAccent else NexoraTextPrimary
                                            )
                                        )
                                        Text(
                                            text = selectedTtsLang.maleVoice,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontSize = 9.sp,
                                                color = NexoraTextMuted,
                                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                            ),
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Open-Source Backend Assessment Card (burmeseitman/myanmar-tts-pipeline)
                    if (selectedTtsLang.isBurmese) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(NexoraSurfaceElevated)
                                .border(1.dp, if (viewModel.ttsManager.isSelfHostedConfigured) NexoraCyanAccent.copy(alpha = 0.6f) else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.GraphicEq,
                                            contentDescription = null,
                                            tint = NexoraNeonViolet,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Open-Source TTS Pipeline",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = NexoraTextPrimary
                                            )
                                        )
                                    }
                                    StatusBadge(
                                        status = if (viewModel.ttsManager.isSelfHostedConfigured) "Self-Hosted Active" else "Requires Self-Hosting",
                                        isSuccess = viewModel.ttsManager.isSelfHostedConfigured
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Repository: burmeseitman/myanmar-tts-pipeline\n" +
                                           if (viewModel.ttsManager.isSelfHostedConfigured)
                                               "Endpoint: ${viewModel.ttsManager.getBurmeseTtsBackendUrl()}\nReal neural Burmese speech synthesis active."
                                           else
                                               "Status: No public cloud API endpoint. Source code requires self-hosting on GPU/container before connecting.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = NexoraTextSecondary,
                                        lineHeight = 16.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { showPipelineInspectionDialog = true },
                                        modifier = Modifier.testTag("inspect_pipeline_btn")
                                    ) {
                                        Text("Inspect Pipeline Specs & Docs", color = NexoraCyanAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    TextButton(onClick = { viewModel.ttsManager.checkBurmeseSupport() }) {
                                        Text("Recheck Status", color = NexoraTextSecondary, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Exact Missing Configuration Error Notice (if backend is not configured)
                    if (selectedTtsLang.isBurmese && !isBurmeseTtsSupported) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(NexoraAmberAccent.copy(alpha = 0.12f))
                                .border(1.dp, NexoraAmberAccent.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = NexoraAmberAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Exact Missing Configuration Error",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NexoraAmberAccent
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "No real Burmese TTS backend is currently active:\n" +
                                           "1. Microsoft Azure Speech (my-MM): AZURE_SPEECH_KEY missing from secrets.\n" +
                                           "2. Self-Hosted Pipeline: BURMESE_TTS_BACKEND_URL not set (burmeseitman/myanmar-tts-pipeline requires container deployment).\n" +
                                           "3. Device Engine: On-device Burmese (my-MM) voice data not installed.\n\n" +
                                           "English fallback is strictly disabled to prevent unintelligible speech.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = NexoraTextSecondary,
                                        lineHeight = 16.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(onClick = { showPipelineInspectionDialog = true }) {
                                        Text("How to Host Pipeline", color = NexoraCyanAccent, fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { viewModel.openTtsSettings(context) }) {
                                        Text("Open Android TTS Settings", color = NexoraAmberAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // NARRATION SCRIPT INPUT & RECAP MODE CONNECTORS
        // =================================================================
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Narration Script (${selectedTtsLang.displayName})",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraNeonViolet
                            )
                        )
                        if (scriptText.isNotBlank()) {
                            Text(
                                text = "${scriptText.length} chars",
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = scriptText,
                        onValueChange = {
                            scriptText = it
                            viewModel.voiceScriptText.value = it
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("voice_script_input"),
                        placeholder = {
                            Text(
                                if (selectedTtsLang.isBurmese) "Enter or paste Myanmar Unicode narration script..." else "Enter text for speech synthesis...",
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoraSurfaceElevated,
                            unfocusedContainerColor = NexoraSurfaceDark,
                            focusedBorderColor = NexoraPurplePrimary,
                            unfocusedBorderColor = NexoraBorderGlass,
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Connect all 5 Myanmar Recap Modes to Voice Studio
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = NexoraCyanAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Load from Recap Mode (ဇာတ်လမ်းမှ ရယူရန်):",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraCyanAccent
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(MyanmarRecapMode.values()) { recapMode ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(NexoraSurfaceDark)
                                    .border(1.dp, NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable {
                                        viewModel.loadFromRecapMode(recapMode)
                                        scriptText = viewModel.voiceScriptText.value
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${recapMode.badge}: ${recapMode.titleEn}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = NexoraTextPrimary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // EXACT SEVEN MYANMAR VOICE STYLES SELECTOR
        // =================================================================
        if (selectedTtsLang.isBurmese) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MYANMAR VOICE STYLES (စတိုင်လ် ၇ မျိုး)",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraNeonViolet,
                            letterSpacing = 0.5.sp
                        )
                    )
                    Text(
                        text = "Tap to Preview",
                        style = MaterialTheme.typography.labelSmall.copy(color = NexoraCyanAccent)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Microsoft Azure Speech (my-MM) Neural Voices: Male (ThihaNeural) & Female (NilarNeural). Styles 3–7 modulate acoustic rate, pitch, and prosody.",
                    style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted, fontSize = 11.sp)
                )
            }

            items(MyanmarVoiceStyle.values()) { style ->
                val isSelected = selectedStyle == style
                val icon = getVoiceStyleIcon(style)

                GlassmorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectMyanmarVoiceStyle(style) }
                        .testTag("style_${style.id}"),
                    borderColor = if (isSelected) NexoraNeonViolet else NexoraBorderGlass,
                    backgroundColor = if (isSelected) NexoraSurfaceElevated.copy(alpha = 0.95f) else NexoraSurfaceDark.copy(alpha = 0.8f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) NexoraPurplePrimary else NexoraSurfaceDark)
                                        .border(1.dp, if (isSelected) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (isSelected) NexoraTextPrimary else NexoraNeonViolet,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${style.badge}: ${style.titleEn}",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) NexoraCyanAccent else NexoraTextPrimary
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        StatusBadge(status = style.titleMy, isSuccess = isSelected)
                                    }
                                    Text(
                                        text = style.descriptionMy,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (isSelected) NexoraTextPrimary else NexoraTextSecondary
                                        )
                                    )
                                }
                            }

                            // Style Voice Preview Play Button
                            IconButton(
                                onClick = { viewModel.playVoiceStylePreview(style, selectedBaseVoice) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) NexoraPurplePrimary.copy(alpha = 0.4f) else NexoraSurfaceElevated)
                                    .border(1.dp, if (isSelected) NexoraCyanAccent else NexoraBorderSubtle, CircleShape)
                                    .testTag("preview_btn_${style.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Test Voice Sample",
                                    tint = if (isSelected) NexoraCyanAccent else NexoraTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = style.descriptionEn,
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted, fontSize = 11.sp)
                        )

                        // Footnote showing Azure base voice and preset SSML parameters
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Base: ${if (style.baseVoiceId.contains("Thiha")) "my-MM-ThihaNeural ♂" else "my-MM-NilarNeural ♀"} • Rate: ${String.format("%.2f", style.defaultSpeed)}x • Pitch: ${String.format("%.2f", style.defaultPitch)}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NexoraCyanAccent.copy(alpha = 0.85f),
                                    fontSize = 10.sp
                                )
                            )

                            // Toggle between Thiha (Male) and Nilar (Female) base voice
                            if (isSelected && style != MyanmarVoiceStyle.MALE_VOICE && style != MyanmarVoiceStyle.FEMALE_VOICE) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(
                                        AzureBurmeseVoices.MALE_THIHA to "Thiha ♂",
                                        AzureBurmeseVoices.FEMALE_NILAR to "Nilar ♀"
                                    ).forEach { (voiceId, label) ->
                                        val isVoiceSel = selectedBaseVoice == voiceId
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (isVoiceSel) NexoraPurplePrimary else NexoraSurfaceDark)
                                                .border(1.dp, if (isVoiceSel) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(6.dp))
                                                .clickable { viewModel.selectedBaseVoiceId.value = voiceId }
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = label,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontSize = 9.sp,
                                                    fontWeight = if (isVoiceSel) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isVoiceSel) NexoraTextPrimary else NexoraTextMuted
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // VOICE CONTROLS: SPEED, PITCH, AND VOLUME SLIDERS
        // =================================================================
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = NexoraNeonViolet,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Voice Parameter Controls (အသံထိန်းချုပ်မှုများ)",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                        }

                        // Reset to default button
                        TextButton(onClick = { viewModel.selectMyanmarVoiceStyle(selectedStyle) }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = NexoraCyanAccent, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset", color = NexoraCyanAccent, fontSize = 11.sp)
                        }
                    }

                    // 1. Speaking Speed Control
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Speed, contentDescription = null, tint = NexoraCyanAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Speaking Speed (အမြန်နှုန်း): ${String.format("%.2f", speed)}x",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = NexoraTextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                            Text(
                                text = when {
                                    speed < 0.9f -> "Slow / Paced"
                                    speed > 1.15f -> "Fast / Viral"
                                    else -> "Normal"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                            )
                        }
                        Slider(
                            value = speed,
                            onValueChange = { viewModel.voiceSpeed.value = it },
                            valueRange = 0.5f..2.0f,
                            steps = 14,
                            colors = SliderDefaults.colors(
                                thumbColor = NexoraCyanAccent,
                                activeTrackColor = NexoraCyanAccent,
                                inactiveTrackColor = NexoraSurfaceElevated
                            ),
                            modifier = Modifier.testTag("speed_slider")
                        )
                    }

                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)

                    // 2. Pitch Control
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = NexoraNeonViolet, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Pitch Tuning (အသံ အနိမ့်အမြင့်): ${String.format("%.2f", pitch)}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = NexoraTextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                            Text(
                                text = when {
                                    pitch < 0.95f -> "Deep / Resonant"
                                    pitch > 1.05f -> "Bright / Expressive"
                                    else -> "Natural"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                            )
                        }
                        Slider(
                            value = pitch,
                            onValueChange = { viewModel.voicePitch.value = it },
                            valueRange = 0.5f..1.5f,
                            steps = 10,
                            colors = SliderDefaults.colors(
                                thumbColor = NexoraNeonViolet,
                                activeTrackColor = NexoraPurplePrimary,
                                inactiveTrackColor = NexoraSurfaceElevated
                            ),
                            modifier = Modifier.testTag("pitch_slider")
                        )
                    }

                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)

                    // 3. Volume Control
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = NexoraEmeraldAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Volume Control (အသံပမာဏ): ${(volume * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = NexoraTextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                            Text(
                                text = if (volume > 1.0f) "Boosted" else "Standard",
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                            )
                        }
                        Slider(
                            value = volume,
                            onValueChange = { viewModel.updateVoiceVolume(it) },
                            valueRange = 0.2f..1.5f,
                            steps = 12,
                            colors = SliderDefaults.colors(
                                thumbColor = NexoraEmeraldAccent,
                                activeTrackColor = NexoraEmeraldAccent,
                                inactiveTrackColor = NexoraSurfaceElevated
                            ),
                            modifier = Modifier.testTag("volume_slider")
                        )
                    }
                }
            }
        }

        // =================================================================
        // AUDIO PLAYBACK & REAL MP3 DOWNLOAD CARD
        // =================================================================
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Audio Output & Playback (အသံ နားဆင်ခြင်း)",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                        if (lastGeneratedFile != null) {
                            StatusBadge(
                                status = if (lastGeneratedFile!!.name.endsWith(".mp3")) "MP3 Ready" else "WAV Ready",
                                isSuccess = true
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    // Waveform Visualizer
                    AudioWaveformVisualizer(isPlaying = isPlaying)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val isConfigError = selectedTtsLang.isBurmese && !isBurmeseTtsSupported

                        GlowingButton(
                            text = when {
                                isConfigError -> "Configure my-MM Backend"
                                isGenerating -> "Synthesizing Audio..."
                                isPlaying -> "Pause Audio"
                                else -> "Play Narration (${if (selectedTtsLang.isBurmese) selectedStyle.badge else selectedTtsLang.code})"
                            },
                            icon = if (isConfigError) Icons.Default.Warning else if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            enabled = !isGenerating,
                            onClick = { viewModel.playVoicePreview() },
                            modifier = Modifier.weight(1f),
                            testTag = "play_voice_btn"
                        )

                        SecondaryGlowingButton(
                            text = if (isConfigError) "Config Details" else "Download MP3 Audio",
                            icon = if (isConfigError) Icons.Default.Warning else Icons.Default.FileDownload,
                            onClick = {
                                if (isConfigError) {
                                    viewModel.ttsErrorMessage.value = viewModel.ttsManager.getMissingConfigurationError()
                                    viewModel.showTtsInstallDialog.value = true
                                } else {
                                    viewModel.downloadOrExportAudio(context)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            testTag = "download_audio_btn"
                        )
                    }
                }
            }
        }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }

    // =================================================================
    // BURMESE TTS EXACT MISSING CONFIGURATION ERROR DIALOG
    // =================================================================
    if (showTtsDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.showTtsInstallDialog.value = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = NexoraAmberAccent,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Backend TTS Provider Required",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = ttsErrorMsg ?: viewModel.ttsManager.getMissingConfigurationError(),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary,
                            lineHeight = 18.sp
                        )
                    )
                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)
                    Text(
                        text = "Configured Provider Specifications:\n• Provider: Microsoft Azure Speech Services\n• Locale: my-MM\n• Female Voice: my-MM-NilarNeural\n• Male Voice: my-MM-ThihaNeural\n\nNo browser language auto-detection or English voice fallback is permitted.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextMuted,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.openTtsSettings(context) }) {
                    Text("Open Android TTS Settings", color = NexoraCyanAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.showTtsInstallDialog.value = false }) {
                    Text("Dismiss", color = NexoraTextSecondary)
                }
            },
            containerColor = NexoraSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // =================================================================
    // OPEN-SOURCE BURMESE TTS PIPELINE DETAILED INSPECTION DIALOG
    // =================================================================
    if (showPipelineInspectionDialog) {
        AlertDialog(
            onDismissRequest = { showPipelineInspectionDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = NexoraCyanAccent,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Open-Source TTS Investigation",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "burmeseitman/myanmar-tts-pipeline",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraCyanAccent,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    )

                    Text(
                        text = "1. Feasibility & Capabilities:\n" +
                               "• Real Burmese Audio: Confirmed. The pipeline is an open-source PyTorch neural TTS solution specifically designed for Burmese.\n" +
                               "• Diglossia Normalization: Handles the critical gap between written Burmese literature and spoken conversational Burmese.\n" +
                               "• Phonetic Transliteration: Performs Burmese G2P (Grapheme-to-Phoneme) and syllabification with tone and virama rules.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary, lineHeight = 16.sp)
                    )

                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)

                    Text(
                        text = "2. Dependencies & Prerequisites:\n" +
                               "• Python 3.9+ runtime\n" +
                               "• PyTorch & Torchaudio\n" +
                               "• Audio libraries: librosa, soundfile, scipy, numpy\n" +
                               "• Burmese tokenizers: pymyanmar, myG2p, regex\n" +
                               "• Pre-trained neural model checkpoint weights",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary, lineHeight = 16.sp)
                    )

                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)

                    Text(
                        text = "3. API Endpoints & Hosting Assessment:\n" +
                               "• Cloud REST API: NONE. The repository contains local Python inference scripts and has no pre-hosted public cloud API.\n" +
                               "• Microservice Wrapper: To use as remote backend, wrap in FastAPI with POST /synthesize accepting { \"text\", \"voice\", \"speed\", \"pitch\" } returning audio/wav stream.\n" +
                               "• Hosting Requirements: 2-4GB+ RAM container (CPU) or GPU (T4 on Hugging Face Spaces, Google Cloud Run, AWS EC2).",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary, lineHeight = 16.sp)
                    )

                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)

                    Text(
                        text = "4. Current Status in NEXORA AI:\n" +
                               "• Integration Ready: NexoraTtsManager is wired with synthesizeWithSelfHostedBackend() and BURMESE_TTS_BACKEND_URL.\n" +
                               "• Honest Error Handling: Because no public URL is provided by the author, audio is gated until the backend URL is deployed in secrets.\n" +
                               "• No Fake Audio: Simulated speech and English fallback are strictly prevented.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraAmberAccent, lineHeight = 16.sp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showPipelineInspectionDialog = false }) {
                    Text("Close", color = NexoraCyanAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showPipelineInspectionDialog = false
                    viewModel.showTtsInstallDialog.value = true
                }) {
                    Text("View Backend Setup", color = NexoraTextSecondary)
                }
            },
            containerColor = NexoraSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

private fun getVoiceStyleIcon(style: MyanmarVoiceStyle): ImageVector {
    return when (style) {
        MyanmarVoiceStyle.MALE_VOICE -> Icons.Default.RecordVoiceOver
        MyanmarVoiceStyle.FEMALE_VOICE -> Icons.Default.RecordVoiceOver
        MyanmarVoiceStyle.STORYTELLER -> Icons.Default.GraphicEq
        MyanmarVoiceStyle.NEWS_PRESENTER -> Icons.Default.Speed
        MyanmarVoiceStyle.CINEMATIC -> Icons.Default.Movie
        MyanmarVoiceStyle.CALM_VOICE -> Icons.Default.VolumeUp
        MyanmarVoiceStyle.EXCITING_VOICE -> Icons.Default.GraphicEq
    }
}
