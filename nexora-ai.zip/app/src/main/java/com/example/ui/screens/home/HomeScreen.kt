package com.example.ui.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.LanguageSelectorChip
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraEmeraldAccent
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraPurpleVioletGradient
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraNavDestination
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun HomeScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val strings by viewModel.strings.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()
    val allProjects by viewModel.allProjects.collectAsState(initial = emptyList())
    val isApiConnected = viewModel.isApiConfigured()

    var searchQuery by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Top Bar with Logo, Profile & Language Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_nexora_logo),
                        contentDescription = "NEXORA AI Logo",
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = strings.appName,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = NexoraTextPrimary,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = strings.tagline,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NexoraNeonViolet,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                LanguageSelectorChip(
                    currentLanguage = currentLang,
                    onLanguageSelected = { viewModel.setLanguage(it) },
                    modifier = Modifier.testTag("lang_toggle_home")
                )
            }
        }

        // Hero Banner Card
        item {
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_banner_card")
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_nexora_hero),
                        contentDescription = "AI Hero Art",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        contentScale = ContentScale.Crop
                    )

                    // Gradient overlay
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        NexoraSurfaceDark.copy(alpha = 0.85f),
                                        NexoraSurfaceDark
                                    )
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .align(Alignment.BottomStart)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            StatusBadge(
                                status = strings.creatorBadge,
                                isSuccess = true
                            )
                            StatusBadge(
                                status = if (isApiConnected) strings.apiStatusActive else strings.apiStatusOffline,
                                isSuccess = isApiConnected
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = strings.welcomeBack,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                        Text(
                            text = "Next-generation video recaps, translation, and studio dubbing in one place.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_bar"),
                placeholder = {
                    Text(
                        strings.searchPlaceholder,
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = NexoraNeonViolet
                    )
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = NexoraSurfaceElevated,
                    unfocusedContainerColor = NexoraSurfaceDark,
                    focusedBorderColor = NexoraPurplePrimary,
                    unfocusedBorderColor = NexoraBorderGlass,
                    focusedTextColor = NexoraTextPrimary,
                    unfocusedTextColor = NexoraTextPrimary
                ),
                singleLine = true
            )
        }

        // AI Usage Overview
        item {
            Text(
                text = strings.aiUsageOverview,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                UsageStatCard(
                    title = "24",
                    subtitle = strings.recapsDone,
                    color = NexoraPurplePrimary,
                    modifier = Modifier.weight(1f)
                )
                UsageStatCard(
                    title = "48.5K",
                    subtitle = strings.wordsTranslated,
                    color = NexoraCyanAccent,
                    modifier = Modifier.weight(1f)
                )
                UsageStatCard(
                    title = "120m",
                    subtitle = strings.voiceMinutes,
                    color = NexoraNeonViolet,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Actions Section
        item {
            Text(
                text = strings.quickActions,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionItem(
                    title = strings.newRecap,
                    icon = Icons.Default.Movie,
                    gradient = NexoraPurpleVioletGradient,
                    onClick = { viewModel.navigateTo(NexoraNavDestination.RECAP) },
                    modifier = Modifier.weight(1f),
                    testTag = "quick_recap_btn"
                )
                QuickActionItem(
                    title = strings.instantTranslate,
                    icon = Icons.Default.Translate,
                    gradient = Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF06B6D4))),
                    onClick = { viewModel.navigateTo(NexoraNavDestination.TRANSLATE) },
                    modifier = Modifier.weight(1f),
                    testTag = "quick_translate_btn"
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionItem(
                    title = strings.createVoice,
                    icon = Icons.Default.GraphicEq,
                    gradient = Brush.linearGradient(listOf(Color(0xFF9333EA), Color(0xFFEC4899))),
                    onClick = { viewModel.navigateTo(NexoraNavDestination.VOICE) },
                    modifier = Modifier.weight(1f),
                    testTag = "quick_voice_btn"
                )
                QuickActionItem(
                    title = strings.generateThumbnail,
                    icon = Icons.Default.Image,
                    gradient = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFEF4444))),
                    onClick = { viewModel.navigateTo(NexoraNavDestination.THUMBNAIL) },
                    modifier = Modifier.weight(1f),
                    testTag = "quick_thumb_btn"
                )
            }
        }

        // Studio Features Section
        item {
            Text(
                text = strings.allFeatures,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                StudioFeatureRow(
                    title = "Myanmar Video Recap Studio (၅ မျိုး)",
                    subtitle = "Narrator, Dialogue, Full, Cinematic & Viral modes with real Burmese TTS",
                    icon = Icons.Default.Movie,
                    accentColor = NexoraNeonViolet,
                    onClick = { viewModel.navigateTo(NexoraNavDestination.RECAP) }
                )
                StudioFeatureRow(
                    title = strings.srtStudioTitle,
                    subtitle = strings.srtStudioSubtitle,
                    icon = Icons.Default.Subtitles,
                    accentColor = NexoraCyanAccent,
                    onClick = { viewModel.navigateTo(NexoraNavDestination.SRT_STUDIO) }
                )
                StudioFeatureRow(
                    title = strings.titleHashtagTitle,
                    subtitle = strings.titleHashtagSubtitle,
                    icon = Icons.Default.Tag,
                    accentColor = NexoraNeonViolet,
                    onClick = { viewModel.navigateTo(NexoraNavDestination.TITLES_TAGS) }
                )
            }
        }

        // Recent Projects Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.recentProjects,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
                Text(
                    text = strings.viewAll,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = NexoraNeonViolet,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier
                        .clickable { viewModel.navigateTo(NexoraNavDestination.PROJECTS) }
                        .padding(4.dp)
                )
            }
        }

        val filteredProjects = allProjects.filter {
            if (searchQuery.isBlank()) true
            else it.title.contains(searchQuery, ignoreCase = true) || it.summary.contains(searchQuery, ignoreCase = true)
        }.take(4)

        if (filteredProjects.isEmpty()) {
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noProjectsYet,
                            style = MaterialTheme.typography.bodyMedium.copy(color = NexoraTextMuted)
                        )
                    }
                }
            }
        } else {
            items(filteredProjects) { project ->
                GlassmorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(NexoraNavDestination.PROJECTS) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(NexoraSurfaceElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = NexoraNeonViolet,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = project.title,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraTextPrimary
                                    ),
                                    maxLines = 1
                                )
                                Text(
                                    text = project.summary,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = NexoraTextSecondary
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                        StatusBadge(
                            status = project.status,
                            isSuccess = project.status == "COMPLETED"
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}

@Composable
private fun UsageStatCard(
    title: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier,
        cornerRadius = 14.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = color
                )
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = NexoraTextSecondary
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun QuickActionItem(
    title: String,
    icon: ImageVector,
    gradient: Brush,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "quick_action"
) {
    Box(
        modifier = modifier
            .height(95.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(NexoraSurfaceDark)
            .border(1.dp, NexoraBorderGlass, RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag(testTag)
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(gradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NexoraTextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun StudioFeatureRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary
                        ),
                        maxLines = 1
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = NexoraTextMuted,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
