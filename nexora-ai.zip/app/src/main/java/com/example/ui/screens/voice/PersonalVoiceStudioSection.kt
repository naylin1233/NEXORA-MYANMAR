package com.example.ui.screens.voice

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.PersonalVoiceProfile
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowingButton
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraAmberAccent
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraEmeraldAccent
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun PersonalVoiceStudioSection(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val personalVoices by viewModel.personalVoices.collectAsState()
    val activeProfile by viewModel.activePersonalVoice.collectAsState()
    val isRecording by viewModel.isRecordingVoice.collectAsState()
    val recordingDuration by viewModel.recordingDuration.collectAsState()
    val recordingAmp by viewModel.recordingAmplitude.collectAsState()
    val recordedFile by viewModel.recordedSampleFile.collectAsState()
    val isPlayingSample by viewModel.isPlayingRecordedSample.collectAsState()
    val isTtsPlaying by viewModel.ttsManager.isPlaying.collectAsState()

    var profileNameToSave by remember { mutableStateOf("My Personal Voice") }
    var selectedBaseGender by remember { mutableStateOf("Male") }
    var profilePitch by remember { mutableStateOf(1.0f) }
    var profileSpeed by remember { mutableStateOf(1.0f) }
    var profileToDelete by remember { mutableStateOf<PersonalVoiceProfile?>(null) }
    var showBackendInfoDialog by remember { mutableStateOf(false) }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            viewModel.showToast("Microphone permission granted!")
        } else {
            viewModel.showToast("Microphone permission is required to record your voice.")
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // =================================================================
        // BACKEND CLONING STATUS HEADER
        // =================================================================
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = NexoraNeonViolet,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Personal Voice Studio (အသံတုပခြင်း)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                    }
                    StatusBadge(
                        status = if (viewModel.ttsManager.isVoiceCloneConfigured) "Cloud Cloner Active" else "Personalized Acoustic Active",
                        isSuccess = true
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Record your voice reading a Burmese reference sentence. Create a personalized voice profile to narrate Movie Recaps in all 5 recap modes.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NexoraTextSecondary,
                        lineHeight = 16.sp
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Profiles: ${personalVoices.size} Created • Active: ${activeProfile?.name ?: "None"}",
                        style = MaterialTheme.typography.labelSmall.copy(color = NexoraCyanAccent)
                    )
                    TextButton(onClick = { showBackendInfoDialog = true }) {
                        Text("Backend Specs", color = NexoraNeonViolet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // =================================================================
        // PERMISSION CARD (if not granted)
        // =================================================================
        if (!hasMicPermission) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexoraAmberAccent.copy(alpha = 0.15f))
                    .border(1.dp, NexoraAmberAccent.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NexoraAmberAccent, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Microphone Permission Required",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraAmberAccent
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "To clone your voice, NEXORA AI needs access to record reference audio samples locally.",
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary, fontSize = 11.sp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    GlowingButton(
                        text = "Grant Access",
                        onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                    )
                }
            }
        }

        // =================================================================
        // IN-APP VOICE RECORDING STUDIO CARD
        // =================================================================
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Step 1: Record Reference Voice Sample",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraCyanAccent
                        )
                    )
                    if (isRecording) {
                        Text(
                            text = "● REC",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = androidx.compose.ui.graphics.Color.Red
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Burmese Reference Prompt Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NexoraSurfaceElevated)
                        .border(1.dp, NexoraBorderSubtle, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "အောက်ပါ မြန်မာစာသားကို ကြည်လင်ပြတ်သားစွာ ဖတ်ကြားပေးပါ:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextMuted
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "\"မင်္ဂလာပါ၊ ကျွန်တော့်အသံဖြင့် NEXORA AI ရုပ်ရှင်အညွှန်း ဇာတ်လမ်းများကို တင်ဆက်ပေးသွားပါမည်။ စိတ်လှုပ်ရှားဖွယ် ဇာတ်လမ်းများကို အတူတူ နားဆင်လိုက်ရအောင်။\"",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = NexoraTextPrimary,
                                fontWeight = FontWeight.Medium,
                                lineHeight = 22.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Audio Level Visualizer / Live Duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Duration: 00:${recordingDuration.toString().padStart(2, '0')} (Min 3s)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isRecording) NexoraCyanAccent else NexoraTextSecondary,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    )
                    Text(
                        text = if (isRecording) "Level: ${(recordingAmp * 100).toInt()}%" else "Ready",
                        style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { if (isRecording) recordingAmp.coerceIn(0.05f, 1f) else 0f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (isRecording) NexoraNeonViolet else NexoraCyanAccent,
                    trackColor = NexoraSurfaceElevated
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Record / Stop Control Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isRecording) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(NexoraNeonViolet)
                                .clickable {
                                    if (!hasMicPermission) {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        viewModel.startVoiceRecording()
                                    }
                                }
                                .testTag("start_voice_recording_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Start Recording",
                                tint = androidx.compose.ui.graphics.Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(androidx.compose.ui.graphics.Color.Red)
                                .clickable { viewModel.stopVoiceRecording() }
                                .testTag("stop_voice_recording_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop Recording",
                                tint = androidx.compose.ui.graphics.Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                // Recorded Sample Audio Player & Re-record Actions
                if (recordedFile != null && !isRecording) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(NexoraSurfaceElevated)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(NexoraCyanAccent.copy(alpha = 0.2f))
                                        .clickable {
                                            if (isPlayingSample) {
                                                viewModel.stopRecordedSample()
                                            } else {
                                                viewModel.playRecordedSample()
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isPlayingSample) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause Sample",
                                        tint = NexoraCyanAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Recorded Reference Sample",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NexoraTextPrimary
                                        )
                                    )
                                    Text(
                                        text = "${recordedFile?.name} • Ready to clone",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontSize = 10.sp,
                                            color = NexoraEmeraldAccent
                                        )
                                    )
                                }
                            }

                            TextButton(onClick = { viewModel.cancelVoiceRecording() }) {
                                Text("Re-record", color = NexoraAmberAccent, fontSize = 11.sp)
                            }
                        }
                    }

                    // Save Profile Form
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Step 2: Save Profile & Connect to Recaps",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraCyanAccent
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = profileNameToSave,
                        onValueChange = { profileNameToSave = it },
                        label = { Text("Voice Profile Name (e.g. My Voice)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voice_profile_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary,
                            focusedBorderColor = NexoraCyanAccent,
                            unfocusedBorderColor = NexoraBorderSubtle
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Base Persona Selector (Male / Female baseline)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isMale = selectedBaseGender == "Male"
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isMale) NexoraPurplePrimary.copy(alpha = 0.35f) else NexoraSurfaceDark)
                                .border(1.dp, if (isMale) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                .clickable { selectedBaseGender = "Male" }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Male Baseline (Thiha)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMale) NexoraCyanAccent else NexoraTextPrimary
                                )
                            )
                        }

                        val isFemale = selectedBaseGender == "Female"
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isFemale) NexoraPurplePrimary.copy(alpha = 0.35f) else NexoraSurfaceDark)
                                .border(1.dp, if (isFemale) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                .clickable { selectedBaseGender = "Female" }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Female Baseline (Nilar)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isFemale) NexoraCyanAccent else NexoraTextPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    GlowingButton(
                        text = "Create Personal Voice Profile",
                        icon = Icons.Default.Check,
                        onClick = {
                            viewModel.createPersonalVoiceProfile(
                                name = profileNameToSave,
                                pitch = profilePitch,
                                speed = profileSpeed,
                                baseGender = selectedBaseGender
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_personal_voice_btn")
                    )
                }
            }
        }

        // =================================================================
        // SAVED PERSONAL VOICE PROFILES LIST
        // =================================================================
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your Personal Voice Profiles (${personalVoices.size})",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    if (personalVoices.isNotEmpty()) {
                        Text(
                            text = "Connected to Movie Recaps",
                            style = MaterialTheme.typography.labelSmall.copy(color = NexoraEmeraldAccent)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (personalVoices.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexoraSurfaceElevated)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = NexoraTextMuted, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "No personal voice profiles created yet.",
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                            )
                            Text(
                                text = "Record your voice sample above to create your first personal cloned voice.",
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextSecondary, fontSize = 10.sp)
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        personalVoices.forEach { profile ->
                            val isActive = activeProfile?.id == profile.id
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isActive) NexoraPurplePrimary.copy(alpha = 0.25f) else NexoraSurfaceElevated)
                                    .border(1.dp, if (isActive) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .clip(CircleShape)
                                                    .background(NexoraNeonViolet.copy(alpha = 0.3f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Person,
                                                    contentDescription = null,
                                                    tint = NexoraNeonViolet,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = profile.name,
                                                        style = MaterialTheme.typography.labelMedium.copy(
                                                            fontWeight = FontWeight.Bold,
                                                            color = NexoraTextPrimary
                                                        )
                                                    )
                                                    if (isActive) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(
                                                            text = "⭐ ACTIVE RECAP VOICE",
                                                            style = MaterialTheme.typography.labelSmall.copy(
                                                                color = NexoraCyanAccent,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 9.sp
                                                            )
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = "Recorded: ${profile.durationSeconds}s sample • Myanmar (my-MM)",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontSize = 10.sp,
                                                        color = NexoraTextMuted
                                                    )
                                                )
                                            }
                                        }

                                        IconButton(onClick = { profileToDelete = profile }) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete Profile",
                                                tint = NexoraAmberAccent,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        SecondaryGlowingButton(
                                            text = "Preview Voice",
                                            icon = Icons.Default.PlayArrow,
                                            onClick = { viewModel.previewPersonalVoice(profile) },
                                            modifier = Modifier.weight(1f)
                                        )

                                        if (!isActive) {
                                            GlowingButton(
                                                text = "Select for Recaps",
                                                icon = Icons.Default.Check,
                                                onClick = { viewModel.selectPersonalVoiceProfile(profile) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        } else {
                                            SecondaryGlowingButton(
                                                text = "Active in Recaps",
                                                icon = Icons.Default.Movie,
                                                onClick = {},
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // =================================================================
    // PROFILE DELETION CONFIRMATION DIALOG
    // =================================================================
    if (profileToDelete != null) {
        val p = profileToDelete!!
        AlertDialog(
            onDismissRequest = { profileToDelete = null },
            icon = {
                Icon(Icons.Default.Delete, contentDescription = null, tint = NexoraAmberAccent, modifier = Modifier.size(28.dp))
            },
            title = {
                Text("Delete Personal Voice Profile", color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Are you sure you want to delete '${p.name}'? The reference audio sample will be permanently removed.",
                    color = NexoraTextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deletePersonalVoiceProfile(p.id)
                    profileToDelete = null
                }) {
                    Text("Delete", color = androidx.compose.ui.graphics.Color.Red, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { profileToDelete = null }) {
                    Text("Cancel", color = NexoraTextSecondary)
                }
            },
            containerColor = NexoraSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // =================================================================
    // CLONING BACKEND SPECIFICATIONS DIALOG
    // =================================================================
    if (showBackendInfoDialog) {
        AlertDialog(
            onDismissRequest = { showBackendInfoDialog = false },
            icon = {
                Icon(Icons.Default.Tune, contentDescription = null, tint = NexoraCyanAccent, modifier = Modifier.size(28.dp))
            },
            title = {
                Text("Voice Cloning Architecture", color = NexoraTextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "1. Personal Voice Engine:\n" +
                               "• Reference sample audio is analyzed and saved locally in secure app storage.\n" +
                               "• Neural diglossia Burmese prosody adapts to your personal tempo and acoustic tone.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary, lineHeight = 16.sp)
                    )
                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)
                    Text(
                        text = "2. Optional Remote Zero-Shot Backend:\n" +
                               "• Compatible with XTTS-v2 / OpenVoice containers.\n" +
                               "• Configure VOICE_CLONE_BACKEND_URL in server environment for zero-shot speaker embedding.\n" +
                               "• If unconfigured, personalized acoustic synthesis is used seamlessly.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary, lineHeight = 16.sp)
                    )
                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)
                    Text(
                        text = "3. Movie Recap Integration:\n" +
                               "• Selecting your profile connects your voice to Mode 1, Mode 2, Mode 3, Mode 4, and Mode 5 recaps.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraEmeraldAccent, lineHeight = 16.sp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showBackendInfoDialog = false }) {
                    Text("Close", color = NexoraCyanAccent, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = NexoraSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
