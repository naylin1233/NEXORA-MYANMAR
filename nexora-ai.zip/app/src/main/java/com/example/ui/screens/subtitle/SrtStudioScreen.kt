package com.example.ui.screens.subtitle

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowingButton
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun SrtStudioScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings by viewModel.strings.collectAsState()
    val segments by viewModel.srtSegments.collectAsState()
    val isTranslating by viewModel.isTranslatingSrt.collectAsState()

    var rawSrt by remember { mutableStateOf(viewModel.srtRawInput.value) }
    var showRawEditor by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraCyanAccent.copy(alpha = 0.2f))
                        .border(1.dp, NexoraCyanAccent, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Subtitles,
                        contentDescription = null,
                        tint = NexoraCyanAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = strings.srtStudioTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = strings.srtStudioSubtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary
                        )
                    )
                }
            }
        }

        // Action Toolbar
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusBadge(status = "${segments.size} ${strings.totalSegments}", isSuccess = true)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SecondaryGlowingButton(
                            text = if (showRawEditor) "Timeline View" else "Raw SRT Editor",
                            onClick = { showRawEditor = !showRawEditor },
                            modifier = Modifier.testTag("toggle_raw_editor_btn")
                        )
                    }
                }
            }
        }

        // Raw Editor Box
        if (showRawEditor) {
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Raw .SRT Content",
                            style = MaterialTheme.typography.labelMedium.copy(color = NexoraTextSecondary)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = rawSrt,
                            onValueChange = {
                                rawSrt = it
                                viewModel.srtRawInput.value = it
                                viewModel.parseCurrentSrt()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .testTag("raw_srt_input"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = NexoraSurfaceElevated,
                                unfocusedContainerColor = NexoraSurfaceDark,
                                focusedBorderColor = NexoraPurplePrimary,
                                unfocusedBorderColor = NexoraBorderGlass,
                                focusedTextColor = NexoraTextPrimary,
                                unfocusedTextColor = NexoraTextPrimary
                            )
                        )
                    }
                }
            }
        }

        // Batch Translate to Myanmar Button
        item {
            GlowingButton(
                text = if (isTranslating) "Translating All Lines..." else strings.translateAllToMyanmar,
                icon = Icons.Default.Translate,
                enabled = !isTranslating && segments.isNotEmpty(),
                onClick = { viewModel.translateSubtitles() },
                modifier = Modifier.fillMaxWidth(),
                testTag = "translate_all_srt_btn"
            )
        }

        // Subtitle Segments Timeline
        item {
            Text(
                text = "Synchronized Subtitle Segments",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )
        }

        items(segments) { segment ->
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "#${segment.index}",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraNeonViolet
                            )
                        )
                        StatusBadge(
                            status = "${segment.startTime} → ${segment.endTime}",
                            isSuccess = false
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Original: ${segment.originalText}",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    var editedText by remember(segment.translatedText) {
                        mutableStateOf(segment.translatedText)
                    }

                    OutlinedTextField(
                        value = editedText,
                        onValueChange = {
                            editedText = it
                            viewModel.updateSegmentText(segment.index, it)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = {
                            Text(
                                "Enter or edit Myanmar subtitle...",
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                            )
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoraSurfaceElevated,
                            unfocusedContainerColor = NexoraSurfaceDark,
                            focusedBorderColor = NexoraCyanAccent,
                            unfocusedBorderColor = NexoraBorderGlass,
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary
                        ),
                        singleLine = false
                    )
                }
            }
        }

        // Export Actions (.SRT and .TXT)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SecondaryGlowingButton(
                    text = strings.exportSrt,
                    icon = Icons.Default.FileDownload,
                    onClick = {
                        val srt = viewModel.exportSrtContent()
                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, srt)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Export Subtitles (.SRT)"))
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "export_srt_btn"
                )
                SecondaryGlowingButton(
                    text = strings.exportPlainTxt,
                    icon = Icons.Default.Download,
                    onClick = {
                        val txt = viewModel.exportTxtContent()
                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, txt)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Export Plain Text (.TXT)"))
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "export_txt_btn"
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}
