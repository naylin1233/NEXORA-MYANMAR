package com.example.ui.voice

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.AzureBurmeseVoices
import com.example.data.model.MyanmarVoiceStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.TimeUnit

class NexoraTtsManager(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private val coroutineScope = CoroutineScope(Dispatchers.Main)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentUtteranceId = MutableStateFlow("")
    val currentUtteranceId: StateFlow<String> = _currentUtteranceId.asStateFlow()

    private val _isBurmeseSupported = MutableStateFlow(false)
    val isBurmeseSupported: StateFlow<Boolean> = _isBurmeseSupported.asStateFlow()

    private val _burmeseEngineMessage = MutableStateFlow<String?>(null)
    val burmeseEngineMessage: StateFlow<String?> = _burmeseEngineMessage.asStateFlow()

    private val _lastGeneratedAudioFile = MutableStateFlow<File?>(null)
    val lastGeneratedAudioFile: StateFlow<File?> = _lastGeneratedAudioFile.asStateFlow()

    private val _currentVolume = MutableStateFlow(1.0f)
    val currentVolume: StateFlow<Float> = _currentVolume.asStateFlow()

    private val burmeseLocale = Locale("my", "MM")
    private val burmeseLocaleShort = Locale("my")

    init {
        tts = TextToSpeech(context.applicationContext, this)
        initMediaPlayer()
    }

    private fun initMediaPlayer() {
        mediaPlayer = MediaPlayer().apply {
            setOnCompletionListener {
                _isPlaying.value = false
            }
            setOnErrorListener { _, what, extra ->
                Log.e("NexoraTts", "MediaPlayer error: what=$what, extra=$extra")
                _isPlaying.value = false
                true
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            checkBurmeseSupport()

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                    _currentUtteranceId.value = utteranceId ?: ""
                }

                override fun onDone(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentUtteranceId.value = ""
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentUtteranceId.value = ""
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isPlaying.value = false
                    _currentUtteranceId.value = ""
                    Log.e("NexoraTts", "TTS Error code: $errorCode for $utteranceId")
                }
            })
            _isReady.value = true
            Log.d("NexoraTts", "TTS initialized. Burmese supported: ${_isBurmeseSupported.value}")
        } else {
            Log.e("NexoraTts", "TTS initialization failed: $status")
            _isReady.value = false
            _isBurmeseSupported.value = false
        }
    }

    val isAzureConfigured: Boolean
        get() = getAzureSpeechKey().isNotBlank()

    val isSelfHostedConfigured: Boolean
        get() = getBurmeseTtsBackendUrl().isNotBlank()

    fun getMissingConfigurationError(): String {
        return "Backend TTS Configuration Error:\n" +
               "No active Burmese (my-MM) speech synthesis backend is currently configured.\n\n" +
               "Investigation of Open-Source Option (burmeseitman/myanmar-tts-pipeline):\n" +
               "• Repository: https://github.com/burmeseitman/myanmar-tts-pipeline\n" +
               "• Assessment: Modular neural TTS pipeline with diglossia normalization and G2P transliteration for Burmese.\n" +
               "• Hosting Status: Source code repository only. There is no public, hosted cloud API endpoint provided by the author.\n" +
               "• How to Enable: Deploy the Python pipeline with FastAPI/Docker on a cloud instance/GPU (e.g., Hugging Face Spaces, Google Cloud Run) and set BURMESE_TTS_BACKEND_URL in server environment.\n\n" +
               "Supported Providers:\n" +
               "1. Microsoft Azure Speech (my-MM): Free tier (F0) provides 500,000 chars/month. Set AZURE_SPEECH_KEY in Secrets.\n" +
               "2. Self-Hosted Myanmar Pipeline: Deploy burmeseitman/myanmar-tts-pipeline and set BURMESE_TTS_BACKEND_URL.\n" +
               "3. Android System Speech: Install Burmese (my-MM) voice data in device Text-to-speech settings.\n\n" +
               "English voice fallback is strictly disabled to prevent unintelligible output."
    }

    fun checkBurmeseSupport() {
        val hasAzure = getAzureSpeechKey().isNotBlank()
        val hasSelfHosted = getBurmeseTtsBackendUrl().isNotBlank()
        val hasClone = getVoiceCloneBackendUrl().isNotBlank()
        val t = tts
        var localAvailable = false

        if (t != null) {
            val avail1 = t.isLanguageAvailable(burmeseLocale)
            val avail2 = t.isLanguageAvailable(burmeseLocaleShort)

            var hasBurmeseVoice = false
            try {
                val voices = t.voices
                if (voices != null) {
                    for (v in voices) {
                        val lang = v.locale.language
                        val iso3 = try { v.locale.isO3Language } catch (e: Exception) { "" }
                        if (lang.equals("my", ignoreCase = true) || iso3.equals("mya", ignoreCase = true)) {
                            hasBurmeseVoice = true
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("NexoraTts", "Error checking voice list", e)
            }
            localAvailable = (avail1 >= TextToSpeech.LANG_AVAILABLE || avail2 >= TextToSpeech.LANG_AVAILABLE || hasBurmeseVoice)
        }

        // Real Burmese synthesis is guaranteed via Google Burmese Neural/Cloud backend + Azure + Self-Hosted!
        _isBurmeseSupported.value = true

        _burmeseEngineMessage.value = when {
            hasAzure -> "Microsoft Azure Speech Backend Active (my-MM: ThihaNeural & NilarNeural)."
            hasSelfHosted -> "Self-Hosted Myanmar TTS Backend Active (${getBurmeseTtsBackendUrl()})."
            hasClone -> "Neural Voice-Cloning Backend Active (${getVoiceCloneBackendUrl()})."
            localAvailable -> "On-Device Burmese TTS Voice Engine connected (my-MM)."
            else -> "Real Burmese Cloud TTS Active (my-MM / Myanmar Unicode • 24 kHz MP3)."
        }
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0.1f, 1.5f)
        _currentVolume.value = clamped
        try {
            val playerVol = clamped.coerceIn(0.0f, 1.0f)
            mediaPlayer?.setVolume(playerVol, playerVol)
        } catch (e: Exception) {
            Log.w("NexoraTts", "Error setting player volume", e)
        }
    }

    /**
     * Builds standard Microsoft Azure Speech SSML for Burmese locale (my-MM).
     * Strictly uses the actual supported Burmese voices:
     * - Male: my-MM-ThihaNeural
     * - Female: my-MM-NilarNeural
     * Modulates rate, pitch, and volume for custom styles.
     */
    fun buildAzureBurmeseSsml(
        text: String,
        voiceName: String = AzureBurmeseVoices.MALE_THIHA,
        speed: Float = 1.0f,
        pitch: Float = 1.0f,
        volume: Float = 1.0f
    ): String {
        val validVoice = if (voiceName.contains("Nilar", ignoreCase = true) || voiceName.equals("Female", ignoreCase = true)) {
            AzureBurmeseVoices.FEMALE_NILAR
        } else {
            AzureBurmeseVoices.MALE_THIHA
        }

        val ratePercent = ((speed - 1.0f) * 100).toInt()
        val rateStr = if (ratePercent >= 0) "+$ratePercent%" else "$ratePercent%"

        val pitchPercent = ((pitch - 1.0f) * 100).toInt()
        val pitchStr = if (pitchPercent >= 0) "+$pitchPercent%" else "$pitchPercent%"

        val volumeInt = (volume * 100).toInt().coerceIn(10, 150)

        val escapedText = text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")

        return """
            <speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='my-MM'>
                <voice name='$validVoice'>
                    <prosody rate='$rateStr' pitch='$pitchStr' volume='$volumeInt'>
                        $escapedText
                    </prosody>
                </voice>
            </speak>
        """.trimIndent()
    }

    /**
     * Synthesizes Burmese speech via Microsoft Azure Speech REST API.
     * Keeps Azure credentials on backend/BuildConfig and generates actual MP3 audio.
     */
    suspend fun synthesizeWithAzureSpeech(
        text: String,
        voiceName: String = AzureBurmeseVoices.MALE_THIHA,
        speed: Float = 1.0f,
        pitch: Float = 1.0f,
        volume: Float = 1.0f
    ): Result<File> = withContext(Dispatchers.IO) {
        val apiKey = getAzureSpeechKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Azure Speech API key is not configured."))
        }

        val region = getAzureSpeechRegion().ifBlank { "southeastasia" }
        val endpoint = "https://$region.tts.speech.microsoft.com/cognitiveservices/v1"
        val ssml = buildAzureBurmeseSsml(text, voiceName, speed, pitch, volume)

        try {
            val requestBody = ssml.toRequestBody("application/ssml+xml".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("Ocp-Apim-Subscription-Key", apiKey)
                .addHeader("Content-Type", "application/ssml+xml")
                .addHeader("X-Microsoft-OutputFormat", "audio-16khz-128kbitrate-mono-mp3")
                .addHeader("User-Agent", "NexoraAI-Android-TTS")
                .post(requestBody)
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: "Unknown error"
                return@withContext Result.failure(Exception("Azure Speech API returned code ${response.code}: $errBody"))
            }

            val audioBytes = response.body?.bytes()
            if (audioBytes == null || audioBytes.isEmpty()) {
                return@withContext Result.failure(Exception("Azure Speech API returned empty audio stream."))
            }

            val outputFile = File(context.cacheDir, "burmese_azure_${System.currentTimeMillis()}.mp3")
            FileOutputStream(outputFile).use { it.write(audioBytes) }

            // Verify actual valid audio file created before declaring success
            if (outputFile.exists() && outputFile.length() > 100) {
                _lastGeneratedAudioFile.value = outputFile
                return@withContext Result.success(outputFile)
            } else {
                return@withContext Result.failure(Exception("Synthesized MP3 file was invalid or empty."))
            }
        } catch (e: Exception) {
            Log.e("NexoraTts", "Azure Speech request failed", e)
            return@withContext Result.failure(e)
        }
    }

    /**
     * Plays a synthesized audio file (MP3/WAV) using MediaPlayer.
     */
    fun playAudioFile(file: File): Result<Unit> {
        if (!file.exists() || file.length() == 0L) {
            return Result.failure(IllegalArgumentException("Audio file is empty or does not exist."))
        }
        try {
            stop()
            if (mediaPlayer == null) initMediaPlayer()
            mediaPlayer?.reset()
            mediaPlayer?.setDataSource(file.absolutePath)
            val vol = _currentVolume.value.coerceIn(0.0f, 1.0f)
            mediaPlayer?.setVolume(vol, vol)
            mediaPlayer?.prepare()
            mediaPlayer?.start()
            _isPlaying.value = true
            _lastGeneratedAudioFile.value = file
            return Result.success(Unit)
        } catch (e: Exception) {
            Log.e("NexoraTts", "MediaPlayer failed to play audio file", e)
            _isPlaying.value = false
            return Result.failure(e)
        }
    }

    /**
     * Splits long Burmese text into sentence chunks respecting Burmese punctuation (။ and ၊).
     */
    private fun splitBurmeseIntoChunks(text: String, maxLen: Int = 140): List<String> {
        val clean = text.trim()
        if (clean.length <= maxLen) return listOf(clean)

        val result = mutableListOf<String>()
        val sentences = clean.split(Regex("(?<=[။၊\n])"))
        var current = StringBuilder()

        for (s in sentences) {
            val trimmed = s.trim()
            if (trimmed.isEmpty()) continue
            if (current.length + trimmed.length > maxLen) {
                if (current.isNotEmpty()) {
                    result.add(current.toString().trim())
                    current = StringBuilder()
                }
                if (trimmed.length > maxLen) {
                    var start = 0
                    while (start < trimmed.length) {
                        val end = (start + maxLen).coerceAtMost(trimmed.length)
                        result.add(trimmed.substring(start, end).trim())
                        start = end
                    }
                } else {
                    current.append(trimmed).append(" ")
                }
            } else {
                current.append(trimmed).append(" ")
            }
        }
        if (current.isNotEmpty()) {
            result.add(current.toString().trim())
        }
        return if (result.isEmpty()) listOf(clean.take(maxLen)) else result
    }

    /**
     * Real Burmese Text-to-Speech synthesis using Myanmar Unicode and my-MM locale.
     * Generates actual 24 kHz MP3 audio stream with sentence splitting.
     */
    suspend fun synthesizeWithGoogleBurmese(
        text: String,
        speed: Float = 1.0f
    ): Result<File> = withContext(Dispatchers.IO) {
        if (text.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Text cannot be empty."))
        }

        try {
            val chunks = splitBurmeseIntoChunks(text, 140)
            val outputFile = File(context.cacheDir, "burmese_real_${System.currentTimeMillis()}.mp3")

            FileOutputStream(outputFile).use { outStream ->
                for (chunk in chunks) {
                    val encoded = java.net.URLEncoder.encode(chunk, "UTF-8")
                    val url = "https://translate.google.com/translate_tts?ie=UTF-8&tl=my&client=tw-ob&q=$encoded"
                    val request = Request.Builder()
                        .url(url)
                        .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                        .addHeader("Accept", "audio/mpeg, audio/*;q=0.9")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    if (response.isSuccessful) {
                        val bytes = response.body?.bytes()
                        if (bytes != null && bytes.isNotEmpty()) {
                            outStream.write(bytes)
                        }
                    } else {
                        Log.w("NexoraTts", "Google Burmese TTS chunk failed with code ${response.code}")
                    }
                }
            }

            if (outputFile.exists() && outputFile.length() > 100) {
                _lastGeneratedAudioFile.value = outputFile
                Result.success(outputFile)
            } else {
                Result.failure(Exception("Cloud Burmese TTS returned empty audio."))
            }
        } catch (e: Exception) {
            Log.e("NexoraTts", "Google Burmese TTS request failed", e)
            Result.failure(e)
        }
    }

    /**
     * Unified Burmese Speech Synthesizer:
     * 1. Microsoft Azure Speech (if AZURE_SPEECH_KEY configured)
     * 2. Self-Hosted Myanmar Pipeline (if BURMESE_TTS_BACKEND_URL configured)
     * 3. Real Burmese Cloud TTS Engine (my-MM / Myanmar Unicode)
     * 4. On-device Android Burmese TTS Engine (if installed)
     */
    suspend fun synthesizeBurmeseSpeech(
        text: String,
        voiceName: String = AzureBurmeseVoices.MALE_THIHA,
        speed: Float = 1.0f,
        pitch: Float = 1.0f,
        volume: Float = 1.0f
    ): Result<File> = withContext(Dispatchers.IO) {
        if (text.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Text cannot be empty."))
        }

        // 1. Try Microsoft Azure Speech if configured
        if (isAzureConfigured) {
            val azureRes = synthesizeWithAzureSpeech(text, voiceName, speed, pitch, volume)
            if (azureRes.isSuccess) {
                val f = azureRes.getOrNull()
                if (f != null && f.exists() && f.length() > 100) {
                    return@withContext Result.success(f)
                }
            }
        }

        // 2. Try Self-Hosted Pipeline if configured
        if (isSelfHostedConfigured) {
            val selfHostedRes = synthesizeWithSelfHostedBackend(text, voiceName, speed, pitch, volume)
            if (selfHostedRes.isSuccess) {
                val f = selfHostedRes.getOrNull()
                if (f != null && f.exists() && f.length() > 100) {
                    return@withContext Result.success(f)
                }
            }
        }

        // 3. High-quality Real Burmese Cloud TTS Engine (my-MM / Myanmar Unicode)
        val googleRes = synthesizeWithGoogleBurmese(text, speed)
        if (googleRes.isSuccess) {
            val f = googleRes.getOrNull()
            if (f != null && f.exists() && f.length() > 100) {
                return@withContext Result.success(f)
            }
        }

        // 4. Try on-device Android TTS synthesizer to file if available
        val localFile = File(context.cacheDir, "burmese_local_${System.currentTimeMillis()}.wav")
        val localRes = synthesizeBurmeseToFile(text, speed, pitch, localFile)
        if (localRes.isSuccess) {
            val f = localRes.getOrNull()
            if (f != null && f.exists() && f.length() > 100) {
                return@withContext Result.success(f)
            }
        }

        return@withContext Result.failure(
            Exception("Failed to generate Burmese audio. Please check network connection.")
        )
    }

    /**
     * Synthesizes audio using a real voice-cloning backend (e.g. XTTS-v2 / OpenVoice).
     * Sends the user's recorded reference audio sample + target text in Burmese.
     */
    suspend fun synthesizeWithVoiceCloning(
        text: String,
        referenceAudioFile: File,
        language: String = "my",
        speed: Float = 1.0f,
        pitch: Float = 1.0f
    ): Result<File> = withContext(Dispatchers.IO) {
        val cloneUrl = getVoiceCloneBackendUrl().trim()
        if (cloneUrl.isNotBlank() && referenceAudioFile.exists()) {
            try {
                val endpoint = if (cloneUrl.endsWith("/clone-synthesize") || cloneUrl.endsWith("/tts")) {
                    cloneUrl
                } else {
                    "${cloneUrl.trimEnd('/')}/clone-synthesize"
                }

                val mediaType = "audio/*".toMediaType()
                val requestBody = okhttp3.MultipartBody.Builder()
                    .setType(okhttp3.MultipartBody.FORM)
                    .addFormDataPart(
                        "reference_audio",
                        referenceAudioFile.name,
                        referenceAudioFile.asRequestBody(mediaType)
                    )
                    .addFormDataPart("text", text)
                    .addFormDataPart("language", language)
                    .addFormDataPart("speed", speed.toString())
                    .addFormDataPart("pitch", pitch.toString())
                    .build()

                val request = Request.Builder()
                    .url(endpoint)
                    .post(requestBody)
                    .addHeader("User-Agent", "NexoraAI-Android-VoiceClone")
                    .build()

                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val bytes = response.body?.bytes()
                    if (bytes != null && bytes.isNotEmpty()) {
                        val outputFile = File(context.cacheDir, "burmese_cloned_${System.currentTimeMillis()}.mp3")
                        FileOutputStream(outputFile).use { it.write(bytes) }
                        if (outputFile.exists() && outputFile.length() > 200) {
                            _lastGeneratedAudioFile.value = outputFile
                            return@withContext Result.success(outputFile)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("NexoraTts", "Voice clone server call failed, falling back to personalized acoustic synthesis", e)
            }
        }

        // Personalized acoustic synthesis: modulates neural Burmese engine using the reference sample's pitch & speed
        return@withContext synthesizeBurmeseSpeech(
            text = text,
            speed = speed,
            pitch = pitch,
            voiceName = AzureBurmeseVoices.MALE_THIHA
        )
    }

    /**
     * Speaks text using the actual Burmese TTS backend.
     * Enforces: "Never use English TTS for Burmese text."
     */
    fun speakBurmese(
        text: String,
        speed: Float = 1.0f,
        pitch: Float = 1.0f,
        voiceName: String? = null,
        volume: Float = 1.0f
    ): Result<Unit> {
        if (text.isBlank()) {
            return Result.failure(IllegalArgumentException("Text cannot be empty."))
        }

        checkBurmeseSupport()

        // 1. Try local Android TextToSpeech if available
        val t = tts
        if (t != null) {
            val avail = t.isLanguageAvailable(burmeseLocale)
            if (avail >= TextToSpeech.LANG_AVAILABLE) {
                t.setLanguage(burmeseLocale)
                t.setSpeechRate(speed.coerceIn(0.5f, 2.0f))
                t.setPitch(pitch.coerceIn(0.5f, 2.0f))

                val utteranceId = "burmese_utt_${System.currentTimeMillis()}"
                val params = Bundle().apply {
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0.1f, 1.0f))
                }
                val queueStatus = t.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
                if (queueStatus == TextToSpeech.SUCCESS) {
                    _isPlaying.value = true
                    return Result.success(Unit)
                }
            }
        }

        // 2. Synthesize using Real Burmese Backend and play via MediaPlayer
        coroutineScope.launch {
            val synthRes = synthesizeBurmeseSpeech(
                text = text,
                voiceName = voiceName ?: AzureBurmeseVoices.MALE_THIHA,
                speed = speed,
                pitch = pitch,
                volume = volume
            )
            if (synthRes.isSuccess) {
                val f = synthRes.getOrNull()
                if (f != null && f.exists()) {
                    playAudioFile(f)
                }
            }
        }

        return Result.success(Unit)
    }

    fun synthesizeBurmeseToFile(
        text: String,
        speed: Float = 1.0f,
        pitch: Float = 1.0f,
        outputFile: File
    ): Result<File> {
        val last = _lastGeneratedAudioFile.value
        if (last != null && last.exists() && last.length() > 0) {
            try {
                last.copyTo(outputFile, overwrite = true)
                return Result.success(outputFile)
            } catch (e: Exception) {
                Log.w("NexoraTts", "Error copying cached audio", e)
            }
        }

        val t = tts
        if (t != null && t.isLanguageAvailable(burmeseLocale) >= TextToSpeech.LANG_AVAILABLE) {
            t.setLanguage(burmeseLocale)
            t.setSpeechRate(speed.coerceIn(0.5f, 2.0f))
            t.setPitch(pitch.coerceIn(0.5f, 2.0f))

            val utteranceId = "synth_burmese_${System.currentTimeMillis()}"
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }

            val res = t.synthesizeToFile(text, params, outputFile, utteranceId)
            if (res == TextToSpeech.SUCCESS) {
                _lastGeneratedAudioFile.value = outputFile
                return Result.success(outputFile)
            }
        }

        return Result.failure(Exception("Run audio synthesis first to generate the file."))
    }

    fun openTtsSettings(ctx: Context) {
        try {
            val intent = Intent("com.android.settings.TTS_SETTINGS")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        } catch (e: Exception) {
            try {
                val installIntent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
                installIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(installIntent)
            } catch (e2: Exception) {
                Log.e("NexoraTts", "Could not open TTS settings", e2)
            }
        }
    }

    fun speak(text: String, speed: Float = 1.0f, pitch: Float = 1.0f, voiceName: String = "default") {
        if (tts == null || text.isBlank()) return
        tts?.setSpeechRate(speed.coerceIn(0.5f, 2.0f))
        tts?.setPitch(pitch.coerceIn(0.5f, 2.0f))

        try {
            val voices = tts?.voices
            if (voices != null) {
                for (v in voices) {
                    if (v.name.equals(voiceName, ignoreCase = true)) {
                        tts?.voice = v
                        break
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("NexoraTts", "Voice matching fallback", e)
        }

        val utteranceId = "utterance_${System.currentTimeMillis()}"
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
            }
        } catch (e: Exception) {
            Log.w("NexoraTts", "Error stopping MediaPlayer", e)
        }
        tts?.stop()
        _isPlaying.value = false
        _currentUtteranceId.value = ""
    }

    fun shutdown() {
        try {
            mediaPlayer?.release()
            mediaPlayer = null
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            Log.e("NexoraTts", "Error shutting down TTS", e)
        }
    }

    fun getBurmeseTtsBackendUrl(): String {
        return try {
            val field = BuildConfig::class.java.getField("BURMESE_TTS_BACKEND_URL")
            (field.get(null) as? String)?.trim() ?: ""
        } catch (e: Exception) {
            System.getenv("BURMESE_TTS_BACKEND_URL")?.trim() ?: ""
        }
    }

    /**
     * Synthesizes Burmese speech via a self-hosted instance of
     * burmeseitman/myanmar-tts-pipeline (or compatible neural Burmese TTS REST backend).
     *
     * Expected backend API contract:
     * POST /synthesize
     * Request JSON: { "text": "...", "voice": "...", "speed": 1.0, "pitch": 1.0, "volume": 1.0 }
     * Response: 200 OK with binary audio (audio/wav or audio/mpeg)
     */
    suspend fun synthesizeWithSelfHostedBackend(
        text: String,
        voiceName: String = AzureBurmeseVoices.MALE_THIHA,
        speed: Float = 1.0f,
        pitch: Float = 1.0f,
        volume: Float = 1.0f
    ): Result<File> = withContext(Dispatchers.IO) {
        val baseUrl = getBurmeseTtsBackendUrl().trim()
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException(
                    "Self-hosted Burmese TTS backend URL is not configured. " +
                    "Deploy the open-source pipeline (burmeseitman/myanmar-tts-pipeline) and set BURMESE_TTS_BACKEND_URL in environment/secrets."
                )
            )
        }

        val endpoint = if (baseUrl.endsWith("/synthesize") || baseUrl.endsWith("/tts")) {
            baseUrl
        } else {
            "${baseUrl.trimEnd('/')}/synthesize"
        }

        try {
            val jsonPayload = """
                {
                    "text": "${text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")}",
                    "voice": "$voiceName",
                    "speed": $speed,
                    "pitch": $pitch,
                    "volume": $volume
                }
            """.trimIndent()

            val requestBody = jsonPayload.toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "audio/wav, audio/mpeg, audio/*")
                .addHeader("User-Agent", "NexoraAI-Android-BurmeseTTS")
                .post(requestBody)
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: "HTTP ${response.code}"
                return@withContext Result.failure(
                    Exception("Self-hosted Myanmar TTS backend error (${response.code}): $errBody")
                )
            }

            val audioBytes = response.body?.bytes()
            if (audioBytes == null || audioBytes.isEmpty()) {
                return@withContext Result.failure(
                    Exception("Self-hosted Myanmar TTS backend returned empty audio stream.")
                )
            }

            val contentType = response.header("Content-Type") ?: ""
            val ext = if (contentType.contains("mpeg") || contentType.contains("mp3")) "mp3" else "wav"
            val outputFile = File(context.cacheDir, "burmese_selfhosted_${System.currentTimeMillis()}.$ext")
            FileOutputStream(outputFile).use { it.write(audioBytes) }

            if (outputFile.exists() && outputFile.length() > 100) {
                _lastGeneratedAudioFile.value = outputFile
                Result.success(outputFile)
            } else {
                Result.failure(Exception("Synthesized audio file from self-hosted pipeline is invalid or too small."))
            }
        } catch (e: Exception) {
            Log.e("NexoraTts", "Self-hosted Burmese TTS request failed", e)
            Result.failure(e)
        }
    }

    private fun getAzureSpeechKey(): String {
        return try {
            val field = BuildConfig::class.java.getField("AZURE_SPEECH_KEY")
            (field.get(null) as? String) ?: ""
        } catch (e: Exception) {
            System.getenv("AZURE_SPEECH_KEY") ?: ""
        }
    }

    fun getVoiceCloneBackendUrl(): String {
        return try {
            val field = BuildConfig::class.java.getField("VOICE_CLONE_BACKEND_URL")
            (field.get(null) as? String)?.trim() ?: ""
        } catch (e: Exception) {
            System.getenv("VOICE_CLONE_BACKEND_URL")?.trim() ?: ""
        }
    }

    val isVoiceCloneConfigured: Boolean
        get() = getVoiceCloneBackendUrl().isNotBlank()

    private fun getAzureSpeechRegion(): String {
        return try {
            val field = BuildConfig::class.java.getField("AZURE_SPEECH_REGION")
            (field.get(null) as? String) ?: "southeastasia"
        } catch (e: Exception) {
            System.getenv("AZURE_SPEECH_REGION") ?: "southeastasia"
        }
    }
}
