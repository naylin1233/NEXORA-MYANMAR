package com.example.ui.screens.translate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowingButton
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun MyanmarTranslateScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val strings by viewModel.strings.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()
    val translatedResult by viewModel.translatedResult.collectAsState()
    val history by viewModel.translationHistory.collectAsState()

    var sourceText by remember { mutableStateOf(viewModel.translateSourceText.value) }
    val sourceLang by viewModel.translateSourceLang.collectAsState()
    val targetLang by viewModel.translateTargetLang.collectAsState()
    val style by viewModel.translateStyle.collectAsState()

    val availableStyles = listOf(strings.styleNatural, strings.styleFormal, strings.styleCasual)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraCyanAccent.copy(alpha = 0.2f))
                        .border(1.dp, NexoraCyanAccent, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = null,
                        tint = NexoraCyanAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = strings.translatorTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = strings.translatorSubtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary
                        )
                    )
                }
            }
        }

        // Language Selector Card with Swap Button
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Source Lang
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.sourceLang,
                            style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                        )
                        Text(
                            text = sourceLang,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                    }

                    // Swap Button
                    IconButton(
                        onClick = { viewModel.swapTranslationLanguages() },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(NexoraSurfaceElevated)
                            .border(1.dp, NexoraBorderGlass, CircleShape)
                            .testTag("swap_lang_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = strings.swapLanguages,
                            tint = NexoraNeonViolet
                        )
                    }

                    // Target Lang
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = strings.targetLang,
                            style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                        )
                        Text(
                            text = targetLang,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraCyanAccent
                            )
                        )
                    }
                }
            }
        }

        // Quick Pair Shortcuts
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickLangPairChip(
                    label = "EN → မြန်မာ",
                    isSelected = sourceLang == "English" && targetLang == "Myanmar",
                    onClick = {
                        viewModel.translateSourceLang.value = "English"
                        viewModel.translateTargetLang.value = "Myanmar"
                    },
                    modifier = Modifier.weight(1f)
                )
                QuickLangPairChip(
                    label = "中文 → မြန်မာ",
                    isSelected = sourceLang == "Chinese" && targetLang == "Myanmar",
                    onClick = {
                        viewModel.translateSourceLang.value = "Chinese"
                        viewModel.translateTargetLang.value = "Myanmar"
                    },
                    modifier = Modifier.weight(1f)
                )
                QuickLangPairChip(
                    label = "ไทย → မြန်မာ",
                    isSelected = sourceLang == "Thai" && targetLang == "Myanmar",
                    onClick = {
                        viewModel.translateSourceLang.value = "Thai"
                        viewModel.translateTargetLang.value = "Myanmar"
                    },
                    modifier = Modifier.weight(1f)
                )
                QuickLangPairChip(
                    label = "မြန်မာ → EN",
                    isSelected = sourceLang == "Myanmar" && targetLang == "English",
                    onClick = {
                        viewModel.translateSourceLang.value = "Myanmar"
                        viewModel.translateTargetLang.value = "English"
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Style Selector (Natural, Formal, Casual)
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = strings.translationStyle,
                        style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Natural", "Formal", "Casual").forEach { s ->
                            val isSel = style == s
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) NexoraPurplePrimary else NexoraSurfaceElevated)
                                    .border(1.dp, if (isSel) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.translateStyle.value = s }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = s,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSel) NexoraTextPrimary else NexoraTextSecondary,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Source Text Input
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = sourceLang,
                            style = MaterialTheme.typography.labelMedium.copy(color = NexoraTextSecondary)
                        )
                        if (sourceText.isNotBlank()) {
                            Text(
                                text = strings.clearText,
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted),
                                modifier = Modifier
                                    .clickable {
                                        sourceText = ""
                                        viewModel.translateSourceText.value = ""
                                    }
                                    .padding(4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = sourceText,
                        onValueChange = {
                            sourceText = it
                            viewModel.translateSourceText.value = it
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("translate_source_input"),
                        placeholder = {
                            Text(
                                strings.enterTextToTranslate,
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoraSurfaceElevated,
                            unfocusedContainerColor = NexoraSurfaceDark,
                            focusedBorderColor = NexoraPurplePrimary,
                            unfocusedBorderColor = NexoraBorderGlass,
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary
                        )
                    )
                }
            }
        }

        // Translate Button
        item {
            GlowingButton(
                text = if (isTranslating) "Translating..." else strings.translateBtn,
                icon = Icons.Default.Translate,
                enabled = !isTranslating,
                onClick = { viewModel.executeTranslation() },
                modifier = Modifier.fillMaxWidth(),
                testTag = "translate_btn"
            )
        }

        // Translation Result Card
        if (translatedResult.isNotBlank()) {
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.translatedOutput,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraCyanAccent
                                )
                            )
                            Row {
                                IconButton(
                                    onClick = {
                                        viewModel.ttsManager.speak(translatedResult)
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Speak",
                                        tint = NexoraNeonViolet,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.copyToClipboard(translatedResult, "Translation") },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy",
                                        tint = NexoraTextPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = translatedResult,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = NexoraTextPrimary,
                                lineHeight = 24.sp
                            )
                        )
                    }
                }
            }
        }

        // Translation History
        item {
            Text(
                text = strings.recentTranslations,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NexoraTextPrimary
                )
            )
        }

        items(history) { item ->
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.translateSourceText.value = item.sourceText
                        sourceText = item.sourceText
                    }
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.sourceLang} → ${item.targetLang} (${item.style})",
                            style = MaterialTheme.typography.labelSmall.copy(color = NexoraNeonViolet)
                        )
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = NexoraTextMuted,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { viewModel.copyToClipboard(item.translatedText) }
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = item.sourceText,
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary),
                        maxLines = 1
                    )
                    Text(
                        text = item.translatedText,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            color = NexoraTextPrimary
                        ),
                        maxLines = 2
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}

@Composable
private fun QuickLangPairChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) NexoraPurplePrimary.copy(alpha = 0.3f) else NexoraSurfaceDark)
            .border(1.dp, if (isSelected) NexoraPurplePrimary else NexoraBorderSubtle, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) NexoraTextPrimary else NexoraTextSecondary
            ),
            maxLines = 1
        )
    }
}
