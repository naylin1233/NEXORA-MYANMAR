package com.example.ui.voice

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class NexoraVoiceRecorder(private val context: Context) {
    private var mediaRecorder: MediaRecorder? = null
    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private var timerJob: Job? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _durationSeconds = MutableStateFlow(0)
    val durationSeconds: StateFlow<Int> = _durationSeconds.asStateFlow()

    private val _amplitude = MutableStateFlow(0.0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _recordedFile = MutableStateFlow<File?>(null)
    val recordedFile: StateFlow<File?> = _recordedFile.asStateFlow()

    private val _isPlayingRecording = MutableStateFlow(false)
    val isPlayingRecording: StateFlow<Boolean> = _isPlayingRecording.asStateFlow()

    private var currentOutputFile: File? = null

    fun startRecording(): Result<File> {
        if (_isRecording.value) {
            return Result.failure(IllegalStateException("Recording is already in progress."))
        }

        try {
            stopPlayingRecording()

            val dir = File(context.filesDir, "voice_samples")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            val outputFile = File(dir, "voice_sample_${System.currentTimeMillis()}.m4a")
            currentOutputFile = outputFile

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }

            mediaRecorder = recorder
            _isRecording.value = true
            _durationSeconds.value = 0
            _amplitude.value = 0.0f

            timerJob?.cancel()
            timerJob = scope.launch {
                var seconds = 0
                while (isActive && _isRecording.value) {
                    delay(200)
                    try {
                        val maxAmp = mediaRecorder?.maxAmplitude ?: 0
                        _amplitude.value = (maxAmp / 32768f).coerceIn(0.05f, 1.0f)
                    } catch (e: Exception) {
                        _amplitude.value = 0.1f
                    }
                    delay(800)
                    seconds++
                    _durationSeconds.value = seconds
                }
            }

            return Result.success(outputFile)
        } catch (e: Exception) {
            Log.e("NexoraVoiceRecorder", "Error starting recording", e)
            cleanupRecorder()
            return Result.failure(e)
        }
    }

    fun stopRecording(): Result<File> {
        if (!_isRecording.value) {
            return Result.failure(IllegalStateException("No recording in progress."))
        }

        timerJob?.cancel()
        timerJob = null

        return try {
            mediaRecorder?.apply {
                try {
                    stop()
                } catch (e: Exception) {
                    Log.w("NexoraVoiceRecorder", "MediaRecorder stop failed", e)
                }
                release()
            }
            mediaRecorder = null
            _isRecording.value = false
            _amplitude.value = 0.0f

            val file = currentOutputFile
            if (file != null && file.exists() && file.length() > 0) {
                _recordedFile.value = file
                Result.success(file)
            } else {
                Result.failure(Exception("Recorded audio file is empty or missing."))
            }
        } catch (e: Exception) {
            Log.e("NexoraVoiceRecorder", "Error stopping recording", e)
            cleanupRecorder()
            Result.failure(e)
        }
    }

    fun cancelRecording() {
        timerJob?.cancel()
        timerJob = null
        cleanupRecorder()
        try {
            currentOutputFile?.delete()
            currentOutputFile = null
        } catch (e: Exception) {
            Log.w("NexoraVoiceRecorder", "Error deleting cancelled recording", e)
        }
        _isRecording.value = false
        _amplitude.value = 0.0f
        _durationSeconds.value = 0
    }

    fun playRecordedSample(file: File? = _recordedFile.value): Result<Unit> {
        val target = file ?: return Result.failure(IllegalArgumentException("No recorded file to play."))
        if (!target.exists() || target.length() == 0L) {
            return Result.failure(IllegalArgumentException("Audio file is empty."))
        }

        return try {
            stopPlayingRecording()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(target.absolutePath)
                setOnCompletionListener {
                    _isPlayingRecording.value = false
                }
                setOnErrorListener { _, _, _ ->
                    _isPlayingRecording.value = false
                    true
                }
                prepare()
                start()
            }
            _isPlayingRecording.value = true
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("NexoraVoiceRecorder", "Error playing recording", e)
            _isPlayingRecording.value = false
            Result.failure(e)
        }
    }

    fun stopPlayingRecording() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
            mediaPlayer = null
        } catch (e: Exception) {
            Log.w("NexoraVoiceRecorder", "Error releasing MediaPlayer", e)
        }
        _isPlayingRecording.value = false
    }

    fun clearRecording() {
        stopPlayingRecording()
        _recordedFile.value = null
        _durationSeconds.value = 0
        _amplitude.value = 0.0f
        currentOutputFile = null
    }

    private fun cleanupRecorder() {
        try {
            mediaRecorder?.release()
        } catch (e: Exception) {
            Log.w("NexoraVoiceRecorder", "Error cleaning up recorder", e)
        }
        mediaRecorder = null
        _isRecording.value = false
    }

    fun release() {
        cancelRecording()
        stopPlayingRecording()
    }
}
