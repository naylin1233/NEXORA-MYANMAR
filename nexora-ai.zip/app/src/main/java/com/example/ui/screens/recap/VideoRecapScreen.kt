package com.example.ui.screens.recap

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CharacterDialogue
import com.example.data.model.MyanmarRecapMode
import com.example.data.model.MyanmarRecapScene
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowingButton
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraAmberAccent
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraEmeraldAccent
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraRedAccent
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun VideoRecapScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings by viewModel.strings.collectAsState()
    val isProcessing by viewModel.isRecapProcessing.collectAsState()
    val progress by viewModel.recapProgress.collectAsState()
    val progressText by viewModel.recapProgressText.collectAsState()
    val recapResult by viewModel.currentMyanmarRecap.collectAsState()

    val selectedMode by viewModel.selectedRecapMode.collectAsState()
    val chunkCount by viewModel.recapChunkCount.collectAsState()
    val viralDuration by viewModel.viralDurationOption.collectAsState()
    val previewMode by viewModel.previewingMode.collectAsState()

    val isBurmeseTtsSupported by viewModel.isBurmeseTtsSupported.collectAsState()
    val isPlaying by viewModel.ttsManager.isPlaying.collectAsState()

    val showTtsDialog by viewModel.showTtsInstallDialog.collectAsState()
    val ttsErrorMsg by viewModel.ttsErrorMessage.collectAsState()

    var inputContent by remember { mutableStateOf(viewModel.recapInput.value) }
    var selectedVideoName by remember { mutableStateOf<String?>(null) }
    var showSrtPreview by remember { mutableStateOf(false) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.selectedVideoUri.value = uri
            selectedVideoName = "Video selected: ${uri.lastPathSegment ?: "clip.mp4"}"
            inputContent = "Uploaded video analysis for: ${uri.lastPathSegment ?: "video.mp4"}. Story will be extracted sequentially across chunks."
            viewModel.recapInput.value = inputContent
            viewModel.showToast("Video loaded for chunked processing!")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexoraPurplePrimary.copy(alpha = 0.2f))
                            .border(1.dp, NexoraPurplePrimary, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = NexoraNeonViolet,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Myanmar Video Recap Studio",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraTextPrimary
                            )
                        )
                        Text(
                            text = "မြန်မာ ဗီဒီယို အကျဉ်းချုပ် စတူဒီယို (စတိုင်လ် ၅ မျိုး)",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraTextSecondary
                            )
                        )
                    }
                }

                // Burmese TTS Status Indicator
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isBurmeseTtsSupported) NexoraEmeraldAccent.copy(alpha = 0.15f) else NexoraAmberAccent.copy(alpha = 0.15f))
                        .border(1.dp, if (isBurmeseTtsSupported) NexoraEmeraldAccent else NexoraAmberAccent, RoundedCornerShape(12.dp))
                        .clickable { viewModel.openTtsSettings(context) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isBurmeseTtsSupported) NexoraEmeraldAccent else NexoraAmberAccent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBurmeseTtsSupported) "Burmese TTS: Ready" else "Burmese TTS: Setup",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isBurmeseTtsSupported) NexoraEmeraldAccent else NexoraAmberAccent
                            )
                        )
                    }
                }
            }
        }

        // =================================================================
        // EXACT FIVE MYANMAR RECAP MODES SELECTOR WITH PREVIEWS
        // =================================================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SELECT RECAP STYLE (စတိုင်လ် ၅ မျိုး)",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraNeonViolet,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = "Tap Preview for Sample",
                    style = MaterialTheme.typography.labelSmall.copy(color = NexoraCyanAccent)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MyanmarRecapMode.values().forEach { mode ->
                    val isSelected = selectedMode == mode
                    val icon = getModeIcon(mode)

                    GlassmorphicCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectedRecapMode.value = mode }
                            .testTag("mode_${mode.id}"),
                        borderColor = if (isSelected) NexoraNeonViolet else NexoraBorderGlass,
                        backgroundColor = if (isSelected) NexoraSurfaceElevated.copy(alpha = 0.95f) else NexoraSurfaceDark.copy(alpha = 0.8f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) NexoraPurplePrimary else NexoraSurfaceDark)
                                        .border(1.dp, if (isSelected) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (isSelected) NexoraTextPrimary else NexoraNeonViolet,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${mode.badge}: ${mode.titleEn}",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) NexoraCyanAccent else NexoraTextPrimary
                                            )
                                        )
                                        StatusBadge(status = mode.titleMy, isSuccess = isSelected)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = mode.descriptionMy,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (isSelected) NexoraTextPrimary else NexoraTextSecondary,
                                            lineHeight = 18.sp
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = mode.descriptionEn,
                                    style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted),
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.width(8.dp))

                                // Mode Preview Button
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(NexoraSurfaceDark)
                                        .border(1.dp, NexoraCyanAccent.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .clickable { viewModel.previewingMode.value = mode }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                        .testTag("preview_${mode.id}")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = NexoraCyanAccent,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Preview Mode",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = NexoraCyanAccent
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // MODE 5 VIRAL DURATION SELECTOR (Short vs Medium)
        // =================================================================
        if (selectedMode == MyanmarRecapMode.SHORT_VIRAL_RECAP) {
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Viral Duration (အလျားအနံ ရွေးချယ်ပါ)",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraNeonViolet
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf(
                                "60s" to "Short (30-60s) • TikTok & Shorts",
                                "120s" to "Medium (90-120s) • Reels & Stories"
                            ).forEach { (opt, label) ->
                                val isSel = viralDuration == opt
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSel) NexoraPurplePrimary.copy(alpha = 0.3f) else NexoraSurfaceDark)
                                        .border(1.dp, if (isSel) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(10.dp))
                                        .clickable { viewModel.viralDurationOption.value = opt }
                                        .padding(vertical = 10.dp, horizontal = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) NexoraCyanAccent else NexoraTextSecondary
                                        ),
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // LONG VIDEO CHUNKED PROCESSING CONTROLS
        // =================================================================
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Layers,
                                contentDescription = null,
                                tint = NexoraCyanAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Long Video Chunked Processing",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                        }
                        StatusBadge(
                            status = "$chunkCount Chunk${if (chunkCount > 1) "s" else ""}",
                            isSuccess = chunkCount > 1
                        )
                    }

                    Text(
                        text = "Chunked processing splits long videos into sequential segments preserving original chronological story order without token loss.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            1 to "Standard (1 Chunk)",
                            2 to "10 Min (2 Chunks)",
                            3 to "20 Min (3 Chunks)",
                            4 to "Full Episode (4 Chunks)"
                        ).forEach { (count, label) ->
                            val isSel = chunkCount == count
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) NexoraPurplePrimary.copy(alpha = 0.3f) else NexoraSurfaceDark)
                                    .border(1.dp, if (isSel) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.recapChunkCount.value = count }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) NexoraCyanAccent else NexoraTextSecondary
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // =================================================================
        // NARRATION VOICE SELECTION (MYANMAR VOICES & PERSONAL VOICE CLONING)
        // =================================================================
        item {
            val personalVoices by viewModel.personalVoices.collectAsState()
            val activePersonalVoice by viewModel.activePersonalVoice.collectAsState()
            val selectedStyle by viewModel.selectedVoiceStyle.collectAsState()

            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = null,
                                tint = NexoraNeonViolet,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Narrator Voice (ဇာတ်ကြောင်းပြော အသံ)",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                        }
                        StatusBadge(
                            status = if (activePersonalVoice != null) "Personal Voice Active" else selectedStyle.titleEn,
                            isSuccess = activePersonalVoice != null
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (activePersonalVoice != null)
                            "Currently using: 🌟 ${activePersonalVoice?.name} (${activePersonalVoice?.durationSeconds}s sample). Applied to all 5 Recap Modes."
                        else
                            "Currently using: ${selectedStyle.badge} ${selectedStyle.titleEn} (${selectedStyle.titleMy}). Connects with Azure my-MM Speech.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (activePersonalVoice != null) NexoraCyanAccent else NexoraTextSecondary,
                            fontSize = 11.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Voice Selection Row: Standard Narrator vs Personal Voice Profiles
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Option 1: Standard Voice (Azure Speech / Cloud TTS)
                        item {
                            val isStandard = activePersonalVoice == null
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isStandard) NexoraPurplePrimary.copy(alpha = 0.35f) else NexoraSurfaceDark)
                                    .border(1.dp, if (isStandard) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.selectPersonalVoiceProfile(null) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("narrator_voice_standard")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = null,
                                        tint = if (isStandard) NexoraCyanAccent else NexoraTextSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Standard Burmese (${selectedStyle.badge})",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (isStandard) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isStandard) NexoraCyanAccent else NexoraTextPrimary
                                        )
                                    )
                                }
                            }
                        }

                        // Option 2+: Saved Personal Voice Profiles
                        items(personalVoices) { profile ->
                            val isSelected = activePersonalVoice?.id == profile.id
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NexoraPurplePrimary.copy(alpha = 0.35f) else NexoraSurfaceDark)
                                    .border(1.dp, if (isSelected) NexoraCyanAccent else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.selectPersonalVoiceProfile(profile) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("narrator_voice_${profile.id}")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("🌟", fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = profile.name,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) NexoraCyanAccent else NexoraTextPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }

                    if (personalVoices.isEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(NexoraSurfaceElevated)
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Want your own voice? Record in Voice Studio -> Personal Voice.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = NexoraTextMuted
                                    )
                                )
                                TextButton(
                                    onClick = { viewModel.navigateTo(com.example.ui.viewmodel.NexoraNavDestination.VOICE) },
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Open Studio", color = NexoraCyanAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Upload Video & Story Input
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Video Input & Story Synopsis",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = NexoraTextPrimary
                            )
                        )
                        SecondaryGlowingButton(
                            text = "Browse Media",
                            icon = Icons.Default.VideoFile,
                            onClick = {
                                videoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            testTag = "browse_media_btn"
                        )
                    }

                    if (selectedVideoName != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        StatusBadge(status = selectedVideoName!!, isSuccess = true)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = inputContent,
                        onValueChange = {
                            inputContent = it
                            viewModel.recapInput.value = it
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(115.dp)
                            .testTag("recap_input_text"),
                        placeholder = {
                            Text(
                                "Enter story synopsis, character lines, or video details...",
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoraSurfaceElevated,
                            unfocusedContainerColor = NexoraSurfaceDark,
                            focusedBorderColor = NexoraPurplePrimary,
                            unfocusedBorderColor = NexoraBorderGlass,
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary
                        )
                    )
                }
            }
        }

        // Generate Recap Button
        item {
            GlowingButton(
                text = if (isProcessing) progressText.ifBlank { "Processing ${selectedMode.titleEn}..." } else "Generate ${selectedMode.badge}: ${selectedMode.titleEn}",
                icon = Icons.Default.AutoAwesome,
                enabled = !isProcessing,
                onClick = { viewModel.startMyanmarVideoRecap() },
                modifier = Modifier.fillMaxWidth(),
                testTag = "generate_myanmar_recap_btn"
            )
        }

        // Processing Progress Bar
        if (isProcessing) {
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = progressText,
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraNeonViolet)
                            )
                            Text(
                                text = "${(progress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                        }
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = NexoraPurplePrimary,
                            trackColor = NexoraSurfaceElevated
                        )
                    }
                }
            }
        }

        // =================================================================
        // GENERATED RECAP RESULT WITH UNICODE SCRIPT EDITING & TTS AUDIO
        // =================================================================
        if (recapResult != null) {
            val res = recapResult!!

            // Result Header Card
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = res.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            StatusBadge(status = res.mode.badge, isSuccess = true)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = res.summary,
                            style = MaterialTheme.typography.bodyMedium.copy(color = NexoraTextSecondary)
                        )

                        // Mode 5 Viral Hook Card
                        if (res.mode == MyanmarRecapMode.SHORT_VIRAL_RECAP && res.viralHook.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(NexoraPurplePrimary.copy(alpha = 0.2f))
                                    .border(1.dp, NexoraNeonViolet.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(
                                        text = "🔥 VIRAL HOOK (Shorts / TikTok / Reels):",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NexoraCyanAccent
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = res.viralHook,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = NexoraTextPrimary,
                                            lineHeight = 22.sp
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Chunks Processed: ${res.chunkCount} • Est: ${res.estimatedDuration}",
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraCyanAccent)
                            )

                            // Quick full audio listen
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                SecondaryGlowingButton(
                                    text = if (isPlaying) "Stop Audio" else "Play Audio",
                                    icon = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    onClick = {
                                        viewModel.playBurmeseNarration(res.fullNarrationText)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Export Actions (Audio & Synchronized SRT)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SecondaryGlowingButton(
                        text = "Export Audio (.WAV)",
                        icon = Icons.Default.FileDownload,
                        onClick = { viewModel.exportNarrationAudio(context) },
                        modifier = Modifier.weight(1f),
                        testTag = "export_narration_audio_btn"
                    )
                    SecondaryGlowingButton(
                        text = "Export Myanmar SRT",
                        icon = Icons.Default.Subtitles,
                        onClick = { viewModel.exportMyanmarSrt(context) },
                        modifier = Modifier.weight(1f),
                        testTag = "export_myanmar_srt_btn"
                    )
                }
            }

            // Toggle SRT Subtitle Preview
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Synchronized Scenes (${res.scenes.size} Scenes)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    TextButton(onClick = { showSrtPreview = !showSrtPreview }) {
                        Text(
                            text = if (showSrtPreview) "Hide SRT" else "Preview Raw SRT",
                            color = NexoraNeonViolet,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (showSrtPreview) {
                item {
                    GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Synchronized Myanmar .SRT",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraCyanAccent
                                    )
                                )
                                IconButton(onClick = { viewModel.copyToClipboard(res.fullSynchronizedSrt, "Myanmar SRT") }) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy SRT",
                                        tint = NexoraTextPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = res.fullSynchronizedSrt,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = NexoraTextSecondary,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            )
                        }
                    }
                }
            }

            // =================================================================
            // SCENE BY SCENE UNICODE EDITABLE LIST
            // =================================================================
            items(res.scenes) { scene ->
                SceneEditableCard(
                    scene = scene,
                    mode = res.mode,
                    isPlaying = isPlaying,
                    onUpdateNarrator = { newText ->
                        viewModel.updateSceneNarratorScript(scene.sceneNumber, newText)
                    },
                    onUpdateDialogue = { diagId, newText ->
                        viewModel.updateCharacterDialogue(scene.sceneNumber, diagId, newText)
                    },
                    onUpdateDramaticCue = { newCue ->
                        viewModel.updateSceneDramaticCue(scene.sceneNumber, newCue)
                    },
                    onPlayBurmeseSpeech = { text, speed, pitch, voice ->
                        viewModel.playBurmeseNarration(text, speed, pitch, voice)
                    }
                )
            }

            // Script Copy / Send to AI Voice Studio
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SecondaryGlowingButton(
                        text = "Copy Complete Script",
                        icon = Icons.Default.ContentCopy,
                        onClick = { viewModel.copyToClipboard(res.fullNarrationText, "Full Myanmar Recap Script") },
                        modifier = Modifier.weight(1f)
                    )
                    SecondaryGlowingButton(
                        text = strings.sendToVoice,
                        icon = Icons.Default.GraphicEq,
                        onClick = { viewModel.sendRecapScriptToVoice() },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }

    // =================================================================
    // MODE PREVIEW MODAL DIALOG
    // =================================================================
    if (previewMode != null) {
        val pMode = previewMode!!
        AlertDialog(
            onDismissRequest = { viewModel.previewingMode.value = null },
            icon = {
                Icon(
                    imageVector = getModeIcon(pMode),
                    contentDescription = null,
                    tint = NexoraNeonViolet,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${pMode.badge}: ${pMode.titleEn}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = pMode.titleMy,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraCyanAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = pMode.descriptionEn,
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary)
                    )
                    HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)
                    Text(
                        text = "Sample Excerpt Preview:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraNeonViolet
                        )
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexoraSurfaceElevated)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = pMode.previewSample,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraTextPrimary,
                                lineHeight = 19.sp
                            )
                        )
                    }

                    // Instant audio test button for this mode sample
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = {
                            viewModel.playBurmeseNarration(pMode.previewSample)
                        }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = NexoraCyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Hear Sample Audio", color = NexoraCyanAccent, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.selectedRecapMode.value = pMode
                    viewModel.previewingMode.value = null
                    viewModel.showToast("${pMode.badge} Selected!")
                }) {
                    Text("Select This Mode", color = NexoraNeonViolet, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.previewingMode.value = null }) {
                    Text("Close", color = NexoraTextSecondary)
                }
            },
            containerColor = NexoraSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // =================================================================
    // BURMESE TTS UNAVAILABLE WARNING & SETUP DIALOG
    // =================================================================
    if (showTtsDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.showTtsInstallDialog.value = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = NexoraAmberAccent,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Burmese TTS Voice Engine Required",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = ttsErrorMsg ?: "Burmese (မြန်မာ) TTS voice data is not installed on this Android device.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = NexoraTextSecondary)
                    )
                    Text(
                        text = "Note: English voice fallback is strictly disabled to prevent unintelligible output. You can install Burmese voice data via Google Speech Recognition & Synthesis in Android Settings.",
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraNeonViolet)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.openTtsSettings(context) }) {
                    Text("Open Android TTS Settings", color = NexoraCyanAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.showTtsInstallDialog.value = false }) {
                    Text("Dismiss", color = NexoraTextSecondary)
                }
            },
            containerColor = NexoraSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

private fun getModeIcon(mode: MyanmarRecapMode): ImageVector {
    return when (mode) {
        MyanmarRecapMode.NARRATOR_RECAP -> Icons.Default.RecordVoiceOver
        MyanmarRecapMode.DIALOGUE_RECAP -> Icons.Default.People
        MyanmarRecapMode.FULL_RECAP -> Icons.Default.Sync
        MyanmarRecapMode.CINEMATIC_RECAP -> Icons.Default.Theaters
        MyanmarRecapMode.SHORT_VIRAL_RECAP -> Icons.Default.Bolt
    }
}

@Composable
private fun SceneEditableCard(
    scene: MyanmarRecapScene,
    mode: MyanmarRecapMode,
    isPlaying: Boolean,
    onUpdateNarrator: (String) -> Unit,
    onUpdateDialogue: (String, String) -> Unit,
    onUpdateDramaticCue: (String) -> Unit,
    onPlayBurmeseSpeech: (String, Float, Float, String?) -> Unit
) {
    GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Scene Title & Timecode
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = scene.title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraNeonViolet
                    )
                )
                StatusBadge(status = scene.timecode, isSuccess = false)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Visual Context: ${scene.visualDescription}",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = NexoraTextSecondary,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            )

            // MODE 4: Dramatic Cues Editor
            if (mode == MyanmarRecapMode.CINEMATIC_RECAP) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🎭 Dramatic / Emotional Cue:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraCyanAccent
                        )
                    )
                }

                var editedCue by remember(scene.dramaticCue) { mutableStateOf(scene.dramaticCue) }
                OutlinedTextField(
                    value = editedCue,
                    onValueChange = {
                        editedCue = it
                        onUpdateDramaticCue(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    placeholder = { Text("e.g. [ခေတ္တရပ်နား] ရင်ခုန်ဖွယ် အလှည့်အပြောင်း...", style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)) },
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = NexoraSurfaceElevated,
                        unfocusedContainerColor = NexoraSurfaceDark,
                        focusedBorderColor = NexoraCyanAccent,
                        unfocusedBorderColor = NexoraBorderGlass,
                        focusedTextColor = NexoraTextPrimary,
                        unfocusedTextColor = NexoraTextPrimary
                    ),
                    singleLine = true
                )
            }

            // MODES 1, 3, 4, 5: Narrator Script (Editable Myanmar Unicode)
            if (mode != MyanmarRecapMode.DIALOGUE_RECAP) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when (mode) {
                            MyanmarRecapMode.CINEMATIC_RECAP -> "🎙️ Cinematic Narration (ရုပ်ရှင် အသံနေအထား)"
                            MyanmarRecapMode.SHORT_VIRAL_RECAP -> "⚡️ Viral Voiceover (အမြန် စာသား)"
                            else -> "🎙️ Myanmar Narrator Script (ဇာတ်ကြောင်းပြန်)"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )

                    IconButton(
                        onClick = { onPlayBurmeseSpeech(scene.narratorScript, 1.0f, 1.0f, null) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play Narrator Voice",
                            tint = NexoraCyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                var editedNarrator by remember(scene.narratorScript) { mutableStateOf(scene.narratorScript) }

                OutlinedTextField(
                    value = editedNarrator,
                    onValueChange = {
                        editedNarrator = it
                        onUpdateNarrator(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    placeholder = { Text("Edit Myanmar narrator script...", style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)) },
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = NexoraSurfaceElevated,
                        unfocusedContainerColor = NexoraSurfaceDark,
                        focusedBorderColor = NexoraPurplePrimary,
                        unfocusedBorderColor = NexoraBorderGlass,
                        focusedTextColor = NexoraTextPrimary,
                        unfocusedTextColor = NexoraTextPrimary
                    )
                )
            }

            // MODES 2 & 3: Character Dialogues (Editable Myanmar Unicode with Distinct Voices)
            if (mode == MyanmarRecapMode.DIALOGUE_RECAP || mode == MyanmarRecapMode.FULL_RECAP) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "💬 Character Dialogues (ဇာတ်ကောင် စကားပြောများ)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraCyanAccent
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))

                scene.dialogues.forEach { diag ->
                    var editedDialogue by remember(diag.myanmarDialogue) { mutableStateOf(diag.myanmarDialogue) }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NexoraSurfaceDark)
                            .border(0.5.dp, NexoraBorderSubtle, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = diag.speakerName,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraTextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(status = diag.speakerRole, isSuccess = false)
                            }

                            // Individual Character voice preview with character pitch offset
                            IconButton(
                                onClick = { onPlayBurmeseSpeech(diag.myanmarDialogue, diag.speed, diag.pitch, null) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play Character Voice",
                                    tint = NexoraNeonViolet,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = editedDialogue,
                            onValueChange = {
                                editedDialogue = it
                                onUpdateDialogue(diag.id, it)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Edit Myanmar character dialogue...", style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)) },
                            shape = RoundedCornerShape(6.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = NexoraSurfaceElevated,
                                unfocusedContainerColor = NexoraSurfaceDark,
                                focusedBorderColor = NexoraCyanAccent,
                                unfocusedBorderColor = NexoraBorderGlass,
                                focusedTextColor = NexoraTextPrimary,
                                unfocusedTextColor = NexoraTextPrimary
                            )
                        )
                    }
                }
            }

            // Scene SRT Snippet in Mode 3
            if (mode == MyanmarRecapMode.FULL_RECAP && scene.srtSnippet.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = NexoraBorderSubtle, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "SRT Sync Snippet:",
                    style = MaterialTheme.typography.labelSmall.copy(color = NexoraTextMuted)
                )
                Text(
                    text = scene.srtSnippet,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = NexoraTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                )
            }
        }
    }
}
