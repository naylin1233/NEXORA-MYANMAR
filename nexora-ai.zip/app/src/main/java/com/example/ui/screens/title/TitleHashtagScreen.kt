package com.example.ui.screens.title

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlowingButton
import com.example.ui.components.SecondaryGlowingButton
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraEmeraldAccent
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun TitleHashtagScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val strings by viewModel.strings.collectAsState()
    val isGenerating by viewModel.isGeneratingTitles.collectAsState()
    val results by viewModel.generatedTitlesTags.collectAsState()

    var topicInput by remember { mutableStateOf(viewModel.titleTopicInput.value) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraEmeraldAccent.copy(alpha = 0.2f))
                        .border(1.dp, NexoraEmeraldAccent, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Tag,
                        contentDescription = null,
                        tint = NexoraEmeraldAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = strings.titleHashtagTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = strings.titleHashtagSubtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary
                        )
                    )
                }
            }
        }

        // Topic Input Card
        item {
            GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Video Theme or Story Premise",
                        style = MaterialTheme.typography.labelMedium.copy(color = NexoraTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = {
                            topicInput = it
                            viewModel.titleTopicInput.value = it
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("title_topic_input"),
                        placeholder = {
                            Text(
                                strings.topicPlaceholder,
                                style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = NexoraSurfaceElevated,
                            unfocusedContainerColor = NexoraSurfaceDark,
                            focusedBorderColor = NexoraPurplePrimary,
                            unfocusedBorderColor = NexoraBorderGlass,
                            focusedTextColor = NexoraTextPrimary,
                            unfocusedTextColor = NexoraTextPrimary
                        )
                    )
                }
            }
        }

        // Generate Action Button
        item {
            GlowingButton(
                text = if (isGenerating) "Generating Viral Content..." else strings.generateSuggestionsBtn,
                icon = Icons.Default.AutoAwesome,
                enabled = !isGenerating,
                onClick = { viewModel.generateTitlesAndTags() },
                modifier = Modifier.fillMaxWidth(),
                testTag = "generate_titles_btn"
            )
        }

        // Output Results
        if (results != null) {
            val res = results!!

            // YouTube Titles
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.youtubeTitles,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    StatusBadge(status = "High CTR", isSuccess = true)
                }
            }

            items(res.youtubeTitles) { title ->
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = NexoraTextPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.copyToClipboard(title, "Title") },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy title",
                                tint = NexoraNeonViolet,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // TikTok Captions
            item {
                Text(
                    text = strings.tiktokCaptions,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
            }

            items(res.tiktokCaptions) { caption ->
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = caption,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = NexoraTextPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.copyToClipboard(caption, "Caption") },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy caption",
                                tint = NexoraCyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Trending Hashtags
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.trendingHashtags,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                            SecondaryGlowingButton(
                                text = strings.copyAll,
                                icon = Icons.Default.ContentCopy,
                                onClick = { viewModel.copyToClipboard(res.hashtags.joinToString(" "), "Hashtags") }
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = res.hashtags.joinToString("  "),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = NexoraNeonViolet,
                                lineHeight = 22.sp
                            )
                        )
                    }
                }
            }

            // SEO Video Description
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.seoDescription,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                )
                            )
                            IconButton(
                                onClick = { viewModel.copyToClipboard(res.seoDescription, "SEO Description") }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy description",
                                    tint = NexoraTextPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = res.seoDescription,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NexoraTextSecondary,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }
}
