package com.example.ui.screens.projects

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ProjectEntity
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.NexoraBorderGlass
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanAccent
import com.example.ui.theme.NexoraDeepBlack
import com.example.ui.theme.NexoraNeonViolet
import com.example.ui.theme.NexoraPurplePrimary
import com.example.ui.theme.NexoraRedAccent
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.viewmodel.NexoraViewModel

@Composable
fun ProjectsScreen(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings by viewModel.strings.collectAsState()
    val allProjects by viewModel.allProjects.collectAsState(initial = emptyList())

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }

    val categories = listOf(strings.filterAll, strings.filterRecaps, strings.filterTranslations, strings.filterVoice, strings.filterSubtitles)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraDeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraPurplePrimary.copy(alpha = 0.2f))
                        .border(1.dp, NexoraPurplePrimary, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = NexoraNeonViolet,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = strings.projectsTitle,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraTextPrimary
                        )
                    )
                    Text(
                        text = "Manage and export all generated recaps, translations, and studio scripts",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NexoraTextSecondary
                        )
                    )
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("projects_search_bar"),
                placeholder = {
                    Text(
                        strings.searchProjects,
                        style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextMuted)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = NexoraNeonViolet
                    )
                },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = NexoraSurfaceElevated,
                    unfocusedContainerColor = NexoraSurfaceDark,
                    focusedBorderColor = NexoraPurplePrimary,
                    unfocusedBorderColor = NexoraBorderGlass,
                    focusedTextColor = NexoraTextPrimary,
                    unfocusedTextColor = NexoraTextPrimary
                ),
                singleLine = true
            )
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSel = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) NexoraPurplePrimary else NexoraSurfaceElevated)
                            .border(1.dp, if (isSel) NexoraNeonViolet else NexoraBorderSubtle, RoundedCornerShape(8.dp))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) NexoraTextPrimary else NexoraTextSecondary
                            )
                        )
                    }
                }
            }
        }

        val filteredList = allProjects.filter { p ->
            val matchesQuery = searchQuery.isBlank() || p.title.contains(searchQuery, ignoreCase = true) || p.summary.contains(searchQuery, ignoreCase = true)
            val matchesCat = when (selectedCategory) {
                strings.filterRecaps -> p.type == "RECAP"
                strings.filterTranslations -> p.type == "TRANSLATE"
                strings.filterVoice -> p.type == "VOICE"
                strings.filterSubtitles -> p.type == "SUBTITLE"
                else -> true
            }
            matchesQuery && matchesCat
        }

        if (filteredList.isEmpty()) {
            item {
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noProjectsYet,
                            style = MaterialTheme.typography.bodyMedium.copy(color = NexoraTextMuted)
                        )
                    }
                }
            }
        } else {
            items(filteredList) { project ->
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = project.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            StatusBadge(status = project.status, isSuccess = project.status == "COMPLETED")
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = project.summary,
                            style = MaterialTheme.typography.bodySmall.copy(color = NexoraTextSecondary),
                            maxLines = 2
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Type: ${project.type} • ${project.language}",
                                style = MaterialTheme.typography.labelSmall.copy(color = NexoraCyanAccent)
                            )
                            Row {
                                IconButton(
                                    onClick = {
                                        val shareIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, "${project.title}\n\n${project.summary}\n\nContent:\n${project.contentData}")
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Share Project"))
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share",
                                        tint = NexoraNeonViolet,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { projectToDelete = project },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = NexoraRedAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }

    // Delete Confirmation Dialog
    if (projectToDelete != null) {
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = {
                Text(
                    text = strings.deleteProject,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraTextPrimary
                    )
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to delete '${projectToDelete?.title}'?",
                    style = MaterialTheme.typography.bodyMedium.copy(color = NexoraTextSecondary)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        projectToDelete?.let { viewModel.deleteProject(it.id) }
                        projectToDelete = null
                    }
                ) {
                    Text("Delete", color = NexoraRedAccent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { projectToDelete = null }) {
                    Text("Cancel", color = NexoraTextSecondary)
                }
            },
            containerColor = NexoraSurfaceDark,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
