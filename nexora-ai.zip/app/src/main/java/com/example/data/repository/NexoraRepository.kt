package com.example.data.repository

import com.example.data.local.ProjectDao
import com.example.data.local.ProjectEntity
import com.example.data.model.CharacterDialogue
import com.example.data.model.CharacterRole
import com.example.data.model.GeneratedTitlesAndTags
import com.example.data.model.MyanmarRecapMode
import com.example.data.model.MyanmarRecapResult
import com.example.data.model.MyanmarRecapScene
import com.example.data.model.ProjectStatus
import com.example.data.model.ProjectType
import com.example.data.model.RecapResult
import com.example.data.model.SceneItem
import com.example.data.model.SubtitleSegment
import com.example.data.model.TranslationRecord
import com.example.data.model.PersonalVoiceProfile
import com.example.data.model.VoiceProfile
import com.example.data.remote.GeminiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class NexoraRepository(
    private val projectDao: ProjectDao,
    val geminiService: GeminiService,
    val context: android.content.Context? = null
) {
    private val _translationHistory = MutableStateFlow<List<TranslationRecord>>(emptyList())
    val translationHistory: StateFlow<List<TranslationRecord>> = _translationHistory.asStateFlow()

    private val _personalVoices = MutableStateFlow<List<PersonalVoiceProfile>>(emptyList())
    val personalVoices: StateFlow<List<PersonalVoiceProfile>> = _personalVoices.asStateFlow()

    private val _activePersonalVoice = MutableStateFlow<PersonalVoiceProfile?>(null)
    val activePersonalVoice: StateFlow<PersonalVoiceProfile?> = _activePersonalVoice.asStateFlow()

    fun loadPersonalVoices() {
        val ctx = context ?: return
        try {
            val file = File(ctx.filesDir, "personal_voices.json")
            if (file.exists()) {
                val jsonStr = file.readText()
                val array = JSONArray(jsonStr)
                val list = mutableListOf<PersonalVoiceProfile>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        PersonalVoiceProfile(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            audioSamplePath = obj.getString("audioSamplePath"),
                            durationSeconds = obj.optInt("durationSeconds", 5),
                            language = obj.optString("language", "my-MM"),
                            pitch = obj.optDouble("pitch", 1.0).toFloat(),
                            speed = obj.optDouble("speed", 1.0).toFloat(),
                            baseVoiceId = obj.optString("baseVoiceId", "my-MM-ThihaNeural"),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            sampleText = obj.optString("sampleText", "မင်္ဂလာပါ၊ ကျွန်တော့်အသံဖြင့် NEXORA AI ရုပ်ရှင်အညွှန်း ဇာတ်လမ်းများကို တင်ဆက်ပေးသွားပါမည်။"),
                            isCloned = obj.optBoolean("isCloned", true)
                        )
                    )
                }
                _personalVoices.value = list
                if (_activePersonalVoice.value == null && list.isNotEmpty()) {
                    _activePersonalVoice.value = list.first()
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("NexoraRepository", "Error loading personal voices", e)
        }
    }

    fun savePersonalVoice(profile: PersonalVoiceProfile) {
        val current = _personalVoices.value.toMutableList()
        val index = current.indexOfFirst { it.id == profile.id }
        if (index >= 0) {
            current[index] = profile
        } else {
            current.add(0, profile)
        }
        _personalVoices.value = current
        _activePersonalVoice.value = profile
        persistPersonalVoices(current)
    }

    fun deletePersonalVoice(id: String) {
        val current = _personalVoices.value.filter { it.id != id }
        _personalVoices.value = current
        if (_activePersonalVoice.value?.id == id) {
            _activePersonalVoice.value = current.firstOrNull()
        }
        persistPersonalVoices(current)
    }

    fun setActivePersonalVoice(profile: PersonalVoiceProfile?) {
        _activePersonalVoice.value = profile
    }

    private fun persistPersonalVoices(list: List<PersonalVoiceProfile>) {
        val ctx = context ?: return
        try {
            val file = File(ctx.filesDir, "personal_voices.json")
            val array = JSONArray()
            for (p in list) {
                val obj = JSONObject().apply {
                    put("id", p.id)
                    put("name", p.name)
                    put("audioSamplePath", p.audioSamplePath)
                    put("durationSeconds", p.durationSeconds)
                    put("language", p.language)
                    put("pitch", p.pitch.toDouble())
                    put("speed", p.speed.toDouble())
                    put("baseVoiceId", p.baseVoiceId)
                    put("createdAt", p.createdAt)
                    put("sampleText", p.sampleText)
                    put("isCloned", p.isCloned)
                }
                array.put(obj)
            }
            file.writeText(array.toString())
        } catch (e: Exception) {
            android.util.Log.e("NexoraRepository", "Error persisting personal voices", e)
        }
    }

    // Available Voice Profiles
    val voiceProfiles: List<VoiceProfile> = listOf(
        VoiceProfile(
            id = "nexora_kyaw",
            name = "NEXORA Kyaw",
            gender = "Male",
            language = "Myanmar",
            tag = "Deep Narrative / Movie Recap",
            sampleText = "မင်္ဂလာပါ NEXORA AI မှ ကြိုဆိုပါတယ်။ ကျွန်တော်ကတော့ ရုပ်ရှင်ဇာတ်လမ်း အကျဉ်းချုပ်များကို အကောင်းဆုံး တင်ဆက်ပေးမယ့် ကျော် ဖြစ်ပါတယ်။"
        ),
        VoiceProfile(
            id = "nexora_thiri",
            name = "NEXORA Thiri",
            gender = "Female",
            language = "Myanmar",
            tag = "Warm Storyteller / Commercial",
            sampleText = "မင်္ဂလာပါရှင်။ NEXORA AI ရဲ့ နွေးထွေးတဲ့ အသံစနစ်နဲ့ ဇာတ်လမ်းကောင်းများကို သက်ဝင်လှုပ်ရှားအောင် ဖန်တီးပေးပါမယ်။"
        ),
        VoiceProfile(
            id = "nexora_alex",
            name = "NEXORA Alex",
            gender = "Male",
            language = "English",
            tag = "Studio Host / Documentary",
            sampleText = "Welcome to NEXORA AI. In this recap, we uncover the thrilling secret hidden beneath the city."
        ),
        VoiceProfile(
            id = "nexora_emma",
            name = "NEXORA Emma",
            gender = "Female",
            language = "English",
            tag = "Cinematic Trailer / Podcast",
            sampleText = "Experience the ultimate journey where artificial intelligence transforms digital imagination into reality."
        )
    )

    init {
        _translationHistory.value = listOf(
            TranslationRecord(
                sourceText = "Artificial Intelligence is transforming modern creativity.",
                translatedText = "ဉာဏ်ရည်တုနည်းပညာသည် ခေတ်သစ် ဖန်တီးမှုစွမ်းရည်များကို အဆင့်မြှင့်တင်ပေးနေပါသည်။",
                sourceLang = "English",
                targetLang = "Myanmar",
                style = "Natural"
            ),
            TranslationRecord(
                sourceText = "这部电影的结局真的很出人意料。",
                translatedText = "ဒီရုပ်ရှင်ရဲ့ ဇာတ်သိမ်းပိုင်းက တကယ်ကို မထင်မှတ်ထားလောက်အောင် ထူးခြားလှပပါတယ်။",
                sourceLang = "Chinese",
                targetLang = "Myanmar",
                style = "Casual"
            )
        )
    }

    suspend fun seedSampleProjectsIfEmpty() = withContext(Dispatchers.IO) {
        val sampleProjects = listOf(
            ProjectEntity(
                id = "proj_recap_1",
                title = "Cyber Horizon: The Last Citadel",
                type = ProjectType.RECAP.name,
                status = ProjectStatus.COMPLETED.name,
                summary = "Full 3-scene Myanmar recap with narrator breakdown and character dialogues.",
                contentData = "Detailed recap with 3 scenes and complete Myanmar narration scripts.",
                language = "Myanmar",
                createdAt = System.currentTimeMillis() - 86400000L,
                updatedAt = System.currentTimeMillis() - 72000000L
            ),
            ProjectEntity(
                id = "proj_srt_2",
                title = "Episode 04 Subtitle Sync",
                type = ProjectType.SUBTITLE.name,
                status = ProjectStatus.COMPLETED.name,
                summary = "42 subtitle segments translated and synchronized into natural Myanmar script.",
                contentData = "42 segments, 00:15:20 total time.",
                language = "Myanmar",
                createdAt = System.currentTimeMillis() - 172800000L,
                updatedAt = System.currentTimeMillis() - 150000000L
            ),
            ProjectEntity(
                id = "proj_voice_3",
                title = "Sci-Fi Documentary Narration",
                type = ProjectType.VOICE.name,
                status = ProjectStatus.COMPLETED.name,
                summary = "NEXORA Kyaw deep narrative audio generated for TikTok recap hook.",
                contentData = "2 min 30 sec audio script generated.",
                language = "Myanmar",
                createdAt = System.currentTimeMillis() - 250000000L,
                updatedAt = System.currentTimeMillis() - 220000000L
            )
        )
        for (p in sampleProjects) {
            val existing = projectDao.getProjectById(p.id)
            if (existing == null) {
                projectDao.insertProject(p)
            }
        }
    }

    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    fun searchProjects(query: String): Flow<List<ProjectEntity>> = projectDao.searchProjects(query)

    suspend fun saveProject(project: ProjectEntity) = withContext(Dispatchers.IO) {
        projectDao.insertProject(project)
    }

    suspend fun deleteProject(id: String) = withContext(Dispatchers.IO) {
        projectDao.deleteProjectById(id)
    }

    // -------------------------------------------------------------
    // THREE MYANMAR RECAP MODES ENGINE WITH CHUNKED LONG VIDEO PROCESSING
    // -------------------------------------------------------------
    suspend fun generateMyanmarVideoRecap(
        inputContent: String,
        mode: MyanmarRecapMode,
        chunkCount: Int = 1,
        onProgress: (Float, String) -> Unit
    ): MyanmarRecapResult = withContext(Dispatchers.IO) {
        val totalSteps = chunkCount.coerceAtLeast(1)

        // Chunked Processing simulation/flow preserving chronological order
        for (chunk in 1..totalSteps) {
            val baseProgress = (chunk - 1).toFloat() / totalSteps.toFloat()
            val chunkWeight = 1.0f / totalSteps.toFloat()

            onProgress(
                baseProgress + (chunkWeight * 0.2f),
                if (totalSteps > 1) "[Chunk $chunk/$totalSteps] Uploading video segment & extracting audio..." else "Uploading & segmenting video data..."
            )
            delay(350)

            onProgress(
                baseProgress + (chunkWeight * 0.5f),
                if (totalSteps > 1) "[Chunk $chunk/$totalSteps] Analyzing dramatic story beats & character lines..." else "Analyzing key scenes and dialogue..."
            )
            delay(400)

            onProgress(
                baseProgress + (chunkWeight * 0.85f),
                when (mode) {
                    MyanmarRecapMode.NARRATOR_RECAP -> if (totalSteps > 1) "[Chunk $chunk/$totalSteps] Writing natural Myanmar narration..." else "Writing engaging Myanmar narration script..."
                    MyanmarRecapMode.DIALOGUE_RECAP -> if (totalSteps > 1) "[Chunk $chunk/$totalSteps] Translating natural Myanmar character dialogue..." else "Converting conversations to Myanmar character dialogue..."
                    MyanmarRecapMode.FULL_RECAP -> if (totalSteps > 1) "[Chunk $chunk/$totalSteps] Synchronizing narrator, dialogue & Myanmar SRT..." else "Synchronizing narration, dialogue and Myanmar SRT..."
                    MyanmarRecapMode.CINEMATIC_RECAP -> if (totalSteps > 1) "[Chunk $chunk/$totalSteps] Composing dramatic cinematic cues & pauses..." else "Composing dramatic cinematic cues and expressive pacing..."
                    MyanmarRecapMode.SHORT_VIRAL_RECAP -> if (totalSteps > 1) "[Chunk $chunk/$totalSteps] Writing high-retention viral hook & key events..." else "Writing viral hook and concise key story events..."
                }
            )
            delay(350)
        }

        onProgress(0.95f, "Assembling complete story timeline and validating Unicode text...")

        // Attempt Gemini API if configured
        if (geminiService.isConfigured()) {
            val modeInstruction = when (mode) {
                MyanmarRecapMode.NARRATOR_RECAP -> """
                    MODE: 1 (NARRATOR RECAP)
                    - One Myanmar narrator tells the complete story scene by scene.
                    - Natural, engaging Myanmar storytelling in fluent Unicode.
                    - For each scene, create a rich "narratorScript" in Burmese.
                    - Do NOT generate character dialogue lines in this mode.
                """.trimIndent()
                MyanmarRecapMode.DIALOGUE_RECAP -> """
                    MODE: 2 (CHARACTER DIALOGUE RECAP)
                    - Retell the story mainly through character conversations.
                    - Give each character distinct supported Burmese voices (pitch: 0.8 to 1.3, speed: 0.9 to 1.1).
                    - Clearly identify each speaker with "speakerName" and "speakerRole".
                    - Strictly: Do not imitate real actors' voices.
                    - Focus primarily on character dialogues in natural Myanmar Unicode.
                """.trimIndent()
                MyanmarRecapMode.FULL_RECAP -> """
                    MODE: 3 (FULL RECAP)
                    - Combine Myanmar narrator storytelling and character dialogues naturally.
                    - Preserve original story order and meaning.
                    - Synchronize narration, character dialogue, video scenes, and valid Myanmar SRT subtitles.
                    - Each scene must have "narratorScript", "dialogues" array, and valid "srtSnippet".
                """.trimIndent()
                MyanmarRecapMode.CINEMATIC_RECAP -> """
                    MODE: 4 (CINEMATIC RECAP)
                    - Dramatic and exciting Myanmar storytelling.
                    - Emphasize important scenes, deep emotions, tension, and plot twists.
                    - Use natural pauses (insert "[ခေတ္တရပ်နား]" tags for breathing room) and expressive cues ("[ရင်ခုန်ဖွယ် အလှည့်အပြောင်း]").
                    - Do not invent events that are not in the original story.
                """.trimIndent()
                MyanmarRecapMode.SHORT_VIRAL_RECAP -> """
                    MODE: 5 (SHORT VIRAL RECAP)
                    - Create a concise, high-retention Myanmar recap for TikTok, YouTube Shorts & Facebook Reels.
                    - Start with an irresistible viral hook ("viralHook" field) with emojis.
                    - Focus strictly on the most critical, shock-value story events without fluff.
                    - Fast-paced and concise.
                """.trimIndent()
            }

            val prompt = """
                You are NEXORA AI expert Myanmar video recap engine.
                Input video synopsis / transcript:
                "$inputContent"

                Number of processed chunks: $chunkCount.
                Ensure original story order and meaning are strictly preserved.
                $modeInstruction

                Format your response strictly as valid JSON:
                {
                  "title": "Compelling Myanmar Title (မြန်မာခေါင်းစဉ်)",
                  "summary": "Engaging high-level Myanmar summary of the story",
                  "viralHook": "Exciting viral hook for TikTok/Reels if in Mode 5",
                  "characters": [
                    {"name": "မင်းသား Leo", "role": "Protagonist", "description": "Character role", "voiceType": "Male Vocal 1", "pitch": 0.95, "speed": 1.0}
                  ],
                  "scenes": [
                    {
                      "sceneNumber": 1,
                      "title": "အခန်း ၁ - အစပျိုးခြင်း",
                      "timecode": "00:00 - 01:30",
                      "visualDescription": "Scene visual context",
                      "dramaticCue": "[ခေတ္တရပ်နား] ရင်ခုန်ဖွယ် အစပျိုးချက်",
                      "narratorScript": "Myanmar narrator voiceover text",
                      "dialogues": [
                        {"speakerName": "Leo", "speakerRole": "Protagonist", "myanmarDialogue": "ငါ ဒီနေရာကနေ မဖြစ်မနေ ထွက်သွားရမယ်။", "pitch": 0.95, "speed": 1.0}
                      ],
                      "srtSnippet": "1\n00:00:02,000 --> 00:00:06,000\nမိုးသည်းထန်စွာ ရွာသွန်းနေတဲ့ နီယွန်မြို့တော်မှာ ဇာတ်လမ်းစတင်ခဲ့ပါတယ်။"
                    }
                  ],
                  "fullNarrationText": "Complete aggregated narration or script ready for audio generation",
                  "fullSynchronizedSrt": "Complete valid SRT formatted subtitle text for entire video",
                  "estimatedDuration": "3 Min"
                }
            """.trimIndent()

            val apiResult = geminiService.generateContent(prompt)
            if (apiResult.isSuccess) {
                val raw = apiResult.getOrNull() ?: ""
                try {
                    val cleanJson = raw.substringAfter("{").substringBeforeLast("}")
                    val fullJson = "{$cleanJson}"
                    val obj = JSONObject(fullJson)

                    val charList = mutableListOf<CharacterRole>()
                    val charArr = obj.optJSONArray("characters")
                    if (charArr != null) {
                        for (i in 0 until charArr.length()) {
                            val c = charArr.getJSONObject(i)
                            charList.add(
                                CharacterRole(
                                    name = c.optString("name", "ဇာတ်ကောင် ${i + 1}"),
                                    role = c.optString("role", "အဓိကဇာတ်ကောင်"),
                                    description = c.optString("description", ""),
                                    voiceType = c.optString("voiceType", "Vocal ${i + 1}"),
                                    pitch = c.optDouble("pitch", 1.0).toFloat(),
                                    speed = c.optDouble("speed", 1.0).toFloat()
                                )
                            )
                        }
                    }

                    val sceneList = mutableListOf<MyanmarRecapScene>()
                    val sceneArr = obj.optJSONArray("scenes")
                    if (sceneArr != null) {
                        for (i in 0 until sceneArr.length()) {
                            val s = sceneArr.getJSONObject(i)
                            val dialogues = mutableListOf<CharacterDialogue>()
                            val dArr = s.optJSONArray("dialogues")
                            if (dArr != null) {
                                for (j in 0 until dArr.length()) {
                                    val d = dArr.getJSONObject(j)
                                    dialogues.add(
                                        CharacterDialogue(
                                            speakerName = d.optString("speakerName", "Speaker"),
                                            speakerRole = d.optString("speakerRole", "Role"),
                                            myanmarDialogue = d.optString("myanmarDialogue", ""),
                                            pitch = d.optDouble("pitch", 1.0).toFloat(),
                                            speed = d.optDouble("speed", 1.0).toFloat()
                                        )
                                    )
                                }
                            }
                            sceneList.add(
                                MyanmarRecapScene(
                                    sceneNumber = s.optInt("sceneNumber", i + 1),
                                    title = s.optString("title", "အခန်း ${i + 1}"),
                                    timecode = s.optString("timecode", "00:00 - 01:00"),
                                    visualDescription = s.optString("visualDescription", ""),
                                    narratorScript = s.optString("narratorScript", ""),
                                    dialogues = dialogues,
                                    srtSnippet = s.optString("srtSnippet", ""),
                                    dramaticCue = s.optString("dramaticCue", "")
                                )
                            )
                        }
                    }

                    onProgress(1.0f, "Recap complete!")
                    val result = MyanmarRecapResult(
                        title = obj.optString("title", "NEXORA AI Myanmar Video Recap"),
                        mode = mode,
                        summary = obj.optString("summary", "Complete recap generated by Gemini AI."),
                        characters = if (charList.isNotEmpty()) charList else getDefaultCharactersForMode(mode),
                        scenes = if (sceneList.isNotEmpty()) sceneList else getDefaultScenesForMode(mode),
                        fullNarrationText = obj.optString("fullNarrationText", ""),
                        fullSynchronizedSrt = obj.optString("fullSynchronizedSrt", generateSrtFromScenes(sceneList)),
                        chunkCount = chunkCount,
                        estimatedDuration = obj.optString("estimatedDuration", if (mode == MyanmarRecapMode.SHORT_VIRAL_RECAP) "60s" else "${chunkCount * 3} Min"),
                        viralHook = obj.optString("viralHook", "")
                    )

                    saveProject(
                        ProjectEntity(
                            id = UUID.randomUUID().toString(),
                            title = result.title,
                            type = ProjectType.RECAP.name,
                            status = ProjectStatus.COMPLETED.name,
                            summary = result.summary,
                            contentData = result.fullNarrationText,
                            language = "Myanmar"
                        )
                    )

                    return@withContext result
                } catch (e: Exception) {
                    // Fall back to offline generation if JSON parsing failed
                }
            }
        }

        // Offline / Realistic Template Generation for all 5 modes
        delay(300)
        onProgress(1.0f, "Recap generation complete!")
        val result = createDefaultMyanmarRecap(inputContent, mode, chunkCount)
        saveProject(
            ProjectEntity(
                id = UUID.randomUUID().toString(),
                title = result.title,
                type = ProjectType.RECAP.name,
                status = ProjectStatus.COMPLETED.name,
                summary = result.summary,
                contentData = result.fullNarrationText,
                language = "Myanmar"
            )
        )
        return@withContext result
    }

    private fun createDefaultMyanmarRecap(inputContent: String, mode: MyanmarRecapMode, chunkCount: Int): MyanmarRecapResult {
        val title = if (inputContent.isNotBlank() && inputContent.length < 40) {
            inputContent
        } else {
            when (mode) {
                MyanmarRecapMode.NARRATOR_RECAP -> "ဆိုက်ဘာမြို့တော်၏ လျှို့ဝှက်ချက် (ဇာတ်ကြောင်းပြန် စတိုင်)"
                MyanmarRecapMode.DIALOGUE_RECAP -> "နီယွန်ည၏ စကားဝိုင်းများ (ဇာတ်ကောင် စကားပြော စတိုင်)"
                MyanmarRecapMode.FULL_RECAP -> "မြို့တော်မျှော်စင် တိုက်ပွဲကြီး (ဇာတ်ကြောင်း + စကားပြော အပြည့်အစုံ)"
                MyanmarRecapMode.CINEMATIC_RECAP -> "မုန်တိုင်းထန်သော နီယွန်မြို့တော် (ရုပ်ရှင်ဆန်ဆန် စတိုင်)"
                MyanmarRecapMode.SHORT_VIRAL_RECAP -> "၆၀ စက္ကန့်အတွင်း လျှို့ဝှက်ချက် (ဗိုင်းရပ် အမြန် အကျဉ်းချုပ်)"
            }
        }

        val summary = when (mode) {
            MyanmarRecapMode.NARRATOR_RECAP -> "အတိတ်မေ့နေသော အေးဂျင့် Leo နှင့် အာဏာရှင် ဗိုလ်မှူးကြီး Kane တို့၏ တိုက်ပွဲကို သဘာဝကျသော မြန်မာဇာတ်ကြောင်းပြောစတိုင်ဖြင့် အခန်းလိုက် တင်ဆက်ထားခြင်း ဖြစ်ပါသည်။"
            MyanmarRecapMode.DIALOGUE_RECAP -> "အေးဂျင့် Leo၊ ဗိုလ်မှူးကြီး Kane နှင့် ဒေါက်တာ Maya တို့၏ အပြန်အလှန် ရင်ဆိုင်စကားပြောများကို သဘာဝကျသော မြန်မာအသုံးအနှုန်းများဖြင့် တိကျစွာ ပြောင်းလဲဖန်တီးထားပါသည်။"
            MyanmarRecapMode.FULL_RECAP -> "ဇာတ်ကြောင်းပြောသူ၏ အသံထွက်နှင့် ဇာတ်ကောင်များ၏ စကားပြောများကို ပေါင်းစပ်ပြီး ဗီဒီယိုအခန်းများနှင့် မြန်မာ SRT စာတန်းထိုးများကို တစ်ပြိုင်တည်း ချိန်ညှိထားသော အပြည့်အစုံစတိုင် ဖြစ်ပါသည်။"
            MyanmarRecapMode.CINEMATIC_RECAP -> "ရုပ်ရှင်ဆန်ဆန် အသံနေအထားပြောင်းလဲမှုများ၊ ခေတ္တရပ်နားချက်များနှင့် မထင်မှတ်ထားသော ဇာတ်ကွက်အလှည့်အပြောင်းများကို အလေးပေးတင်ဆက်ထားသော ရုပ်ရှင်စတိုင် ဖြစ်ပါသည်။"
            MyanmarRecapMode.SHORT_VIRAL_RECAP -> "TikTok၊ Shorts နှင့် Reels များအတွက် အစပျိုးဆွဲဆောင်မှု (Hook) ပါဝင်ပြီး အဓိကအချက်များကိုသာ အမြန်ဆုံးသိရှိစေမည့် ဗိုင်းရပ်အကျဉ်းချုပ် ဖြစ်ပါသည်။"
        }

        val viralHook = if (mode == MyanmarRecapMode.SHORT_VIRAL_RECAP) {
            "⚡️ ဒီရုပ်ရှင်ရဲ့ အစမှာ ဘာဖြစ်သွားလဲ သိလား? 😱 အေးဂျင့် Leo တစ်ယောက် သတိရလာချိန်မှာ သူ့လက်ထဲမှာ မြို့တစ်ခုလုံးကို ဖျက်ဆီးပစ်နိုင်တဲ့ လျှို့ဝှက်ကုဒ်တွေ ရောက်နေခဲ့တယ်! အဆုံးထိ ကြည့်လိုက်ပါ... ဇာတ်သိမ်းက တကယ့် Shock ပဲ! 🔥"
        } else ""

        val characters = getDefaultCharactersForMode(mode)
        val scenes = getDefaultScenesForMode(mode)
        val srtText = generateSrtFromScenes(scenes)
        val fullNarration = scenes.joinToString("\n\n") { scene ->
            when (mode) {
                MyanmarRecapMode.NARRATOR_RECAP -> "[${scene.title} (${scene.timecode})]\n${scene.narratorScript}"
                MyanmarRecapMode.DIALOGUE_RECAP -> "[${scene.title} (${scene.timecode})]\n" + scene.dialogues.joinToString("\n") { "${it.speakerName}: ${it.myanmarDialogue}" }
                MyanmarRecapMode.FULL_RECAP -> "[${scene.title} (${scene.timecode})]\nဇာတ်ကြောင်း: ${scene.narratorScript}\n" + scene.dialogues.joinToString("\n") { "${it.speakerName}: ${it.myanmarDialogue}" }
                MyanmarRecapMode.CINEMATIC_RECAP -> "[${scene.title} (${scene.timecode})] ${scene.dramaticCue}\n${scene.narratorScript}"
                MyanmarRecapMode.SHORT_VIRAL_RECAP -> if (scene.sceneNumber == 1 && viralHook.isNotBlank()) "🔥 [VIRAL HOOK]\n$viralHook\n\n[${scene.title}]\n${scene.narratorScript}" else "[${scene.title}]\n${scene.narratorScript}"
            }
        }

        return MyanmarRecapResult(
            title = title,
            mode = mode,
            summary = summary,
            characters = characters,
            scenes = scenes,
            fullNarrationText = fullNarration,
            fullSynchronizedSrt = srtText,
            chunkCount = chunkCount,
            estimatedDuration = if (mode == MyanmarRecapMode.SHORT_VIRAL_RECAP) "60s" else "${chunkCount * 3} Min",
            viralHook = viralHook
        )
    }

    private fun getDefaultCharactersForMode(mode: MyanmarRecapMode): List<CharacterRole> {
        return listOf(
            CharacterRole(
                name = "အေးဂျင့် Leo",
                role = "အဓိကဇာတ်ကောင် (Protagonist)",
                description = "အတိတ်မေ့နေသော်လည်း တိုက်ခိုက်ရေးစွမ်းရည်ရှိသော လျှို့ဝှက်စစ်သည်။",
                voiceType = "Supported Vocal A (Male Deep)",
                pitch = 0.9f,
                speed = 1.0f
            ),
            CharacterRole(
                name = "ဗိုလ်မှူးကြီး Kane",
                role = "ရန်သူခေါင်းဆောင် (Antagonist)",
                description = "မြို့တော်ကို ထိန်းချုပ်ရန် ကြံစည်နေသော ဆိုက်ဘာစစ်တပ် အကြီးအကဲ။",
                voiceType = "Supported Vocal B (Male Resonant)",
                pitch = 0.8f,
                speed = 0.95f
            ),
            CharacterRole(
                name = "ဒေါက်တာ Maya",
                role = "သိပ္ပံပညာရှင် (Allied Mentor)",
                description = "Leo ၏ လျှို့ဝှက်ချက်ကို သိရှိပြီး မြို့ကို ကယ်တင်ရန် ကူညီပေးသူ။",
                voiceType = "Supported Vocal C (Female Clear)",
                pitch = 1.2f,
                speed = 1.05f
            )
        )
    }

    private fun getDefaultScenesForMode(mode: MyanmarRecapMode): List<MyanmarRecapScene> {
        return when (mode) {
            MyanmarRecapMode.CINEMATIC_RECAP -> listOf(
                MyanmarRecapScene(
                    sceneNumber = 1,
                    title = "အခန်း ၁ - မုန်တိုင်းညက နိုးထခြင်း",
                    timecode = "00:00 - 01:20",
                    visualDescription = "မိုးသည်းထန်စွာ ရွာသွန်းနေသော နီယွန်မြို့တော်၏ လမ်းကြားတွင် Leo သတိရလာသည်။",
                    dramaticCue = "[ခေတ္တရပ်နား] ရင်ခုန်ဖွယ် အစပျိုးချက်",
                    narratorScript = "မိုးသည်းထန်စွာ ရွာသွန်းနေတဲ့ နီယွန်မြို့တော်... [ခေတ္တရပ်နား] မိုးကြိုးများ တစ်ချက် လျှပ်ခနဲ လက်သွားချိန်မှာ လျှို့ဝှက်အေးဂျင့် Leo တစ်ယောက် သတိရလာခဲ့ပါတယ်။ သူ့လက်ထဲမှာတော့ မြို့တော်တစ်ခုလုံးကို ထိန်းချုပ်ထားတဲ့ လျှို့ဝှက်ကုဒ်တွေ... [ရင်ခုန်ဖွယ် အလှည့်အပြောင်း] ရောက်ရှိနေခဲ့တာပါ။",
                    srtSnippet = "1\n00:00:02,000 --> 00:00:08,000\nမိုးသည်းထန်စွာ ရွာသွန်းနေတဲ့ နီယွန်မြို့တော်... [ခေတ္တရပ်နား]\n\n2\n00:00:08,500 --> 00:00:15,000\nမိုးကြိုးများ လျှပ်ခနဲ လက်သွားချိန်မှာ လျှို့ဝှက်အေးဂျင့် Leo သတိရလာခဲ့ပါတယ်။"
                ),
                MyanmarRecapScene(
                    sceneNumber = 2,
                    title = "အခန်း ၂ - သေရေးရှင်ရေး ရင်ဆိုင်မှု",
                    timecode = "01:20 - 02:40",
                    visualDescription = "ရထားဘူတာဟောင်းတွင် ဗိုလ်မှူးကြီး Kane ၏ တပ်ဖွဲ့များနှင့် Leo ရင်ဆိုင်ရသည်။",
                    dramaticCue = "[ပြင်းထန်သော စိတ်လှုပ်ရှားမှု]",
                    narratorScript = "ရထားဘူတာဟောင်းကြီးထဲမှာတော့... [ခေတ္တရပ်နား] အာဏာရှင် ဗိုလ်မှူးကြီး Kane ဟာ Leo ရှေ့ကို ရောက်လာခဲ့ပါတယ်။ Leo ရဲ့ အတိတ်တစ်ခုလုံးကို ဖျက်ဆီးပစ်ခဲ့တဲ့ အမှန်တရားကို လှောင်ပြောင်ပြောဆိုရင်း... [အသက်ရှူမှားဖွယ် တိုက်ပွဲ] သေရေးရှင်ရေး တိုက်ပွဲကြီး စတင်ခဲ့ပါတော့တယ်။",
                    srtSnippet = "3\n00:01:22,000 --> 00:01:28,000\nရထားဘူတာဟောင်းကြီးထဲမှာတော့... [ခေတ္တရပ်နား] Kane ရောက်လာခဲ့ပါတယ်။\n\n4\n00:01:29,000 --> 00:01:36,000\nLeo ရဲ့ အတိတ်တစ်ခုလုံးကို ဖျက်ဆီးပစ်ခဲ့တဲ့ အမှန်တရားကို လှောင်ပြောင်ပြောဆိုခဲ့ပါတော့တယ်။"
                ),
                MyanmarRecapScene(
                    sceneNumber = 3,
                    title = "အခန်း ၃ - မျှော်စင်ထိပ်က နောက်ဆုံးအဖြေ",
                    timecode = "02:40 - 04:00",
                    visualDescription = "မိုးကြိုးများ ဆူညံနေသော မျှော်စင်ထိပ်တွင် မြို့၏ ကံကြမ္မာကို ဆုံးဖြတ်မည့် တိုက်ပွဲ။",
                    dramaticCue = "[ဇာတ်သိမ်း အထွတ်အထိပ်]",
                    narratorScript = "မိုးကြိုးသံများ ဆူညံနေတဲ့ မျှော်စင်ထိပ်မှာ... [ခေတ္တရပ်နား] Kane ရဲ့ နောက်ဆုံးစကားကတော့ 'ငါ့ကို သတ်လိုက်ရင်တောင် ဒီမြို့တော်ဟာ လွတ်လပ်ခွင့်ရမှာ မဟုတ်ဘူး' ဆိုတာပါပဲ။ ဒါပေမဲ့ Leo ဟာ နောက်မတွန့်ခဲ့ပါဘူး... တစ်ချက်တည်းသော ထိုးနှက်ချက်နဲ့အတူ မြို့တော်ကြီးကို အမှောင်ထုထဲကနေ ပြန်လည်ကယ်တင်ခဲ့ပါတော့တယ်။",
                    srtSnippet = "5\n00:02:42,000 --> 00:02:49,000\nမိုးကြိုးသံများ ဆူညံနေတဲ့ မျှော်စင်ထိပ်မှာ... [ခေတ္တရပ်နား]\n\n6\n00:02:50,000 --> 00:02:58,000\nတစ်ချက်တည်းသော ထိုးနှက်ချက်နဲ့အတူ မြို့တော်ကြီးကို ပြန်လည်ကယ်တင်ခဲ့ပါတော့တယ်။"
                )
            )
            MyanmarRecapMode.SHORT_VIRAL_RECAP -> listOf(
                MyanmarRecapScene(
                    sceneNumber = 1,
                    title = "အပိုင်း ၁ - Viral Hook (အစပျိုးချက်)",
                    timecode = "00:00 - 00:20",
                    visualDescription = "မိုးသည်းထန်စွာ ရွာနေသော လမ်းကြားတွင် Leo မျက်လုံးပွင့်လာသည်။",
                    dramaticCue = "[HIGH RETENTION HOOK]",
                    narratorScript = "ဒီဇာတ်ကားရဲ့ အစမှာ ဘာဖြစ်သွားလဲ သိလား? အေးဂျင့် Leo တစ်ယောက် သတိရလာချိန်မှာ သူ့လက်ထဲမှာ တစ်မြို့လုံးကို ဖျက်ဆီးပစ်နိုင်တဲ့ လျှို့ဝှက်ကုဒ်တွေ ရောက်နေခဲ့တယ်!",
                    srtSnippet = "1\n00:00:01,000 --> 00:00:06,000\nဒီဇာတ်ကားရဲ့ အစမှာ ဘာဖြစ်သွားလဲ သိလား? 😱\n\n2\n00:00:06,500 --> 00:00:12,000\nသူ့လက်ထဲမှာ မြို့တစ်ခုလုံးကို ဖျက်ဆီးနိုင်တဲ့ လျှို့ဝှက်ကုဒ်တွေ ရောက်နေခဲ့တယ်!"
                ),
                MyanmarRecapScene(
                    sceneNumber = 2,
                    title = "အပိုင်း ၂ - Plot Twist (လှည့်ကွက်)",
                    timecode = "00:20 - 00:40",
                    visualDescription = "Kane နှင့် မျက်နှာချင်းဆိုင် ရင်ဆိုင်ရပြီး အမှန်တရား ပေါ်ပေါက်လာသည်။",
                    dramaticCue = "[SHOCK REVEAL]",
                    narratorScript = "သူ့ကို လိုက်သတ်နေတဲ့ ဗိုလ်မှူးကြီး Kane ဟာ တကယ်တော့ သူ့ရဲ့ ဖန်တီးရှင် ဖြစ်နေခဲ့တာပါ! အဆုံးထိ ကြည့်လိုက်ပါ... အခုမှ တကယ့် Shock စတင်ပါပြီ!",
                    srtSnippet = "3\n00:00:21,000 --> 00:00:26,000\nKane ဟာ တကယ်တော့ သူ့ရဲ့ ဖန်တီးရှင် ဖြစ်နေခဲ့တာပါ!\n\n4\n00:00:26,500 --> 00:00:32,000\nအဆုံးထိ ကြည့်လိုက်ပါ... အခုမှ တကယ့် Shock စတင်ပါပြီ!"
                ),
                MyanmarRecapScene(
                    sceneNumber = 3,
                    title = "အပိုင်း ၃ - Viral Climax (အဆုံးသတ်)",
                    timecode = "00:40 - 01:00",
                    visualDescription = "မျှော်စင်ထိပ်တွင် မိုးကြိုးလျှပ်စီးများကြား အောင်ပွဲခံသည်။",
                    dramaticCue = "[CLIMAX & CTA]",
                    narratorScript = "နောက်ဆုံးမှာတော့ မျှော်စင်ထိပ်ကနေ စနစ်တစ်ခုလုံးကို ဖျက်ဆီးပြီး မြို့တော်ကြီးကို ကယ်တင်နိုင်ခဲ့ပါတယ်။ နောက်ထပ် ဇာတ်ကားအကျဉ်းချုပ်တွေအတွက် Follow လုပ်ထားပေးပါဦးနော်!",
                    srtSnippet = "5\n00:00:41,000 --> 00:00:47,000\nစနစ်တစ်ခုလုံးကို ဖျက်ဆီးပြီး မြို့တော်ကြီးကို ကယ်တင်နိုင်ခဲ့ပါတယ်။\n\n6\n00:00:47,500 --> 00:00:54,000\nနောက်ထပ် အကျဉ်းချုပ်တွေအတွက် Follow လုပ်ထားပေးပါဦးနော်!"
                )
            )
            else -> listOf(
                MyanmarRecapScene(
                    sceneNumber = 1,
                    title = "အခန်း ၁ - မုန်တိုင်းညက နိုးထခြင်း",
                    timecode = "00:00 - 01:30",
                    visualDescription = "မိုးသည်းထန်စွာ ရွာသွန်းနေသော နီယွန်မြို့တော်၏ လမ်းကြားတွင် Leo သတိရလာသည်။",
                    narratorScript = "ဒီဇာတ်လမ်းကတော့ မိုးသည်းထန်စွာ ရွာသွန်းနေတဲ့ နီယွန်မြို့တော်ရဲ့ လျှို့ဝှက်ဆန်းကြယ်တဲ့ ညတစ်ညမှာ စတင်ခဲ့ပါတယ်။ လျှို့ဝှက်အေးဂျင့် Leo ဟာ အတိတ်မေ့နေပေမယ့် သူ့ရဲ့ ရင်ထဲမှာ အရေးကြီးတဲ့ မစ်ရှင်တစ်ခု ရှိနေမှန်း သိနေခဲ့ပါတယ်။",
                    dialogues = listOf(
                        CharacterDialogue(
                            speakerName = "အေးဂျင့် Leo",
                            speakerRole = "Protagonist",
                            myanmarDialogue = "ငါ ဘယ်သူလဲ... ငါ့လက်ထဲမှာ ဘာကြောင့် ဒီကုဒ်တွေ ရှိနေရတာလဲ။",
                            pitch = 0.9f,
                            speed = 1.0f
                        ),
                        CharacterDialogue(
                            speakerName = "ဒေါက်တာ Maya",
                            speakerRole = "Allied Mentor",
                            myanmarDialogue = "Leo! ငါ့အသံကြားရလား။ အခုချက်ချင်း အဲ့ဒီလမ်းကြားကနေ ပြေးတော့၊ သူတို့ မင်းနောက်ကို လိုက်နေပြီ!",
                            pitch = 1.2f,
                            speed = 1.05f
                        )
                    ),
                    srtSnippet = "1\n00:00:02,000 --> 00:00:07,500\nမိုးသည်းထန်စွာ ရွာသွန်းနေတဲ့ နီယွန်မြို့တော်မှာ ဇာတ်လမ်းစတင်ခဲ့ပါတယ်။\n\n2\n00:00:08,200 --> 00:00:13,000\nLeo: ငါ ဘယ်သူလဲ... ငါ့လက်ထဲမှာ ဘာကြောင့် ဒီကုဒ်တွေ ရှိနေရတာလဲ။"
                ),
                MyanmarRecapScene(
                    sceneNumber = 2,
                    title = "အခန်း ၂ - ရင်ဆိုင်တွေ့ဆုံမှုနှင့် သတိပေးချက်",
                    timecode = "01:30 - 03:00",
                    visualDescription = "မြို့တော်ရထားဘူတာတွင် ဗိုလ်မှူးကြီး Kane နှင့် Leo တို့ မျက်နှာချင်းဆိုင် ရင်ဆိုင်မိသည်။",
                    narratorScript = "ဘူတာရုံကြီးထဲမှာတော့ ရန်သူ့တပ်ဖွဲ့တွေ ဝိုင်းရံထားချိန်မှာ ဗိုလ်မှူးကြီး Kane ဟာ Leo ရှေ့ကို ရောက်လာခဲ့ပါတယ်။ Leo ရဲ့ အတိတ်ဇာတ်ကြောင်းကို သူကိုယ်တိုင် ဖျက်ဆီးခဲ့တာ ဖြစ်ကြောင်း လှောင်ပြောင်ပြောဆိုခဲ့ပါတော့တယ်။",
                    dialogues = listOf(
                        CharacterDialogue(
                            speakerName = "ဗိုလ်မှူးကြီး Kane",
                            speakerRole = "Antagonist",
                            myanmarDialogue = "မင်း ဘယ်လောက်ပဲ ပြေးပြေး အလဟဿပဲ Leo။ မင်းရဲ့ ဘဝတစ်ခုလုံးက ငါ့ရဲ့ ဖန်တီးမှုပဲ!",
                            pitch = 0.8f,
                            speed = 0.95f
                        ),
                        CharacterDialogue(
                            speakerName = "အေးဂျင့် Leo",
                            speakerRole = "Protagonist",
                            myanmarDialogue = "ငါ့အတိတ်ကို မင်း ဖျက်ဆီးခဲ့ရင်တောင်... ငါ့ရဲ့ အနာဂတ်ကိုတော့ မင်း မပိုင်ဘူး Kane!",
                            pitch = 0.9f,
                            speed = 1.0f
                        )
                    ),
                    srtSnippet = "3\n00:01:32,000 --> 00:01:38,000\nဘူတာရုံကြီးထဲမှာတော့ ရန်သူ့တပ်ဖွဲ့တွေ ဝိုင်းရံထားချိန်မှာ Kane ရောက်လာခဲ့ပါတယ်။\n\n4\n00:01:39,000 --> 00:01:44,500\nKane: မင်းရဲ့ ဘဝတစ်ခုလုံးက ငါ့ရဲ့ ဖန်တီးမှုပဲ!"
                ),
                MyanmarRecapScene(
                    sceneNumber = 3,
                    title = "အခန်း ၃ - မျှော်စင်ထိပ်က နောက်ဆုံးတိုက်ပွဲ",
                    timecode = "03:00 - 04:30",
                    visualDescription = "မိုးကြိုးပစ်ခတ်နေသော မြို့တော်မျှော်စင်ထိပ်တွင် မြို့၏ လျှပ်စစ်စနစ်ကို ကယ်တင်မည့် နောက်ဆုံးတိုက်ပွဲ။",
                    narratorScript = "နောက်ဆုံးမှာတော့ မြို့တော်မျှော်စင်ကြီးထက်မှာ သူတို့နှစ်ဦး ရင်ဆိုင်တိုက်ခိုက်ကြပြီး မြို့သူမြို့သားတွေရဲ့ လွတ်လပ်ခွင့်ကို Leo က ပြန်လည်ရယူပေးနိုင်ခဲ့ပါတော့တယ်။",
                    dialogues = listOf(
                        CharacterDialogue(
                            speakerName = "ဒေါက်တာ Maya",
                            speakerRole = "Allied Mentor",
                            myanmarDialogue = "Leo! စနစ်ကို ပိတ်လိုက်နိုင်ပြီ! တစ်မြို့လုံး ဘေးကင်းသွားပြီ!",
                            pitch = 1.2f,
                            speed = 1.05f
                        ),
                        CharacterDialogue(
                            speakerName = "အေးဂျင့် Leo",
                            speakerRole = "Protagonist",
                            myanmarDialogue = "အဆုံးသတ်သွားပြီ။ အခုကစပြီး... ငါတို့ အားလုံး လွတ်လပ်သွားပြီ။",
                            pitch = 0.9f,
                            speed = 0.95f
                        )
                    ),
                    srtSnippet = "5\n00:03:02,000 --> 00:03:08,000\nနောက်ဆုံးမှာတော့ မြို့တော်မျှော်စင်ကြီးထက်မှာ နောက်ဆုံးတိုက်ပွဲ စတင်ခဲ့ပါတယ်။\n\n6\n00:03:09,000 --> 00:03:14,000\nLeo: အခုကစပြီး... ငါတို့ အားလုံး လွတ်လပ်သွားပြီ။"
                )
            )
        }
    }

    fun generateSrtFromScenes(scenes: List<MyanmarRecapScene>): String {
        val sb = StringBuilder()
        var index = 1
        for (scene in scenes) {
            val parts = scene.timecode.split("-")
            val startSec = parseTimeToSeconds(parts.getOrNull(0)?.trim() ?: "00:00")
            val endSec = parseTimeToSeconds(parts.getOrNull(1)?.trim() ?: "01:00")

            // Narrator segment
            if (scene.narratorScript.isNotBlank()) {
                val midSec = startSec + ((endSec - startSec) * 0.45).toInt()
                sb.append("${index++}\n")
                sb.append("${formatSecondsToSrtTime(startSec)} --> ${formatSecondsToSrtTime(midSec)}\n")
                sb.append("${scene.narratorScript}\n\n")
            }

            // Dialogue segments
            var currentDialogueTime = startSec + ((endSec - startSec) * 0.5).toInt()
            val step = if (scene.dialogues.isNotEmpty()) ((endSec - currentDialogueTime) / scene.dialogues.size).coerceAtLeast(3) else 3
            for (diag in scene.dialogues) {
                val diagEnd = (currentDialogueTime + step).coerceAtMost(endSec)
                sb.append("${index++}\n")
                sb.append("${formatSecondsToSrtTime(currentDialogueTime)} --> ${formatSecondsToSrtTime(diagEnd)}\n")
                sb.append("${diag.speakerName}: ${diag.myanmarDialogue}\n\n")
                currentDialogueTime = diagEnd
            }
        }
        return sb.toString().trimEnd()
    }

    private fun parseTimeToSeconds(timeStr: String): Int {
        val clean = timeStr.trim()
        val parts = clean.split(":")
        return when (parts.size) {
            2 -> (parts[0].toIntOrNull() ?: 0) * 60 + (parts[1].toIntOrNull() ?: 0)
            3 -> (parts[0].toIntOrNull() ?: 0) * 3600 + (parts[1].toIntOrNull() ?: 0) * 60 + (parts[2].toIntOrNull() ?: 0)
            else -> 0
        }
    }

    private fun formatSecondsToSrtTime(seconds: Int): String {
        val hours = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return String.format("%02d:%02d:%02d,000", hours, mins, secs)
    }

    // Backwards compatible method
    suspend fun generateVideoRecap(
        inputContent: String,
        videoLang: String,
        outputLang: String,
        style: String,
        onProgress: (Float, String) -> Unit
    ): RecapResult = withContext(Dispatchers.IO) {
        val mode = when {
            style.contains("Dialogue", ignoreCase = true) || style.contains("စကားပြော", ignoreCase = true) -> MyanmarRecapMode.DIALOGUE_RECAP
            style.contains("Full", ignoreCase = true) || style.contains("အပြည့်အစုံ", ignoreCase = true) -> MyanmarRecapMode.FULL_RECAP
            style.contains("Cinematic", ignoreCase = true) || style.contains("ရုပ်ရှင်", ignoreCase = true) -> MyanmarRecapMode.CINEMATIC_RECAP
            style.contains("Viral", ignoreCase = true) || style.contains("ဗိုင်းရပ်", ignoreCase = true) || style.contains("Short", ignoreCase = true) -> MyanmarRecapMode.SHORT_VIRAL_RECAP
            else -> MyanmarRecapMode.NARRATOR_RECAP
        }
        val myanmarResult = generateMyanmarVideoRecap(inputContent, mode, 1, onProgress)
        return@withContext RecapResult(
            title = myanmarResult.title,
            summary = myanmarResult.summary,
            characters = myanmarResult.characters,
            fullNarrationScript = myanmarResult.fullNarrationText,
            scenes = myanmarResult.scenes.map { s ->
                SceneItem(
                    sceneNumber = s.sceneNumber,
                    title = s.title,
                    timecode = s.timecode,
                    visualDescription = s.visualDescription,
                    narration = s.narratorScript.ifBlank { s.dialogues.joinToString("\n") { "${it.speakerName}: ${it.myanmarDialogue}" } }
                )
            },
            style = mode.titleEn,
            durationEstimated = myanmarResult.estimatedDuration
        )
    }

    // Myanmar Translation Engine
    suspend fun translateText(
        text: String,
        sourceLang: String,
        targetLang: String,
        style: String
    ): String = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext ""

        if (geminiService.isConfigured()) {
            val prompt = """
                You are an expert professional translator specializing in Myanmar (Burmese), English, Chinese, and Thai.
                Translate the following text:
                "$text"
                From: $sourceLang
                To: $targetLang
                Translation Style: $style (Natural, Formal, or Casual)
                Ensure natural grammar, culturally accurate vocabulary, and clean output with no commentary.
            """.trimIndent()

            val result = geminiService.generateContent(prompt)
            if (result.isSuccess) {
                val output = result.getOrNull()?.trim() ?: ""
                if (output.isNotBlank()) {
                    addTranslationHistory(text, output, sourceLang, targetLang, style)
                    return@withContext output
                }
            }
        }

        delay(300)
        val translated = intelligentFallbackTranslate(text, sourceLang, targetLang, style)
        addTranslationHistory(text, translated, sourceLang, targetLang, style)
        return@withContext translated
    }

    private fun intelligentFallbackTranslate(text: String, from: String, to: String, style: String): String {
        val lower = text.trim().lowercase()

        if ((to.contains("Myanmar", ignoreCase = true) || to.contains("မြန်မာ", ignoreCase = true))) {
            return when {
                lower.contains("hello") || lower.contains("hi") -> "မင်္ဂလာပါ"
                lower.contains("how are you") -> "နေကောင်းပါသလားခင်ဗျာ။"
                lower.contains("thank you") -> "ကျေးဇူးတင်ရှိပါသည်ခင်ဗျာ။"
                lower.contains("artificial intelligence") || lower.contains("ai") -> {
                    if (style.contains("Formal", ignoreCase = true)) {
                        "ဉာဏ်ရည်တုနည်းပညာ (AI) သည် ခေတ်သစ်ဒစ်ဂျစ်တယ်ကမ္ဘာ၏ အဓိကမောင်းနှင်အား ဖြစ်ပါသည်။"
                    } else {
                        "AI နည်းပညာက အခုခေတ်မှာ လူတိုင်းအတွက် အသုံးဝင်တဲ့ အရာတစ်ခု ဖြစ်လာပါပြီ။"
                    }
                }
                lower.contains("video recap") -> "ဗီဒီယို ဇာတ်လမ်းအကျဉ်းချုပ် ဖန်တီးမှု စနစ်"
                lower.contains("subscribe") -> "ကျွန်ုပ်တို့၏ Channel ကို Subscribe ပြုလုပ်ထားပေးပါဦးခင်ဗျာ။"
                else -> "「$text」— ဤစာသားအတွက် သဘာဝကျသော မြန်မာဘာသာပြန်ဆိုချက် ရလဒ် ဖြစ်ပါသည်။ (NEXORA AI Engine)"
            }
        }

        if (to.contains("English", ignoreCase = true)) {
            return when {
                lower.contains("မင်္ဂလာပါ") -> "Hello, welcome!"
                lower.contains("နေကောင်း") -> "How are you doing?"
                lower.contains("ကျေးဇူး") -> "Thank you very much."
                else -> "Accurate English translation for: $text"
            }
        }

        return if (to.contains("Chinese", ignoreCase = true) || to.contains("中文", ignoreCase = true)) {
            "这是翻译结果: $text"
        } else {
            "Translated: $text"
        }
    }

    private fun addTranslationHistory(src: String, dst: String, sLang: String, tLang: String, style: String) {
        val newRecord = TranslationRecord(
            sourceText = src,
            translatedText = dst,
            sourceLang = sLang,
            targetLang = tLang,
            style = style
        )
        val current = _translationHistory.value.toMutableList()
        current.add(0, newRecord)
        if (current.size > 20) current.removeAt(current.size - 1)
        _translationHistory.value = current
    }

    // SRT Subtitle Parsing and Generation
    fun parseSrt(raw: String): List<SubtitleSegment> {
        val list = mutableListOf<SubtitleSegment>()
        if (raw.isBlank()) return list

        val blocks = raw.replace("\r\n", "\n").split("\n\n")
        var counter = 1
        for (block in blocks) {
            val lines = block.trim().lines()
            if (lines.size >= 2) {
                val timeLineIndex = if (lines[0].toIntOrNull() != null && lines.size >= 3) 1 else 0
                val textStartIndex = timeLineIndex + 1

                val timeLine = lines[timeLineIndex]
                val parts = timeLine.split("-->")
                if (parts.size == 2) {
                    val start = parts[0].trim()
                    val end = parts[1].trim()
                    val text = lines.subList(textStartIndex, lines.size).joinToString("\n")
                    list.add(
                        SubtitleSegment(
                            index = counter++,
                            startTime = start,
                            endTime = end,
                            originalText = text,
                            translatedText = ""
                        )
                    )
                }
            }
        }
        return list
    }

    fun exportToSrt(segments: List<SubtitleSegment>, useTranslated: Boolean = true): String {
        val sb = StringBuilder()
        for ((idx, seg) in segments.withIndex()) {
            sb.append("${idx + 1}\n")
            sb.append("${seg.startTime} --> ${seg.endTime}\n")
            val text = if (useTranslated && seg.translatedText.isNotBlank()) seg.translatedText else seg.originalText
            sb.append("$text\n\n")
        }
        return sb.toString().trimEnd()
    }

    fun exportToTxt(segments: List<SubtitleSegment>, useTranslated: Boolean = true): String {
        val sb = StringBuilder()
        for (seg in segments) {
            val text = if (useTranslated && seg.translatedText.isNotBlank()) seg.translatedText else seg.originalText
            sb.append("[${seg.startTime}] $text\n")
        }
        return sb.toString().trimEnd()
    }

    suspend fun translateSubtitlesToMyanmar(segments: List<SubtitleSegment>): List<SubtitleSegment> = withContext(Dispatchers.IO) {
        val updated = mutableListOf<SubtitleSegment>()
        for (seg in segments) {
            val translated = translateText(seg.originalText, "English", "Myanmar", "Natural")
            updated.add(seg.copy(translatedText = translated))
        }
        return@withContext updated
    }

    // Viral Title and Hashtag Generator
    suspend fun generateTitlesAndTags(topic: String, lang: String): GeneratedTitlesAndTags = withContext(Dispatchers.IO) {
        if (geminiService.isConfigured()) {
            val prompt = """
                You are NEXORA AI viral content strategist.
                Generate high-CTR YouTube titles, TikTok hooks, SEO description, and trending hashtags for:
                "$topic"
                Output Language: $lang (Myanmar & English friendly)
                Return strictly JSON with keys:
                "youtubeTitles": array of 5 titles with high CTR hooks,
                "tiktokCaptions": array of 4 TikTok caption hooks,
                "seoDescription": optimized description with hook and timestamps,
                "hashtags": array of 15 hashtags
            """.trimIndent()

            val result = geminiService.generateContent(prompt)
            if (result.isSuccess) {
                try {
                    val raw = result.getOrNull() ?: ""
                    val clean = raw.substringAfter("{").substringBeforeLast("}")
                    val obj = JSONObject("{$clean}")

                    val yTitles = mutableListOf<String>()
                    val yArr = obj.optJSONArray("youtubeTitles")
                    if (yArr != null) {
                        for (i in 0 until yArr.length()) yTitles.add(yArr.getString(i))
                    }

                    val tCaptions = mutableListOf<String>()
                    val tArr = obj.optJSONArray("tiktokCaptions")
                    if (tArr != null) {
                        for (i in 0 until tArr.length()) tCaptions.add(tArr.getString(i))
                    }

                    val tags = mutableListOf<String>()
                    val tagArr = obj.optJSONArray("hashtags")
                    if (tagArr != null) {
                        for (i in 0 until tagArr.length()) tags.add(tagArr.getString(i))
                    }

                    return@withContext GeneratedTitlesAndTags(
                        youtubeTitles = if (yTitles.isNotEmpty()) yTitles else getDefaultTitles(topic),
                        tiktokCaptions = if (tCaptions.isNotEmpty()) tCaptions else getDefaultCaptions(topic),
                        seoDescription = obj.optString("seoDescription", getDefaultDescription(topic)),
                        hashtags = if (tags.isNotEmpty()) tags else getDefaultHashtags()
                    )
                } catch (e: Exception) {
                    // Fallback to default
                }
            }
        }

        delay(400)
        return@withContext GeneratedTitlesAndTags(
            youtubeTitles = getDefaultTitles(topic),
            tiktokCaptions = getDefaultCaptions(topic),
            seoDescription = getDefaultDescription(topic),
            hashtags = getDefaultHashtags()
        )
    }

    private fun getDefaultTitles(topic: String): List<String> = listOf(
        "ဒီဇာတ်ကားကို မကြည့်ရသေးရင် မဖြစ်ဘူး! $topic ဇာတ်သိမ်းအထိ ရင်ခုန်စရာ အပြည့်",
        "မထင်မှတ်ထားတဲ့ ဇာတ်ကွက် အလှည့်အပြောင်း! $topic (Full Movie Recap)",
        "တစ်မြို့လုံးကို ထိတ်လန့်သွားစေခဲ့တဲ့ $topic ၏ လျှို့ဝှက်ချက် အဖြေ",
        "10 Minutes Movie Recap: $topic (မြန်မာအသံထွက် ဇာတ်လမ်းအကျဉ်း)",
        "Why Everyone is Talking About $topic — Explained in 5 Minutes!"
    )

    private fun getDefaultCaptions(topic: String): List<String> = listOf(
        "နောက်ဆုံးမှာ ဖြစ်သွားတာကို ဘယ်သူမှ ထင်မထားခဲ့ဘူး... 😱 $topic #မြန်မာဇာတ်ကား #recap",
        "ဒီလို ရုပ်ရှင်မျိုး ကြည့်ဖူးကြလား? ဇာတ်သိမ်းက တကယ့် Shock ပဲ! ⚡️ #nexoraai",
        "အဆုံးထိကြည့်ပါ၊ အဖြေကို သင် အံ့ဩသွားစေရမယ်! 🔥 #movierecap #myanmar",
        "Wait till the end to see the truth behind $topic! 🤯 #viral #shorts"
    )

    private fun getDefaultDescription(topic: String): String = """
        မင်္ဂလာပါ NEXORA AI ပရိသတ်များခင်ဗျာ။
        ယနေ့ တင်ဆက်ပေးမယ့် ဇာတ်လမ်းကတော့ စိတ်လှုပ်ရှားဖွယ် ကောင်းလှတဲ့ "$topic" အကြောင်း ဖြစ်ပါတယ်။
        
        ⏱ အချိန်မှတ်တမ်းများ (Timestamps):
        00:00 - အဖွင့်ဇာတ်ကွက် (Introduction)
        01:15 - လျှို့ဝှက်ချက် ဖော်ထုတ်ခြင်း (Key Conflict)
        02:45 - အလှည့်အပြောင်း (Plot Twist)
        03:30 - အဆုံးသတ် သုံးသပ်ချက် (Conclusion)

        အသစ်သစ်သော ဇာတ်လမ်းအကျဉ်းချုပ်များကို နေ့စဉ် ကြည့်ရှုနိုင်ရန် NEXORA AI Channel ကို Subscribe ပြုလုပ်ထားပေးပါခင်ဗျာ။
    """.trimIndent()

    private fun getDefaultHashtags(): List<String> = listOf(
        "#NexoraAI", "#MovieRecap", "#မြန်မာဇာတ်လမ်းအကျဉ်း", "#FilmReview",
        "#TikTokMyanmar", "#YouTubeRecap", "#မြန်မာစာတန်းထိုး", "#TrendingNow",
        "#ViralRecap", "#CinemaBurma", "#Storytelling", "#AIStudio",
        "#MyanmarCreator", "#Entertainment", "#ViralVideo"
    )
}
