package com.example.data.model

enum class ProjectType(val label: String) {
    RECAP("Video Recap"),
    TRANSLATE("Translation"),
    VOICE("AI Voice"),
    SUBTITLE("SRT Subtitle"),
    THUMBNAIL("Thumbnail"),
    TITLES("Titles & Tags")
}

enum class ProjectStatus(val label: String) {
    COMPLETED("Completed"),
    PROCESSING("Processing"),
    DRAFT("Draft"),
    ERROR("Error")
}

enum class MyanmarRecapMode(
    val id: String,
    val titleEn: String,
    val titleMy: String,
    val badge: String,
    val descriptionEn: String,
    val descriptionMy: String,
    val previewSample: String
) {
    NARRATOR_RECAP(
        id = "narrator",
        titleEn = "Narrator Recap",
        titleMy = "ဇာတ်ကြောင်းပြန် စတိုင်",
        badge = "MODE 1",
        descriptionEn = "One Myanmar narrator tells the complete story scene by scene with engaging storytelling.",
        descriptionMy = "သဘာဝကျသော မြန်မာဇာတ်ကြောင်းပြောသူမှ ဇာတ်လမ်းကို အခန်းလိုက် အသံထွက်ဖတ်ကြားတင်ဆက်သည်။",
        previewSample = "ဒီဇာတ်လမ်းကတော့ မိုးသည်းထန်စွာ ရွာသွန်းနေတဲ့ နီယွန်မြို့တော်မှာ စတင်ခဲ့ပါတယ်။ အတိတ်မေ့နေတဲ့ အေးဂျင့် Leo ဟာ မြို့တော်ကို ကယ်တင်ဖို့အတွက် သူတစ်ဦးတည်း စတင်လှုပ်ရှားခဲ့ရပါတယ်..."
    ),
    DIALOGUE_RECAP(
        id = "dialogue",
        titleEn = "Character Dialogue",
        titleMy = "ဇာတ်ကောင် စကားပြော စတိုင်",
        badge = "MODE 2",
        descriptionEn = "Retell the story mainly through character conversations with distinct supported Burmese voices.",
        descriptionMy = "ဇာတ်ကောင်စကားပြောများကို သဘာဝကျသော မြန်မာစကားပြောများအဖြစ် ပြောင်းလဲပြီး ဇာတ်ကောင်အလိုက် အသံခွဲခြားပေးသည်။",
        previewSample = "Leo: \"ငါ့အတိတ်ကို မင်းဖျက်ဆီးခဲ့ရင်တောင်... ငါ့အနာဂတ်ကိုတော့ မင်း မပိုင်ဘူး Kane!\"\nKane: \"မင်းဘယ်လောက်ပဲ ပြေးပြေး အလဟဿပဲ Leo...\""
    ),
    FULL_RECAP(
        id = "full",
        titleEn = "Full Recap",
        titleMy = "ဇာတ်ကြောင်း + စကားပြော အပြည့်အစုံ",
        badge = "MODE 3",
        descriptionEn = "Combines narrator storytelling and character dialogues, synchronized with scenes, audio and SRT.",
        descriptionMy = "ဇာတ်ကြောင်းပြောနှင့် ဇာတ်ကောင်စကားပြောများကို အခန်းလိုက် တွဲစပ်ကာ မြန်မာ SRT စာတန်းထိုးနှင့် တစ်ပြိုင်တည်း ထုတ်ပေးသည်။",
        previewSample = "[ဇာတ်ကြောင်း] မြို့တော်မျှော်စင်ထိပ်မှာတော့ အဆုံးအဖြတ်တိုက်ပွဲ စတင်ခဲ့ပါပြီ...\nLeo: \"ဒေါက်တာ Maya! စနစ်ကို အခုချက်ချင်း ပိတ်လိုက်ပါ!\"\nMaya: \"Leo, ငါကြိုးစားနေတယ်! နောက် ၁၀ စက္ကန့်ပဲ လိုတော့တယ်!\""
    ),
    CINEMATIC_RECAP(
        id = "cinematic",
        titleEn = "Cinematic Recap",
        titleMy = "ရုပ်ရှင်ဆန်ဆန် စိတ်လှုပ်ရှားဖွယ် စတိုင်",
        badge = "MODE 4",
        descriptionEn = "Dramatic and exciting Myanmar storytelling with natural pauses, emotional emphasis and plot twists.",
        descriptionMy = "အထူးဇာတ်ကွက်၊ စိတ်လှုပ်ရှားဖွယ် အလှည့်အပြောင်းများနှင့် အသံနေအထားပြောင်းလဲမှုများဖြင့် ရုပ်ရှင်ဆန်ဆန် တင်ဆက်သည်။",
        previewSample = "မိုးကြိုးများ တစ်ချက် လျှပ်ခနဲ လက်သွားချိန်... [ခေတ္တရပ်နား] အမှောင်ထုထဲကနေ ထွက်ပေါ်လာတဲ့ မျက်နှာကို မြင်လိုက်ရတဲ့အခါ Leo တစ်ယောက် အသက်ရှူပင် မှားသွားခဲ့ရပါတယ်။ အဲ့ဒီလူဟာ တခြားသူ မဟုတ်ခဲ့ပါဘူး... [ရင်ခုန်ဖွယ် အလှည့်အပြောင်း] သူ့ရဲ့ အရင်းနှီးဆုံး သူငယ်ချင်း ဖြစ်နေခဲ့တာပါ!"
    ),
    SHORT_VIRAL_RECAP(
        id = "viral",
        titleEn = "Short Viral Recap",
        titleMy = "ဗိုင်းရပ် အမြန် အကျဉ်းချုပ် စတိုင်",
        badge = "MODE 5",
        descriptionEn = "Concise, engaging Myanmar recap starting with a viral hook for TikTok, YouTube Shorts & Reels.",
        descriptionMy = "TikTok နှင့် Reels များအတွက် ဆွဲဆောင်မှုရှိသော အစပျိုးစာသား (Hook) ဖြင့် တိုတိုရှင်းရှင်း လိုရင်းတင်ဆက်သည်။",
        previewSample = "⚡️ ဒီရုပ်ရှင်ရဲ့ အစမှာ ဘာဖြစ်သွားလဲ သိလား? 😱\nအေးဂျင့် Leo တစ်ယောက် သတိရလာချိန်မှာ သူ့လက်ထဲမှာ မြို့တစ်ခုလုံးကို ဖျက်ဆီးပစ်နိုင်တဲ့ လျှို့ဝှက်ကုဒ်တွေ ရောက်နေခဲ့တယ်! အဆုံးထိ ကြည့်လိုက်ပါ... ဇာတ်သိမ်းက တကယ့် Shock ပဲ! 🔥"
    )
}

data class CharacterRole(
    val name: String,
    val role: String,
    val description: String,
    val voiceType: String = "Male 1",
    val pitch: Float = 1.0f,
    val speed: Float = 1.0f
)

data class CharacterDialogue(
    val id: String = java.util.UUID.randomUUID().toString(),
    val speakerName: String,
    val speakerRole: String,
    val myanmarDialogue: String,
    val pitch: Float = 1.0f,
    val speed: Float = 1.0f
)

data class MyanmarRecapScene(
    val sceneNumber: Int,
    val title: String,
    val timecode: String,
    val visualDescription: String,
    val narratorScript: String = "",
    val dialogues: List<CharacterDialogue> = emptyList(),
    val srtSnippet: String = "",
    val dramaticCue: String = ""
)

data class MyanmarRecapResult(
    val title: String,
    val mode: MyanmarRecapMode,
    val summary: String,
    val characters: List<CharacterRole>,
    val scenes: List<MyanmarRecapScene>,
    val fullNarrationText: String,
    val fullSynchronizedSrt: String,
    val chunkCount: Int = 1,
    val estimatedDuration: String = "3 Min",
    val viralHook: String = "",
    val viralDurationOption: String = "60s"
)

// Backwards compatibility for existing views
data class SceneItem(
    val sceneNumber: Int,
    val title: String,
    val timecode: String,
    val visualDescription: String,
    val narration: String
)

data class RecapResult(
    val title: String,
    val summary: String,
    val characters: List<CharacterRole>,
    val fullNarrationScript: String,
    val scenes: List<SceneItem>,
    val style: String,
    val durationEstimated: String
)

data class TranslationRecord(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sourceText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String,
    val style: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class SubtitleSegment(
    val index: Int,
    val startTime: String,
    val endTime: String,
    val originalText: String,
    val translatedText: String = ""
)

data class VoiceProfile(
    val id: String,
    val name: String,
    val gender: String,
    val language: String,
    val tag: String,
    val sampleText: String
)

data class PersonalVoiceProfile(
    val id: String = "user_voice_${System.currentTimeMillis()}",
    val name: String,
    val audioSamplePath: String,
    val durationSeconds: Int,
    val language: String = "my-MM",
    val pitch: Float = 1.0f,
    val speed: Float = 1.0f,
    val baseVoiceId: String = AzureBurmeseVoices.MALE_THIHA,
    val createdAt: Long = System.currentTimeMillis(),
    val sampleText: String = "မင်္ဂလာပါ၊ ကျွန်တော့်အသံဖြင့် NEXORA AI ရုပ်ရှင်အညွှန်း ဇာတ်လမ်းများကို တင်ဆက်ပေးသွားပါမည်။",
    val isCloned: Boolean = true
)

object AzureBurmeseVoices {
    const val LOCALE = "my-MM"
    const val MALE_THIHA = "my-MM-ThihaNeural"
    const val FEMALE_NILAR = "my-MM-NilarNeural"
}

data class TtsLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val femaleVoice: String,
    val maleVoice: String,
    val isBurmese: Boolean = false
)

object SupportedTtsLanguages {
    val BURMESE = TtsLanguage(
        code = AzureBurmeseVoices.LOCALE,
        displayName = "Myanmar (Burmese)",
        nativeName = "မြန်မာစာ",
        femaleVoice = AzureBurmeseVoices.FEMALE_NILAR,
        maleVoice = AzureBurmeseVoices.MALE_THIHA,
        isBurmese = true
    )

    val ENGLISH = TtsLanguage(
        code = "en-US",
        displayName = "English (US)",
        nativeName = "English",
        femaleVoice = "en-US-JennyNeural",
        maleVoice = "en-US-GuyNeural",
        isBurmese = false
    )

    val CHINESE = TtsLanguage(
        code = "zh-CN",
        displayName = "Chinese (Mandarin)",
        nativeName = "中文",
        femaleVoice = "zh-CN-XiaoxiaoNeural",
        maleVoice = "zh-CN-YunxiNeural",
        isBurmese = false
    )

    val THAI = TtsLanguage(
        code = "th-TH",
        displayName = "Thai",
        nativeName = "ไทย",
        femaleVoice = "th-TH-PremwadeeNeural",
        maleVoice = "th-TH-NiwatNeural",
        isBurmese = false
    )

    val ALL = listOf(BURMESE, ENGLISH, CHINESE, THAI)
}

enum class MyanmarVoiceStyle(
    val id: String,
    val titleEn: String,
    val titleMy: String,
    val badge: String,
    val descriptionEn: String,
    val descriptionMy: String,
    val baseVoiceId: String,
    val defaultGender: String,
    val defaultSpeed: Float,
    val defaultPitch: Float,
    val defaultVolume: Float,
    val previewSample: String
) {
    MALE_VOICE(
        id = "male_voice",
        titleEn = "Male Voice",
        titleMy = "သဘာဝ အမျိုးသားအသံ",
        badge = "STYLE 1",
        descriptionEn = "Natural Myanmar male voice.",
        descriptionMy = "သဘာဝကျသော မြန်မာအမျိုးသား အသံ (ThihaNeural)",
        baseVoiceId = AzureBurmeseVoices.MALE_THIHA,
        defaultGender = "Male",
        defaultSpeed = 1.0f,
        defaultPitch = 1.0f,
        defaultVolume = 1.0f,
        previewSample = "မင်္ဂလာပါ၊ ကျွန်တော်ကတော့ သဘာဝကျတဲ့ မြန်မာအမျိုးသား အသံဖြစ်ပါတယ်။"
    ),
    FEMALE_VOICE(
        id = "female_voice",
        titleEn = "Female Voice",
        titleMy = "သဘာဝ အမျိုးသမီးအသံ",
        badge = "STYLE 2",
        descriptionEn = "Natural Myanmar female voice.",
        descriptionMy = "သဘာဝကျသော မြန်မာအမျိုးသမီး အသံ (NilarNeural)",
        baseVoiceId = AzureBurmeseVoices.FEMALE_NILAR,
        defaultGender = "Female",
        defaultSpeed = 1.0f,
        defaultPitch = 1.0f,
        defaultVolume = 1.0f,
        previewSample = "မင်္ဂလာပါရှင့်၊ ကျွန်မကတော့ ကြည်လင်ပြတ်သားတဲ့ မြန်မာအမျိုးသမီး အသံဖြစ်ပါတယ်။"
    ),
    STORYTELLER(
        id = "storyteller",
        titleEn = "Storyteller",
        titleMy = "ပုံပြောသူ / ဇာတ်လမ်းပြော",
        badge = "STYLE 3",
        descriptionEn = "Warm and engaging storytelling delivery.",
        descriptionMy = "နွေးထွေးပြီး နားဆင်သူကို ဆွဲဆောင်နိုင်သော ပုံပြင်ဇာတ်လမ်းပြော အသံနေအထား",
        baseVoiceId = AzureBurmeseVoices.FEMALE_NILAR,
        defaultGender = "Female",
        defaultSpeed = 0.92f,
        defaultPitch = 0.98f,
        defaultVolume = 1.05f,
        previewSample = "ဟိုးရှေးရှေးတုန်းက တောအုပ်ကြီးတစ်ခုရဲ့ အစွန်အဖျားမှာတော့ လျှို့ဝှက်ဆန်းကြယ်တဲ့ ရဲတိုက်ကြီးတစ်ခု ရှိခဲ့ဖူးပါတယ်..."
    ),
    NEWS_PRESENTER(
        id = "news_presenter",
        titleEn = "News Presenter",
        titleMy = "သတင်းကြေညာသူ",
        badge = "STYLE 4",
        descriptionEn = "Clear and professional news delivery.",
        descriptionMy = "ကြည်လင်ပြတ်သားပြီး တိကျလေးနက်သော သတင်းကြေညာ တင်ဆက်မှု အသံနေအထား",
        baseVoiceId = AzureBurmeseVoices.MALE_THIHA,
        defaultGender = "Male",
        defaultSpeed = 1.10f,
        defaultPitch = 1.02f,
        defaultVolume = 1.10f,
        previewSample = "ယနေ့ညနေခင်း ထိပ်တန်းသတင်းများအရ နည်းပညာကဏ္ဍတွင် ဉာဏ်ရည်တုစနစ်သစ်များ အောင်မြင်စွာ တီထွင်နိုင်ခဲ့ကြောင်း သိရှိရပါသည်။"
    ),
    CINEMATIC(
        id = "cinematic",
        titleEn = "Cinematic",
        titleMy = "ရုပ်ရှင်ဆန်ဆန် ဇာတ်ကြောင်းပြန်",
        badge = "STYLE 5",
        descriptionEn = "Dramatic movie recap narration.",
        descriptionMy = "ရင်ခုန်စိတ်လှုပ်ရှားဖွယ် ဇာတ်ကွက်အလှည့်အပြောင်းများအတွက် ရုပ်ရှင်ဆန်ဆန် အသံနေအထား",
        baseVoiceId = AzureBurmeseVoices.MALE_THIHA,
        defaultGender = "Male",
        defaultSpeed = 0.88f,
        defaultPitch = 0.90f,
        defaultVolume = 1.15f,
        previewSample = "မိုးကြိုးများ တစ်ချက် လျှပ်ခနဲ လက်သွားချိန်... အမှောင်ထုထဲကနေ ပေါ်ထွက်လာတဲ့ အရိပ်မည်းကြီးဟာ မြို့တော်တစ်ခုလုံးကို ထိတ်လန့်သွားစေခဲ့ပါတယ်!"
    ),
    CALM_VOICE(
        id = "calm_voice",
        titleEn = "Calm Voice",
        titleMy = "အေးချမ်းငြိမ်သက်သော အသံ",
        badge = "STYLE 6",
        descriptionEn = "Soft and peaceful narration.",
        descriptionMy = "နားဆင်ရသူ စိတ်နှလုံး အေးချမ်းစေမည့် နူးညံ့ငြိမ်းချမ်းသော အသံနေအထား",
        baseVoiceId = AzureBurmeseVoices.FEMALE_NILAR,
        defaultGender = "Female",
        defaultSpeed = 0.85f,
        defaultPitch = 0.95f,
        defaultVolume = 0.90f,
        previewSample = "စိတ်အေးချမ်းစွာ အနားယူလိုက်ပါ။ သဘာဝတရားရဲ့ တိတ်ဆိတ်အေးချမ်းမှုက သင့်ရဲ့ စိတ်နှလုံးကို ကြည်နူးစေပါလိမ့်မယ်..."
    ),
    EXCITING_VOICE(
        id = "exciting_voice",
        titleEn = "Exciting Voice",
        titleMy = "တက်ကြွစိတ်လှုပ်ရှားဖွယ် အသံ",
        badge = "STYLE 7",
        descriptionEn = "Energetic and expressive narration.",
        descriptionMy = "အားမာန်အပြည့်နှင့် ပွဲဆူစေမည့် စိတ်လှုပ်ရှားတက်ကြွဖွယ် အသံနေအထား",
        baseVoiceId = AzureBurmeseVoices.MALE_THIHA,
        defaultGender = "Male",
        defaultSpeed = 1.18f,
        defaultPitch = 1.12f,
        defaultVolume = 1.20f,
        previewSample = "အံ့သြစရာ အကောင်းဆုံး အခိုက်အတန့် ရောက်ရှိလို့လာပါပြီ! ဘယ်သူမှ မထင်မှတ်ထားတဲ့ အနိုင်ရလဒ်ကို အခုပဲ အတူတူ ကြည့်ရှုလိုက်ကြရအောင်ဗျာ!"
    )
}

data class GeneratedTitlesAndTags(
    val youtubeTitles: List<String>,
    val tiktokCaptions: List<String>,
    val seoDescription: String,
    val hashtags: List<String>
)
