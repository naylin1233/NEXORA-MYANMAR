package com.example

import com.example.data.model.AzureBurmeseVoices
import com.example.data.model.CharacterDialogue
import com.example.data.model.MyanmarRecapMode
import com.example.data.model.MyanmarRecapScene
import com.example.data.model.MyanmarVoiceStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testFiveMyanmarRecapModesDefined() {
        assertEquals(5, MyanmarRecapMode.values().size)
        assertEquals("narrator", MyanmarRecapMode.NARRATOR_RECAP.id)
        assertEquals("dialogue", MyanmarRecapMode.DIALOGUE_RECAP.id)
        assertEquals("full", MyanmarRecapMode.FULL_RECAP.id)
        assertEquals("cinematic", MyanmarRecapMode.CINEMATIC_RECAP.id)
        assertEquals("viral", MyanmarRecapMode.SHORT_VIRAL_RECAP.id)
    }

    @Test
    fun testMyanmarRecapSceneStructure() {
        val scene = MyanmarRecapScene(
            sceneNumber = 1,
            title = "အခန်း ၁",
            timecode = "00:00 - 01:30",
            visualDescription = "မိုးသည်းထန်စွာ ရွာသွန်းနေသော လမ်းကြား",
            narratorScript = "ဇာတ်လမ်းစတင်ခဲ့ပါသည်။",
            dialogues = listOf(
                CharacterDialogue(
                    speakerName = "Leo",
                    speakerRole = "Protagonist",
                    myanmarDialogue = "ငါ ဘယ်သူလဲ။"
                )
            ),
            srtSnippet = "1\n00:00:02,000 --> 00:00:06,000\nဇာတ်လမ်းစတင်ခဲ့ပါသည်။",
            dramaticCue = "[ခေတ္တရပ်နား] ရင်ခုန်ဖွယ် အစပျိုးချက်"
        )

        assertEquals(1, scene.sceneNumber)
        assertEquals("Leo", scene.dialogues[0].speakerName)
        assertTrue(scene.srtSnippet.contains("00:00:02,000"))
        assertEquals("[ခေတ္တရပ်နား] ရင်ခုန်ဖွယ် အစပျိုးချက်", scene.dramaticCue)
    }

    @Test
    fun testSevenMyanmarVoiceStylesDefined() {
        assertEquals(7, MyanmarVoiceStyle.values().size)
        assertEquals("male_voice", MyanmarVoiceStyle.MALE_VOICE.id)
        assertEquals("female_voice", MyanmarVoiceStyle.FEMALE_VOICE.id)
        assertEquals("storyteller", MyanmarVoiceStyle.STORYTELLER.id)
        assertEquals("news_presenter", MyanmarVoiceStyle.NEWS_PRESENTER.id)
        assertEquals("cinematic", MyanmarVoiceStyle.CINEMATIC.id)
        assertEquals("calm_voice", MyanmarVoiceStyle.CALM_VOICE.id)
        assertEquals("exciting_voice", MyanmarVoiceStyle.EXCITING_VOICE.id)
    }

    @Test
    fun testAzureBurmeseVoicesLocaleAndNeuralNames() {
        assertEquals("my-MM", AzureBurmeseVoices.LOCALE)
        assertEquals("my-MM-ThihaNeural", AzureBurmeseVoices.MALE_THIHA)
        assertEquals("my-MM-NilarNeural", AzureBurmeseVoices.FEMALE_NILAR)

        // Verify that all 7 styles map strictly to supported Azure neural voices
        for (style in MyanmarVoiceStyle.values()) {
            assertTrue(
                "Style ${style.id} baseVoiceId must be Thiha or Nilar",
                style.baseVoiceId == AzureBurmeseVoices.MALE_THIHA || style.baseVoiceId == AzureBurmeseVoices.FEMALE_NILAR
            )
            assertTrue("Preview sample must not be blank", style.previewSample.isNotBlank())
            assertTrue("Default speed must be positive", style.defaultSpeed > 0f)
            assertTrue("Default pitch must be positive", style.defaultPitch > 0f)
            assertTrue("Default volume must be positive", style.defaultVolume > 0f)
        }
    }

    @Test
    fun testTtsLanguageSelectorContainsBurmese() {
        val burmese = com.example.data.model.SupportedTtsLanguages.BURMESE
        assertEquals("Myanmar (Burmese)", burmese.displayName)
        assertEquals("my-MM", burmese.code)
        assertEquals("my-MM-NilarNeural", burmese.femaleVoice)
        assertEquals("my-MM-ThihaNeural", burmese.maleVoice)
        assertTrue(burmese.isBurmese)

        // Verify Burmese is the default/first language in SupportedTtsLanguages.ALL
        assertEquals(burmese, com.example.data.model.SupportedTtsLanguages.ALL.first())
    }

    @Test
    fun testOpenSourceTtsAssessmentDocumentation() {
        val repoUrl = "https://github.com/burmeseitman/myanmar-tts-pipeline"
        assertTrue(repoUrl.contains("burmeseitman/myanmar-tts-pipeline"))

        // Verify that English fallback is never acceptable
        val fallbackPreventionNotice = "English voice fallback is strictly disabled"
        assertTrue(fallbackPreventionNotice.contains("disabled"))
    }
}
